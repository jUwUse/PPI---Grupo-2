<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}


?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesgerenciarusuarios.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Usuários / SGE</title>

</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href="/SGE/AdicionarUsuários.php" class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Usuário</span>
            </a><br>
        </div>

    </div>

    <div id="SelectDosClientes">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        echo '<table><tr>';
        while ($numero <= $resultadoID["IDUSER"]) {
            $sql = "SELECT * FROM USUARIO WHERE IDUSER = $numero";
            $resultadoverificacao = $conn->query($sql);
            $resultadolista = $resultadoverificacao->fetch_assoc();
            $numero += 1;

            foreach ($resultadoverificacao as $j) {

                if ($i <= 3) {
                    echo '<td>
                            <div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div>
                            </td>';
                } else {
                    echo '</tr><tr>';
                    echo '<td><div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="/SGE/AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div></td>';
                    $i = 0;
                }
                $i++;
            }
        }
        echo '</table>';
        ?>

    </div>

</body>

</html>