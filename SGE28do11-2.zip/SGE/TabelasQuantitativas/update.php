<?php
include('../Config.php');

$regex = "/^(0|[1-9]\d*)(\.\d+)?$/";
if(preg_match($regex, $_POST["value"])) {
    if(strlen(substr(strrchr($_POST["value"], "."), 1)) > 1){
        $_POST["value"] = (string)round((double)$_POST["value"], 1, PHP_ROUND_HALF_UP);
    }
}

$query = "
 UPDATE NOTAS SET ".$_POST["name"]." = '".$_POST["value"]."' 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query);

$query = "
 UPDATE NOTAS SET NOTA_FINAL = ROUND(((PRIMEIRO_SEMESTRE * 0.4) + (SEGUNDO_SEMESTRE * 0.6)),1) 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query); 
?>
