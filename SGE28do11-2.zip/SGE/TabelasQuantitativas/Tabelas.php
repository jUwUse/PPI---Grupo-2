<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

unset($_SESSION["Turma"]);

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    } else {
        header("location: ../Home.php");
        exit();
    }
}
if (isset($_GET['disciplina']) == FALSE) {
    header("location: ../Home.php");
    exit();
}

$instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ?");
$instrucao->bind_param("i", $_GET['disciplina']); //s=string, i=int, d=double
$instrucao->execute();
$resultadoDisciplina = $instrucao->get_result();
$resultadoDisciplina = $resultadoDisciplina->fetch_assoc();

$instrucao = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?");
$instrucao->bind_param("i", $_GET['id']); //s=string, i=int, d=double
$instrucao->execute();
$resultadoTurma = $instrucao->get_result();
$resultadoTurma = $resultadoTurma->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="../stylestabquanti.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabela de <?php echo $resultadoDisciplina['NOME'] ?> - <?php echo $resultadoTurma['NUMERO'] ?> / SGE</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap3-editable/js/bootstrap-editable.js"></script>

</head>

<body>
    <!-- Aqui vai ser a mais pura cópia. Tutorial abaixo, caso funcionar:
    https://www.youtube.com/watch?v=lkDO2xqbifE
-->
    <table id="sample_data" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>NOME</th>
                <th>PRIMEIRO SEMESTRE</th>
                <th>SEGUNDO SEMESTRE</th>
                <th>NOTA FINAL</th>
                <th>OBSERVAÇÕES</th>
            </tr>
        </thead>
        <tbody id="employee_data"></tbody>
    </table>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

</body>

</html>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
        function fetch_employee_data() {
            $.ajax({
                url: "/SGE/TabelasQuantitativas/fetch.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA'] ?>",
                method: "POST",
                dataType: "json",
                success: function(data) {

                    for (var count = 0; count < data.length; count++) {
                        var html_data = '<tr><td>' + data[count].NOME + '</td>';
                        html_data += '<td data-name="PRIMEIRO_SEMESTRE" class="PRIMEIRO_SEMESTRE" data-type="text" data-pk="' + data[count].IDNOTA + '">' + data[count].PRIMEIRO_SEMESTRE + '</td>';
                        html_data += '<td data-name="SEGUNDO_SEMESTRE" class="SEGUNDO_SEMESTRE" data-type="text" data-pk="' + data[count].IDNOTA + '">' + data[count].SEGUNDO_SEMESTRE + '</td>';
                        html_data += '<td data-name="NOTA_FINAL" class="NOTA_FINAL" data-type="text" data-pk="' + data[count].IDNOTA + '">' + data[count].NOTA_FINAL + '</td>';
                        html_data += '<td data-name="OBSERVACOES" class="OBSERVACOES" data-type="text" data-pk="' + data[count].IDNOTA + '">' + data[count].OBSERVACOES + '</td>';
                        $('#employee_data').append(html_data);
                    }
                }
            })
        }
        fetch_employee_data();

        $('#employee_data').editable({
            container: 'body',
            selector: 'td.PRIMEIRO_SEMESTRE',
            url: "/SGE/TabelasQuantitativas/update.php",
            title: 'PRIMEIRO_SEMESTRE',
            type: "POST",
            dataType: 'json',

            validate: function(value) {
                if ($.trim(value) == '') {
                    return 'Este campo deve ser preenchido.';
                }
                var regex = /^-?\d*\.?\d+$/;
                if (!regex.test(value)) {
                    return 'Somente números são permitidos.';
                }

                if (parseFloat(value) > 10) {
                    return 'O valor máximo é 10.';
                }
                if (parseFloat(value) < 0) {
                    return 'O valor mínimo é 0.';
                }
            }
        });

        $('#employee_data').editable({
            container: 'body',
            selector: 'td.SEGUNDO_SEMESTRE',
            url: "/SGE/TabelasQuantitativas/update.php",
            title: 'SEGUNDO_SEMESTRE',
            type: "POST",
            dataType: 'json',

            validate: function(value) {
                if ($.trim(value) == '') {
                    return 'Este campo deve ser preenchido.';
                }
                var regex = /^-?\d*\.?\d+$/;
                if (!regex.test(value)) {
                    return 'Somente números são permitidos.';
                }
                if (parseFloat(value) > 10) {
                    return 'O valor máximo é 10.';
                }
            }
        });

        $('#employee_data').editable({
            container: 'body',
            selector: 'td.OBSERVACOES',
            url: "/SGE/TabelasQuantitativas/update.php",
            title: 'OBSERVACOES',
            type: "POST",
            dataType: 'json',

            validate: function(value) {
                if ($.trim(value) == '') {
                    return 'Este campo deve ser preenchido.';
                }
            }
        });
    });
</script>