<?php //Preenche os dados.
include("Config.php");
include("Logout_Function.php");

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

function Alterar($Nome, $Matriz, $Permissoes, $conn, $id)
{

    if ($Nome == NULL && $Matriz == NULL && $Permissoes == NULL) {
        echo "<div class='erro'>Insira as informações que deseja alterar.</div>";
        return "não funcionou.";
    }

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }
    if (strlen((string)$Matriz) > 100) {
        echo "<div class='erro'>O nome do setor matricial não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM SETOR WHERE NOME = ? AND IDSETOR != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Outro setor já possui este nome.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("UPDATE SETOR SET NOME = ? WHERE IDSETOR = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();

    $instrucao = $conn->prepare("UPDATE SETOR SET MATRIZ = ? WHERE IDSETOR = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Matriz); //s=string, i=int, d=double
    $instrucao->execute();

    $instrucao = $conn->prepare("DELETE FROM TRABALHA WHERE IDSETOR = {$id}");
    $instrucao->execute();

    foreach ($_POST['SetorResponsavel'] as $item) {
        $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $item); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc();

        $instrucao = $conn->prepare("INSERT INTO TRABALHA(IDSETOR, IDUSER) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("ss", $id, $resultado['IDUSER']); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.1</div>";
            return "não funcionou.";
        }
    }

    header('Location: GerenciarSetores.php');
}

$IDAEditar = (int)$_GET['id'];
$sql = "SELECT * FROM SETOR WHERE IDSETOR = $IDAEditar";
$resultadoverificacao = $conn->query($sql);
$resultadolista = $resultadoverificacao->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesalterarsetores.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Alterar Setores / SGE</title>

    <script>
        function Cancelar() {
            location.href = '/SGE/GerenciarSetores.php';
        }

        window.onmousedown = function(e) {
            var el = e.target;
            if (el.tagName.toLowerCase() == 'option' && el.closest('select').hasAttribute('multiple')) {
                e.preventDefault();

                // toggle selection
                if (el.hasAttribute('selected')) el.removeAttribute('selected');
                else el.setAttribute('selected', '');

                // hack to correct buggy behavior
                var select = el.parentNode.cloneNode(true);
                el.parentNode.parentNode.replaceChild(select, el.parentNode);
            }
        }
    </script>

</head>

<body>
    <?php
    if (isset($_POST['AlteracaoSubmitSetor'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = Alterar($_POST['NomeSetor'], $_POST['MatrizSetor'], $_POST['SetorResponsavel'], $conn, $IDAEditar);
        // function Alterar($Nome, $Duracao, $Coordenador, $conn, $id) {
    }
    ?>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarSetores.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <p><b>Alterar Setores</b></p>

            <form enctype="multipart/form-data" action="" id="FormulariodeAlteracaoSetor" method="post">
                <label for="NomeSetor">Nome da Atividade:</label><br>
                <input class="campo" type="text" id="NomeSetor" name="NomeSetor" value="<?php echo @$resultadolista['NOME']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                <label for="SetorResponsavel">Usuários Responsáveis:</label><br>
                <div class="dropdown">
                    <button class="dropbtn">Selecione</button>
                    <select class="dropdown-content" name="SetorResponsavel[]" id="SetorResponsavel" multiple="multiple">
                        <?php
                        $numero = 1;
                        $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
                        $resultadoID = $conn->query($ultimoID);
                        $resultadoID = $resultadoID->fetch_assoc();
                        while ($numero <= $resultadoID["IDUSER"]) {
                            $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE IDUSER = ?");
                            $instrucao->bind_param("i", $numero);
                            $instrucao->execute();
                            $resultado_editores_option = $instrucao->get_result();
                            $resultado_editores_option = $resultado_editores_option->fetch_assoc();
                            if ($resultado_editores_option != NULL) {
                                $query = "SELECT * FROM TRABALHA WHERE IDUSER = {$resultado_editores_option['IDUSER']} AND IDSETOR = {$IDAEditar}";
                                $resultado2 = mysqli_query($conn, $query);
                                $returned_rows = mysqli_fetch_all($resultado2, MYSQLI_ASSOC);
                                if ($returned_rows == NULL) {
                                    echo '<option value="' . $resultado_editores_option["NOME"] . '"> ' . $resultado_editores_option["NOME"] . ' </option>';
                                } else {
                                    foreach ($returned_rows as $row) {
                                        echo '<option value="' . $resultado_editores_option["NOME"] . '" selected> ' . $resultado_editores_option["NOME"] . ' </option>';
                                    }
                                }
                            }
                            $numero++;
                        }
                        ?>
                    </select>
                </div>

                <br>

                <label for="MatrizSetor">Setor Matricial:</label><br>
                <input class="campo" type="text" id="MatrizSetor" name="MatrizSetor" value="<?php echo @$resultadolista['MATRIZ']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                <input class="botao" type="submit" name="AlteracaoSubmitSetor" value="Aplicar">
                <input class="botaodois" type="button" onclick="Cancelar()" name="AlteracaoCancel" value="Cancelar">
            </form>

        </div>
    </div>

</body>

</html>