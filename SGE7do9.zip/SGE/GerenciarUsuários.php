<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    include ('Config.php');
    include('Logout_Function.php');

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }
    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários / SGE</title>

</head>
<body>
    <a href="/SGE/AdicionarUsuários.php">Adicionar</a>

    <div id="SelectDosClientes">
        <?php
            $numero = 1;
            $i = 0;
            $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
            $resultadoID = $conn->query($ultimoID);
            $resultadoID = $resultadoID->fetch_assoc();
            echo '<table><tr>';
            while ($numero <= $resultadoID["IDUSER"]) {
                $sql = "SELECT * FROM USUARIO WHERE IDUSER = $numero";
                $resultadoverificacao = $conn->query($sql);
                $resultadolista = $resultadoverificacao->fetch_assoc();
                $numero += 1;
                    
                foreach ($resultadoverificacao as $j) {
                    
                    if ($i<=3) {
                        echo '<td>
                            <div> <p>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="AlterarUsuários.php?id='. $resultadolista["IDUSER"] .'">Editar</a> <a href="DeletarUsuários.php?id='. $resultadolista["IDUSER"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\');">Deletar</a> </p>' . '</p> </div>
                            </td>'; 
                    }
                    
                    else {       
                        echo '</tr><tr>';
                        echo '<td><div> <p>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="/SGE/AlterarUsuários.php?id='. $resultadolista["IDUSER"] .'">Editar</a> <a href="DeletarUsuários.php?id='. $resultadolista["IDUSER"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\');">Deletar</a> </p>' .'</p> </div></td>'; 
                        $i = 0;
                    }
                    $i ++;
                    
                }  
            }
            echo '</table>';
        ?>

    </div>

</body>
</html>