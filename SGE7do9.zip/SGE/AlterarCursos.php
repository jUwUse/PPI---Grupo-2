<?php //Preenche os dados.
    include ("Config.php");
    include ("Logout_Function.php");

    function Alterar($Nome, $Duracao, $Coordenador, $conn, $id) {

        if ($Nome == NULL && $Duracao == NULL && $Siape == NULL) {
            echo "Insira as informações que deseja alterar.";
            return "não funcionou.";
        }
        
        if (strlen((string)$Nome) > 100) {
            echo "O nome não pode ter mais de 100 caracteres.";
            return "não funcionou.";
        }
        if (strlen((string)$Coordenador) > 100) {
            echo "O nome do coordenador não pode ter mais de 100 caracteres.";
            return "não funcionou.";
        }
        if ($Duracao < 1 && $Duracao != NULL) {
            echo "Um curso precisa ter, no mínimo, 1 ano de duração";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM CURSO WHERE NOME = ? AND IDCURSO != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "Outro curso já possui este nome.";
            return "não funcionou.";
        }
        
        if ($Nome != NULL) {
            $instrucao = $conn->prepare("UPDATE CURSO SET NOME = ? WHERE IDCURSO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
            $instrucao->execute();
        }
        
        if ($Duracao != NULL) {
            $instrucao = $conn->prepare("UPDATE CURSO SET DURACAO = ? WHERE IDCURSO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $Duracao); //s=string, i=int, d=double
            $instrucao->execute();
        }

        if ($Coordenador != NULL) {
            $instrucao = $conn->prepare("UPDATE CURSO SET COORDENADOR = ? WHERE IDCURSO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Coordenador); //s=string, i=int, d=double
            $instrucao->execute();
        }
            
        header('Location: GerenciarCursos.php');
    }

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }
    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }

    $IDAEditar = (int)$_GET['id'];
    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolista = $resultadoverificacao->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Cursos / SGE</title>

    <script>

    function Cancelar() {
        location.href = '/SGE/GerenciarCursos.php';
    }

    </script>

</head>
<body>
    <?php
        if(isset($_POST['AlteracaoSubmitCurso'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Alterar($_POST['NomeAlteracaoCurso'], $_POST['DuracaoAlteracaoCurso'], $_POST['CoordenadorAlteracaoCurso'], $conn, $IDAEditar);
            // function Alterar($Nome, $Duracao, $Coordenador, $conn, $id) {
        }
    ?>

    <form action="" id="FormulariodeAlteracaoCurso" method="post">
        <label for="NomeAlteracaoCurso">Nome:</label><br>
        <input type="text" id="NomeAlteracaoCurso" name="NomeAlteracaoCurso" placeholder = "<?php echo @$resultadolista["NOME"]?>" value="<?php echo @$_POST['NomeAlteracaoCurso'] ?>"><br>

        <label for="DuracaoAlteracaoCurso">Duracao:</label><br>
        <input type="number" id="DuracaoAlteracaoCurso" name="DuracaoAlteracaoCurso" placeholder = "<?php echo @$resultadolista["DURACAO"]?>" value="<?php echo @$_POST['DuracaoAlteracaoCurso'] ?>"><br>

        <label for="CoordenadorAlteracaoCurso">Coordenador:</label><br>
        <input type="text" id="CoordenadorAlteracaoCurso" name="CoordenadorAlteracaoCurso" placeholder = "<?php echo @$resultadolista["COORDENADOR"]?>" value="<?php echo @$_POST['CoordenadorAlteracaoCurso'] ?>"><br>

        <input type="submit" name="AlteracaoSubmitCurso" value="Salvar Alterações"><br>
        <input type="button" onclick="Cancelar()" name="AlteracaoCancel" value="Cancelar"><br>
    </form>

</body>
</html>