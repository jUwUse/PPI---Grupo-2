<?php
    error_reporting(E_ALL ^ E_DEPRECATED);

    function login($Email, $Senha) {
        include ('Config.php');

        if ($Email == "" || $Senha == "") {
            echo "Um erro desconhecido ocorreu. Tente novamente.";
            return "não funcionou.";
        }
        
        $Email = filter_var($Email, FILTER_SANITIZE_EMAIL);

        $instrucao = $conn->prepare("SELECT EMAIL, SENHA FROM USUARIO WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Email); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultadoverificacao = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultadoverificacao == NULL) {
            echo "Email ou senha incorretos.";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME, TIPO FROM USUARIO WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Email); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $InformacoesExtras = $resultado->fetch_assoc();

        if (password_verify($Senha, $resultadoverificacao['SENHA']) == False /* && $InformacoesExtras["TIPO"] != "ADM" */) { // Isso vai fazer a verificação descriptografando o hash da senha. Caso não exista um administrador ainda, tire o comentário do código, mas a princípio isso só deve acontecer caso o banco de dados seja perdido (senha=PPIPPIPPI).
            echo "Senha incorreta.";
            return "não funcionou.";
        }
        else { //Caso tenha tudo funcionado.
            $_SESSION["Email"] = $Email; //Armazena o email do usuário
            $_SESSION["Nome"] = $InformacoesExtras["NOME"];
            $_SESSION["Tipo"] = $InformacoesExtras["TIPO"];
            $_SESSION["Senha"] = $resultadoverificacao["SENHA"];
            header("location: home.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar / SGE</title>
</head>
<body>
    <span>
        <?php
            if(isset($_POST['LoginSubmit'])) {
                $resultado_final_decisivo_mega_importante = login($_POST['EmailLogin'], $_POST['UserPasswordLogin']);
            }

        ?>

    </span>
    <div>
        <div>
            <form action="login.php" method="post" autocomplete="off">
                <label for="EmailLogin">Email:</label><br>
                <input type="email" id="EmailLogin" name="EmailLogin" value="<?php echo @$_POST['EmailLogin']; ?>" required><br>

                <label for="UserPasswordLogin">Senha:</label><br>
                <input type="password" id="UserPasswordLogin" name="UserPasswordLogin" value="<?php echo @$_POST['UserPasswordLogin']; ?>" required><br>

                <!-- <input type="checkbox" id="UserRememberLogin" name="UserRememberLogin">
                <label for="UserRememberLogin">Lembrar-me</label><br> -->
                <!-- Por enquanto removido porque não é necessário, caso sobrar tempo eu programo. -->

                <input type="submit" name="LoginSubmit" value="Avançar"><br>

                Não tem uma conta?
                <a href="/SGE/SignUp.php">Cadastre-se</a><br>

                Perdeu sua senha?
                <a href="/SGE/RecoverPassword.php">Recupere-a</a><br>

            </form>
        </div>
    </div>
</body>
</html>