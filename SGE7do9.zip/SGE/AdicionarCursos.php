<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    include ('Config.php');
    include('Logout_Function.php');

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }
    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }

    function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        $elementos = func_get_args();

        foreach ($elementos as $valor) {
            if($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE){ //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
                echo "Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.";
                return "não funcionou.";
            } //Pode mudar o return para "echo" para testar mais visivelmente.
        };

        if (strlen((string)$Nome) > 100) {
            echo "O nome não pode ter mais de 100 caracteres.";
            return "não funcionou.";
        }
        if (strlen((string)$Coordenador) > 100) {
            echo "O nome do coordenador não pode ter mais de 100 caracteres.";
            return "não funcionou.";
        }
        if ($Duracao < 1) {
            echo "Um curso precisa ter, no mínimo, 1 ano de duração";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM CURSO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "Um curso com esse nome já existe no sistema.";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("INSERT INTO CURSO(NOME, DURACAO, COORDENADOR) VALUES(?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("sis", $Nome, $Duracao, $Coordenador); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT * FROM CURSO WHERE IDCURSO = LAST_INSERT_ID()"); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultadolistaid = $resultado->fetch_assoc();

        // Adicionando turmas:

        header("location: /SGE/AdicionarTurmas.php?id=".$resultadolistaid['IDCURSO']);

    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Cursos / SGE</title>
</head>
<body>
    <span>
        <?php
            if(isset($_POST['CursoCadastroSubmit'])) { // Caso o formulário de professor seja enviado.
                $resultado_final_decisivo_mega_importante = Adicionar($_POST['NomeCurso'], $_POST['DuracaoCurso'], $_POST['CoordenadorCurso'], $conn);
                //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
            }
        ?>
    </span>

    <div>
        <form id="CursoCadastro" action="AdicionarCursos.php" method="post" style="text-align: center; display: block;" autocomplete="off">
            <label for="NomeCurso">Nome do Curso:</label><br>
            <input type="text" id="NomeCurso" name="NomeCurso" value="<?php echo @$_POST['NomeCurso']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

            <label for="DuracaoCurso">Duracao (em anos)</label><br>
            <input type="number" id="DuracaoCurso" name="DuracaoCurso" value="<?php echo @$_POST['DuracaoCurso']; ?>" required><br>

            <label for="CoordenadorCurso">Coordenador do Curso:</label><br>
            <input type="text" id="CoordenadorCurso" name="CoordenadorCurso" value="<?php echo @$_POST['CoordenadorCurso']; ?>"><br>

            <input type="submit" name="CursoCadastroSubmit" value="Criar Curso"><br>
        </form>
    </div>
    
</body>
</html>