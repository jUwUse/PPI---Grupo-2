<?php
require("./fpdf185/fpdf.php");
include("./config.php");

// Informações do Aluno
if (isset($_GET['id'])) {
    $alunosSelecionados = $_GET['id']; // Vai retornar uma lista
    $pdf = new FPDF("L", "mm", "A4");

    foreach ($alunosSelecionados as $aluno) {
        $IDAEditar = $aluno;
        $sql = "SELECT * FROM ALUNO WHERE IDALUNO = $IDAEditar";
        $resultadoverificacao = $conn->query($sql);
        $resultadolistaAluno = $resultadoverificacao->fetch_assoc();

        // Informações da Turma
        $sql = "SELECT * FROM TURMA INNER JOIN ALUNO ON TURMA.IDTURMA = ALUNO.IDTURMA WHERE ALUNO.IDALUNO = $IDAEditar";
        $resultadoverificacao = $conn->query($sql);
        $resultadolistaTurma = $resultadoverificacao->fetch_assoc();

        // Informações das Notas
        $pdf->AddPage(); 
        $pdf->SetFont("Arial", "B", "10");

        $query = "SELECT * FROM DISCIPLINA WHERE IDTURMA = {$resultadolistaTurma['IDTURMA']}";
        $resultado = mysqli_query($conn, $query);
        $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
        $num_rows = $resultado->num_rows;

        if ($num_rows > 0) {
            $pdf->Cell(71, 10, "Desemprenho Escolar do(a) ". strtoupper($resultadolistaAluno["NOME"]) . " (". $resultadolistaAluno["MATRICULA"]. "), ".strtr((string)$_GET['tipo'], '_',' '), 0, 1);
            if ($num_rows == 1) {
                $pdf->Cell(60, 6, "Disciplina", 1, 0, "L");
                $pdf->Cell(40, 6, "Nota", 1, 0, "C");
                $pdf->Cell(40, 6, "Faltas", 1, 1, "C");
            } 
            else { //Duas colunas
                $pdf->Cell(60, 6, "Disciplina", 1, 0, "L");
                $pdf->Cell(40, 6, "Nota", 1, 0, "C");
                $pdf->Cell(40, 6, "Faltas", 1, 0, "C");
                $pdf->Cell(60, 6, "Disciplina", 1, 0, "L");
                $pdf->Cell(40, 6, "Nota", 1, 0, "C");
                $pdf->Cell(40, 6, "Faltas", 1, 1, "C");
            }
        }
        else {
            header("location: Turma.php?id={$resultadolistaTurma['IDTURMA']}");
        }

        $i = 0;
        $lista = array();
        foreach ($returned_rows as $row) {
            $query = "SELECT * FROM NOTAS WHERE IDDISCIPLINA = {$row['IDDISCIPLINA']} AND IDALUNO = $IDAEditar";
            $resultado = mysqli_query($conn, $query);
            $returned_rowsNotas = mysqli_fetch_all($resultado, MYSQLI_ASSOC);

            $query = "SELECT * FROM USUARIO INNER JOIN LECIONA ON USUARIO.IDUSER = LECIONA.IDUSER WHERE LECIONA.IDDISCIPLINA = {$row['IDDISCIPLINA']}";
            $resultado = mysqli_query($conn, $query);
            $returned_rowsLeciona = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
            
            foreach ($returned_rowsLeciona as $leciona) {
                array_push($lista, (string)$leciona['EMAIL']);
            }

            foreach ($returned_rowsNotas as $nota) {
                $listaEmails = implode(', ', $lista);
                $text = $row['NOME']."\n(". $listaEmails .")";

                $x = $pdf->GetX();
                $y = $pdf->GetY();
                $height = $pdf->GetMultiCellHeight(60, 5, $text);

                if ($i == 1) {
                    $height = max($height, $prevHeight);
                }

                $pdf->MultiCell(60, 5, $text, 1, 'L'); 

                $pdf->SetXY($x + 60, $y);
                $pdf->Cell(40, $height, $nota[$_GET['tipo']], 1, 0, "C"); 
                $pdf->Cell(40, $height, $nota['FALTAS'], 1, 0, "C");

                if ($i == 0) {
                    $prevHeight = $height;

                    $pdf->SetXY($x + 140, $y);
                    $i = 1;
                } else {
                    $pdf->Ln();
                    $i = 0;
                }

                $lista = array();
                break;
            }
        }
    }

    $pdf->Output();
}
?>
