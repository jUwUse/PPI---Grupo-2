<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    } else {
        header("location: Home.php");

        exit();
    }
}

if (isset($_GET['id'])) {
    $_SESSION['Turma'] = $_GET['id'];
}

$selectnumero = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
$selectnumero->bind_param("i", $_SESSION['Turma']); //s=string, i=int, d=double
$selectnumero->execute();
$resultadonumero = $selectnumero->get_result();
$resultadonumero = $resultadonumero->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesgerarmaterial.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerar Material, Turma <?php echo $resultadonumero['NUMERO'] ?> / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function FormHide(tipo) {
            const botaoum = document.querySelector('.botaoum');
            const botaodois = document.querySelector('.botaodois');

            if (tipo == "Boletim") {
                document.getElementById("FormConselho").style.display = "none";
                document.getElementById("FormBoletim").style.display = "block";
                document.getElementById("botaoBoletim").style.borderColor = 'purple';
                document.getElementById("botaoConselho").style.borderColor = 'black';
            } else if (tipo == "Conselho") {
                document.getElementById("FormBoletim").style.display = "none";
                document.getElementById("FormConselho").style.display = "block";
                document.getElementById("botaoConselho").style.borderColor = 'purple';
                document.getElementById("botaoBoletim").style.borderColor = 'black';

            }
        }

        function SelectTodos(formId, tipo) {
            const form = document.getElementById(formId);
            const checkboxes = form.querySelectorAll('input[type="checkbox"]:not(#checkAll' + tipo + ')');
            const selectAllCheckbox = document.getElementById('checkAll' + tipo);

            if (selectAllCheckbox.checked) {
                checkboxes.forEach(checkbox => checkbox.checked = true);
            } else {
                checkboxes.forEach(checkbox => checkbox.checked = false);
            }
        }

        function handleCheckboxClick(formId, tipo) {
            const form = document.getElementById(formId);
            const checkboxes = form.querySelectorAll('input[type="checkbox"]:not(#checkAll' + tipo + ')');
            const selectAllCheckbox = document.getElementById('checkAll' + tipo);

            selectAllCheckbox.checked = [...checkboxes].every(checkbox => checkbox.checked);
        }
    </script>
</head>

<body>

    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/Turma.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>


        <div class="container-fluid">
            <div class="row quadrado align-items-center">
                <h3>Gerar Material</h3>
                <div>
                    <button class="botaoum clicar" id="botaoBoletim" type="button" onclick="FormHide('Boletim')">Boletim</button>
                    <button class="botaodois" id="botaoConselho" type="button" onclick="FormHide('Conselho')">Material para Conselho</button>
                </div>

                <span>
                    <?php
                    if (isset($_POST['NotasBoletimSubmit'])) {
                        $tipo = $_POST['NotasBoletim'];
                        $alunosSelecionados = $_POST['alunosBoletim'];
                        $queryParams = http_build_query(['id' => $alunosSelecionados, 'tipo' => $tipo]); //Se passar diretamente no link, vai ter um problema com a lista.
                        header("location: /SGE/GerarBoletimAluno.php?$queryParams");
                    }
                    if (isset($_POST['NotasConselhoSubmit'])) {
                        $tipo = $_POST['NotasConselho'];
                        $alunosSelecionados = $_POST['alunosConselho'];
                        $queryParams = http_build_query(['id' => $alunosSelecionados, 'tipo' => $tipo]);
                        header("location: /SGE/GerarConselhoAluno.php?$queryParams");
                    }
                    ?>
                </span>

                <div>
                    <form id="FormBoletim" enctype="multipart/form-data" action="GerarMaterial.php" method="post" style="text-align: left" autocomplete="off">
                        <p><b>Gerar Boletim</b></p>

                        <select name="NotasBoletim" id="NotasBoletim" size="4" required>
                            <?php
                            $query = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='BD_PPIWOW' AND `TABLE_NAME`='NOTAS' AND `COLUMN_NAME` NOT IN('IDNOTA','IDDISCIPLINA','IDALUNO','NOME','OBSERVACOES','FALTAS')";
                            $resultado = mysqli_query($conn, $query);
                            if ($resultado) {
                                $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
                                foreach ($returned_rows as $row) {
                            ?>
                                    <option value="<?php echo $row["COLUMN_NAME"] ?>"> <?php echo $row["COLUMN_NAME"] ?> </option>
                            <?php
                                }
                            }
                            ?>
                        </select><br><br>

                        <input type="checkbox" id="checkAllBoletim" name="checkAllBoletim" value="checkAllBoletim" onclick="SelectTodos('FormBoletim', 'Boletim')">
                        <label for="checkAllBoletim"> Selecionar Todos</label><br>

                        <?php
                        $query = "SELECT * FROM ALUNO WHERE IDTURMA = {$_SESSION['Turma']}";
                        $resultadoAluno = mysqli_query($conn, $query);
                        if ($resultadoAluno) {
                            $returned_rows = mysqli_fetch_all($resultadoAluno, MYSQLI_ASSOC);
                            foreach ($returned_rows as $row) {
                        ?>
                                <input type="checkbox" id="check<?php echo $row['NOME'] ?>" name="alunosBoletim[]" value="<?php echo $row['IDALUNO'] ?>" onclick="handleCheckboxClick('FormBoletim', 'Boletim')">
                                <label for="check<?php echo $row['NOME'] ?>"> <?php echo $row['NOME'] ?></label><br>
                        <?php
                            }
                        }
                        ?>

                        <input class="botao" type="submit" name="NotasBoletimSubmit" value="Gerar"><br>
                    </form>

                    <form id="FormConselho" enctype="multipart/form-data" action="GerarMaterial.php" method="post" style="text-align: left; display:none;" autocomplete="off">
                        <p><b>Gerar Material para Conselho</b></p>

                        <select name="NotasConselho" id="NotasConselho" size="4" required>
                            <?php
                            $query = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='BD_PPIWOW' AND `TABLE_NAME`='NOTAS' AND `COLUMN_NAME` NOT IN('IDNOTA','IDDISCIPLINA','IDALUNO','NOME','OBSERVACOES','FALTAS')";
                            $resultado = mysqli_query($conn, $query);
                            if ($resultado) {
                                $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
                                foreach ($returned_rows as $row) {
                            ?>
                                    <option value="<?php echo $row["COLUMN_NAME"] ?>"> <?php echo $row["COLUMN_NAME"] ?> </option>
                            <?php
                                }
                            }
                            ?>
                        </select><br><br>

                        <input type="checkbox" id="checkAllConselho" name="checkAllConselho" value="checkAllConselho" onclick="SelectTodos('FormConselho', 'Conselho')">
                        <label for="checkAllConselho"> Selecionar Todos</label><br>

                        <?php
                        $query = "SELECT * FROM ALUNO WHERE IDTURMA = {$_SESSION['Turma']}";
                        $resultadoAluno = mysqli_query($conn, $query);
                        if ($resultadoAluno) {
                            $returned_rows = mysqli_fetch_all($resultadoAluno, MYSQLI_ASSOC);
                            foreach ($returned_rows as $row) {
                        ?>
                                <input type="checkbox" id="check<?php echo $row['NOME'] ?>" name="alunosConselho[]" value="<?php echo $row['IDALUNO'] ?>" onclick="handleCheckboxClick('FormConselho', 'Conselho')">
                                <label for="check<?php echo $row['NOME'] ?>"> <?php echo $row['NOME'] ?></label><br>
                        <?php
                            }
                        }
                        ?>

                        <input class="botao" type="submit" name="NotasConselhoSubmit" value="Gerar"><br>
                    </form>
                </div>
            </div>
        </div>
</body>

</html>