<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('Config.php');
include('Logout_Function.php');

if (!isset($_SESSION['Email'])) {
    logout();
}

date_default_timezone_set('America/Sao_Paulo');
$data_Atual = date('Y-m-d', time());

function isPrazoValid($prazo1, $prazo2, $currentDate)
{
    if (is_null($prazo1) && is_null($prazo2)) {
        return "NO_PRAZO_DEFINED";
    }
    if (!is_null($prazo1) && $currentDate <= $prazo1) {
        return "PRAZO1_VALID";
    }
    if (!is_null($prazo2) && (is_null($prazo1) || $currentDate > $prazo1) && $currentDate <= $prazo2) {
        return "PRAZO2_VALID";
    }
    return "PRAZO_EXPIRED";
}

function getPrazoStatus($conn, $documento)
{
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
    $instrucao->bind_param("s", $documento);
    $instrucao->execute();
    $resultado = $instrucao->get_result()->fetch_assoc();
    return [
        'status' => isPrazoValid($resultado["PRAZO1"], $resultado["PRAZO2"], $GLOBALS['data_Atual']),
        'prazo' => (!is_null($resultado["PRAZO1"]) && $GLOBALS['data_Atual'] <= $resultado["PRAZO1"]) ? $resultado["PRAZO1"] : $resultado["PRAZO2"]
    ];
}

function usuarioJaEnviouRecuperacao($conn, $iduser, $idDisciplina, $prazoFinal)
{
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ? AND DATA_ENVIO <= ?");
    $instrucao->bind_param("iis", $iduser, $idDisciplina, $prazoFinal);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    if ($instrucao->fetch()) {
        return $arquivo;
    }
    return false;
}

function removerArquivoRecuperacao($conn, $iduser, $idDisciplina)
{
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ?");
    $instrucao->bind_param("ii", $iduser, $idDisciplina);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);

    if ($instrucao->fetch() && $arquivo) {
        $caminho = "images_recuperacao/" . $arquivo;

        if (file_exists($caminho)) {
            unlink($caminho);
        }

        $instrucao->close();

        $deleteInstrucao = $conn->prepare("DELETE FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ?");
        $deleteInstrucao->bind_param("ii", $iduser, $idDisciplina);
        $deleteInstrucao->execute();
        $deleteInstrucao->close();

        echo "<div class='sucesso'>Arquivo removido com sucesso!</div>";
    } else {
        echo "<div class='erro'>Erro ao remover o arquivo.</div>";
    }
}

$prazoRecuperacao = getPrazoStatus($conn, 'Recuperacao_Paralela');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['removerArquivoRecuperacao'])) {
        removerArquivoRecuperacao($conn, $_SESSION["ID"], $_POST['idDisciplina']);
    } elseif (isset($_POST['RecuperacaoParalelaSubmit']) && isset($_FILES['Arquivo'])) {
        $idDisciplina = $_POST['idDisciplina'];
        $arquivoNome = basename($_FILES['Arquivo']['name']);
        $caminhoDestino = "images_recuperacao/" . $arquivoNome;

        if (move_uploaded_file($_FILES['Arquivo']['tmp_name'], $caminhoDestino)) {
            $stmt = $conn->prepare("INSERT INTO RECUPERACAO_PARALELA (IDUSER, IDDISCIPLINA, ARQUIVO, DATA_ENVIO) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $_SESSION["ID"], $idDisciplina, $arquivoNome, $data_Atual);
            $stmt->execute();
            $stmt->close();
            echo "<div class='sucesso'>Arquivo enviado com sucesso!</div>";
        } else {
            echo "<div class='erro'>Erro ao enviar o arquivo.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="stylesarquivosrecuperacao.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Recuperação Paralela / SGE</title>
</head>

<body>

    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>

    <h3>Recuperação Paralela</h3>
    <?php
    $instrucao = $conn->prepare("SELECT D.IDDISCIPLINA, D.NOME, D.IDTURMA FROM LECIONA L JOIN DISCIPLINA D ON L.IDDISCIPLINA = D.IDDISCIPLINA WHERE L.IDUSER = ?");
    $instrucao->bind_param("i", $_SESSION["ID"]);
    $instrucao->execute();
    $disciplinas = $instrucao->get_result();
    $disciplinascount = $disciplinas->num_rows;
    if ($disciplinascount > 0) {
        while ($disciplina = $disciplinas->fetch_assoc()) :
            $arquivoEnviado = usuarioJaEnviouRecuperacao($conn, $_SESSION["ID"], $disciplina['IDDISCIPLINA'], $prazoRecuperacao['prazo']);
            $instrucaoTurma = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = {$disciplina['IDTURMA']}");
            $instrucaoTurma->execute();
            $NumeroTurma = $instrucaoTurma->get_result();
            $NumeroTurma = $NumeroTurma->fetch_assoc()
    ?>
            <h4><?= $disciplina['NOME'] ?><?php echo ' Turma ' . $NumeroTurma['NUMERO'] ?></h4>
            <?php if ($arquivoEnviado) : ?>
                <div class="erro">
                    <p><strong>Você já enviou um documento para esta disciplina.</strong></p>
                </div>
                <form method="post";>
                    <input type="hidden" name="idDisciplina" value="<?= $disciplina['IDDISCIPLINA'] ?>">
                    <button type="submit" name="removerArquivoRecuperacao">Remover Arquivo</button>
                </form>
            <?php else : ?>
                <form enctype="multipart/form-data" method="post" style="display: flex; flex-direction: column; align-items: center;>
                    <input type="hidden" name="idDisciplina" value="<?= $disciplina['IDDISCIPLINA'] ?>">
                    <input type="file" name="Arquivo" required>
                    <button class="enviar" type="submit" name="RecuperacaoParalelaSubmit">Enviar</button>
                </form>
            <?php endif; ?>
            <hr class="linha">
        <?php endwhile; ?>
    <?php } else {
        echo "<p><div class='erro'><strong>Você não leciona nenhuma disciplina, portanto não precisa entregar esse arquivo.</strong></div></p>";
    }
    ?>
</body>

</html>