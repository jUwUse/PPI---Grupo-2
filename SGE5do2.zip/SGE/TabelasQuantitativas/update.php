<?php
include('../Config.php');

$regex = "/^(0|[1-9]\d*)(\.\d+)?$/";
if(preg_match($regex, $_POST["value"])) {
    if(strlen(substr(strrchr($_POST["value"], "."), 1)) > 1){
        $_POST["value"] = (string)round((double)$_POST["value"], 1, PHP_ROUND_HALF_UP);
    }
}

$InformacoesAluno = "SELECT * FROM NOTAS WHERE IDNOTA = '{$_POST["pk"]}'";
$resultadoAluno = $conn->query($InformacoesAluno);
$resultadoAluno = $resultadoAluno->fetch_assoc();

$query = "
 UPDATE NOTAS SET ".$_POST["name"]." = '".$_POST["value"]."' 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query);

if (isset($_POST["name"])) {
    $instrucaoSub = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE NOME = ?");
    $instrucaoSub->bind_param('s', $_POST['name']);
    $instrucaoSub->execute();
    $resultadoSub = $instrucaoSub->get_result();
    $quantiaSub = $resultadoSub->num_rows;

    if ($quantiaSub > 0 || $_POST['name'] == "GERAL_PRIMEIRO_SEMESTRE" || $_POST['name'] == "GERAL_SEGUNDO_SEMESTRE") {
        $fetched = $resultadoSub->fetch_assoc();  // Move fetch_assoc here
        if ($fetched['PERTENCE'] == "PRIMEIRO_SEMESTRE") {
            $soma = "GERAL_PRIMEIRO_SEMESTRE";
        }
        elseif ($fetched['PERTENCE'] == "SEGUNDO_SEMESTRE") {
            $soma = "GERAL_SEGUNDO_SEMESTRE";  // Corrected from "GERAL_PRIMEIRO_SEMESTRE"
        }

        $resultadoSubSegundoLegal = [];
        do {
            $resultadoSubSegundoLegal[] = $fetched;  // Include first fetched row
        } while ($fetched = $resultadoSub->fetch_assoc());

        foreach ($resultadoSubSegundoLegal as $row) {
            if (strtoupper($row['NOME']) == "GERAL") {
                $pertence = $row['PERTENCE'];
                continue;
            }
            else {
                $pertence = $row['PERTENCE'];
                $soma .= "+((".$row['NOME'].")*((".$row['PESO']."/100)))";
            }
        }

        $query = "
        UPDATE NOTAS SET ".$pertence."= ROUND(".eval($soma).",1)
        WHERE IDNOTA = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $_POST["pk"]);
        $stmt->execute();
    }
}



$query = "
 UPDATE NOTAS SET NOTA_FINAL = ROUND(((PRIMEIRO_SEMESTRE * 0.4) + (SEGUNDO_SEMESTRE * 0.6)),1) 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query); 

date_default_timezone_set('America/Sao_Paulo');
$date = date('d/m/Y G:i:s', time());
$string_date = (string)$date;

$query = "INSERT INTO HISTORICO_NOTAS(NOME, CONTEUDO, IDDISCIPLINA, DIA, ALUNO, COLUNA) VALUES('{$_SESSION['Nome']}','{$_POST['value']}',{$_GET['id']},'{$string_date}','{$resultadoAluno['NOME']}','{$_POST['name']}')";
mysqli_query($conn, $query);
?>
