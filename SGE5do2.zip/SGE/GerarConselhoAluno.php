<?php
error_reporting(E_ERROR);
include('Config.php');
include('Logout_Function.php');

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="stylesgerarconselhoaluno.css">
    <title>Material para Conselho de Classe</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>


    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
        <hr>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>



    <?php
    if (isset($_GET['id'])) {
        $i = 1;
    ?>
        <div class="container-fluid">
            <div class="row quadrado align-items-center">
                <div id="fullPageCarousel" class="carousel slide w-100 h-100" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php
                        $alunosSelecionados = $_GET['id']; // Vai retornar uma lista

                        foreach ($alunosSelecionados as $aluno) {
                            $selectAluno = $conn->prepare("SELECT * FROM ALUNO WHERE IDALUNO = $aluno");
                            $selectAluno->execute();
                            $resultadoAluno = $selectAluno->get_result();
                            $resultadoAluno = $resultadoAluno->fetch_assoc();

                            $selectTurma = $conn->prepare("SELECT * FROM TURMA INNER JOIN ALUNO ON TURMA.IDTURMA = ALUNO.IDTURMA WHERE ALUNO.IDALUNO = $aluno");
                            $selectTurma->execute();
                            $resultadoTurma = $selectTurma->get_result();
                            $resultadoTurma = $resultadoTurma->fetch_assoc();

                            $selectQual = $conn->prepare("SELECT * FROM DADOS_QUALITATIVOS WHERE IDALUNO = $aluno");
                            $selectQual->execute();
                            $resultadoQual = $selectQual->get_result();
                            $resultadoQual = $resultadoQual->fetch_assoc();

                            if ($i == 1) { //É necessário diferenciar o primeiro slide do resto, porque tem um elemento na classe do bootstrap chamado "active". Somente o primeiro slide pode ter ele.
                        ?>
                                <div class="carousel-item active h-100">
                                    <div class="d-flex justify-content-center align-items-center h-100">
                                        <div class="slide-content" style="font-size: 18px;">

                                            <h3><?php echo $resultadoAluno['NOME'] ?></h3>
                                            <p>Matrícula: <?php echo $resultadoAluno['MATRICULA'] ?>
                                                Turma: <?php echo $resultadoTurma['NUMERO'] ?>
                                                Histórico de Reprovação: <?php echo $resultadoQual['REPROVOU'] ?>
                                            <p>Notas abaixo de 5: </p>
                                            <?php
                                            $query = "SELECT {$_GET['tipo']}, IDDISCIPLINA FROM NOTAS WHERE IDALUNO = $aluno AND {$_GET['tipo']} < 5 AND {$_GET['tipo']} > 0";
                                            $resultadoNotas = mysqli_query($conn, $query);
                                            $returned_rowsNotas = mysqli_fetch_all($resultadoNotas, MYSQLI_ASSOC);

                                            foreach ($returned_rowsNotas as $Notas) {
                                                $selectDisc = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA ={$Notas['IDDISCIPLINA']}");
                                                $selectDisc->execute();
                                                $resultadoDisc = $selectDisc->get_result();
                                                $resultadoDisc = $resultadoDisc->fetch_assoc();

                                                echo "<p>" . $Notas[(string)$_GET['tipo']] . " em " . $resultadoDisc['NOME'] . "</p>";
                                            }
                                            ?>

                                            <p>Status de Moradia: <?php echo $resultadoQual['MORADIA'] ?></p>

                                            <p>Observações: </p>
                                            <?php
                                            $query = "SELECT OBSERVACOES, IDDISCIPLINA FROM NOTAS WHERE IDALUNO = $aluno AND {$_GET['tipo']} < 5 AND OBSERVACOES <> NULL";
                                            $resultadoNotas = mysqli_query($conn, $query);
                                            $returned_rowsNotas = mysqli_fetch_all($resultadoNotas, MYSQLI_ASSOC);

                                            foreach ($returned_rowsNotas as $Observacoes) {
                                                $selectDiscObs = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA ={$Observacoes['IDDISCIPLINA']}");
                                                $selectDiscObs->execute();
                                                $resultadoDiscObs = $selectDiscObs->get_result();
                                                $resultadoDiscObs = $resultadoDiscObs->fetch_assoc();

                                                echo "<p>" . $Observacoes['OBSERVACOES'] . " (" . $resultadoDiscObs['NOME'] . ")</p>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                $i++;
                            } else {
                            ?>
                                <div class="carousel-item h-100">
                                    <div class="d-flex justify-content-center align-items-center h-100">
                                        <div class="slide-content" style="font-size: 18px;">

                                            <h3><?php echo $resultadoAluno['NOME'] ?></h3>
                                            <p>Matrícula: <?php echo $resultadoAluno['MATRICULA'] ?>
                                                Turma: <?php echo $resultadoTurma['NUMERO'] ?>
                                                Histórico de Reprovação: <?php echo $resultadoQual['REPROVOU'] ?>
                                            <p>Notas abaixo de 5: </p>
                                            <?php
                                            $query = "SELECT {$_GET['tipo']}, IDDISCIPLINA FROM NOTAS WHERE IDALUNO = $aluno AND {$_GET['tipo']} < 5 AND {$_GET['tipo']} > 0";
                                            $resultadoNotas = mysqli_query($conn, $query);
                                            $returned_rowsNotas = mysqli_fetch_all($resultadoNotas, MYSQLI_ASSOC);

                                            foreach ($returned_rowsNotas as $Notas) {
                                                $selectDisc = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA ={$Notas['IDDISCIPLINA']}");
                                                $selectDisc->execute();
                                                $resultadoDisc = $selectDisc->get_result();
                                                $resultadoDisc = $resultadoDisc->fetch_assoc();

                                                echo "<p>" . $Notas[(string)$_GET['tipo']] . " em " . $resultadoDisc['NOME'] . "</p>";
                                            }
                                            ?>

                                            <p>Status de Moradia: <?php echo $resultadoQual['MORADIA'] ?></p>

                                            <p>Observações: </p>
                                            <?php
                                            $query = "SELECT OBSERVACOES, IDDISCIPLINA FROM NOTAS WHERE IDALUNO = $aluno AND {$_GET['tipo']} < 5 AND OBSERVACOES <> NULL";
                                            $resultadoNotas = mysqli_query($conn, $query);
                                            $returned_rowsNotas = mysqli_fetch_all($resultadoNotas, MYSQLI_ASSOC);

                                            foreach ($returned_rowsNotas as $Observacoes) {
                                                $selectDiscObs = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA ={$Observacoes['IDDISCIPLINA']}");
                                                $selectDiscObs->execute();
                                                $resultadoDiscObs = $selectDiscObs->get_result();
                                                $resultadoDiscObs = $resultadoDiscObs->fetch_assoc();

                                                echo "<p>" . $Observacoes['OBSERVACOES'] . " (" . $resultadoDiscObs['NOME'] . ")</p>";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            }
                        }
                        ?>
                    </div> <!-- Fecha a div inner -->
                </div>
            </div>
            <!-- Todo esse código embaixo é pra poder ir pro lado e tals -->
            <button class="carousel-control-prev" type="button" data-bs-target="#fullPageCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#fullPageCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    <?php
    }
    ?>
</body>

</html>