<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

$PossuiPermissao = "";
$query = "SELECT * FROM SETOR INNER JOIN TRABALHA ON SETOR.IDSETOR = TRABALHA.IDSETOR WHERE TRABALHA.IDUSER = '{$_SESSION['ID']}'";
$resultado2 = mysqli_query($conn, $query);
if ($resultado2) {
    $returned_rows = mysqli_fetch_all($resultado2, MYSQLI_ASSOC);
    foreach($returned_rows as $row) {
        $Unspaced = str_replace(' ', '_', (string)$row['NOME']);
        $PossuiPermissao .= " ".(string)$Unspaced." ";
    }
}
else {
    $PossuiPermissao = FALSE;
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="../stylestabquali.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabela Qualitativa / SGE</title>

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script> 
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap3-editable/js/bootstrap-editable.js"></script>
    
</head>
<body>
    
<div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>
<!-- Aqui vai ser a mais pura cópia. Tutorial abaixo, caso funcionar:
    https://www.youtube.com/watch?v=lkDO2xqbifE
-->
    <table id="sample_data" class="table table-bordered table-striped"> 
        <thead>
            <tr> 
                <th>NOME</th>
                <?php 
                    $query = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='BD_PPIWOW' AND `TABLE_NAME`='DADOS_QUALITATIVOS'";
                    $resultado = mysqli_query($conn, $query);
                    $numero = 1;
                    if ($resultado) {
                        $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
                        foreach($returned_rows as $row) {
                            if ($row['COLUMN_NAME'] != "IDDADOS_QUALITATIVOS" && $row['COLUMN_NAME'] != "IDSETOR" && $row['COLUMN_NAME'] != "IDALUNO" && $row['COLUMN_NAME'] != "NOME") {
                                echo "<th name='".$row['COLUMN_NAME']."' id='Coluna".$numero."'>".$row['COLUMN_NAME']."</th>";
                            }
                            $numero++;
                        }
                    }
                ?>
            </tr>
        </thead>
        <tbody id="employee_data"></tbody>
    </table>
</body>
</html>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
        function fetch_employee_data() {
            $.ajax({
                url:"/SGE/TabelasQualitativas/fetch.php",
                method:"POST",
                dataType:"json",
                success:function(data){
                    
                    for(var count = 0; count < data.length; count++) {
                        var html_data = '<tr><td>'+data[count].NOME+'</td>';
                        for (var addapted_count = 4; addapted_count <= Object.keys(data[0]).length; addapted_count++) {
                        // document.getElementById("Coluna"+addapted_count).getAttribute("name")
                            function porfavor(value) {
                                var location = document.getElementById("Coluna"+addapted_count).getAttribute("name");
                                return eval('data[count].'+location);
                            }
                            var locationForaDaFuncao = document.getElementById("Coluna"+addapted_count).getAttribute("name");

                            html_data += '<td data-name="'+locationForaDaFuncao+'" class="'+locationForaDaFuncao+'" data-type="text" data-pk="'+data[count].IDDADOS_QUALITATIVOS+'">'+porfavor(addapted_count)+'</td>';
                            
                        }
                        $('#employee_data').append(html_data);
                    }
                }
            })
        }
        fetch_employee_data();

        // Isso aqui funciona, o que tá embaixo

        for(var z = 1; z < document.getElementById('sample_data').rows[0].cells.length; z++) {
            <?php
            if($_SESSION['Tipo'] == 'ADM') {
                ?>    
                    $('#employee_data').editable({
                        container: 'body',
                        selector: 'td.'+document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                        url: "/SGE/TabelasQualitativas/update.php",
                        title: document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                        type: "POST",
                        dataType: 'json',

                        validate: function(value){
                            if($.trim(value) == ''){
                                return 'Este campo deve ser preenchido.';
                            }
                        }
                    });
                <?php
            }
            elseif($PossuiPermissao != FALSE && $PossuiPermissao != "") {
                ?>
                let texto = <?php echo json_encode($PossuiPermissao)?>;
                    if(texto.includes(document.getElementById("sample_data").rows[0].cells[z].innerHTML)) {
                        $('#employee_data').editable({
                            container: 'body',
                            selector: 'td.'+document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                            url: "/SGE/TabelasQualitativas/update.php",
                            title: document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                            type: "POST",
                            dataType: 'json',

                            validate: function(value){
                                if($.trim(value) == ''){
                                    return 'Este campo deve ser preenchido.';
                                }
                            }
                        });
                    }
                <?php
            }
            ?>
        }  
    });
</script>