<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

date_default_timezone_set('America/Sao_Paulo');
$data_12horas = date('m/d/Y h:i:s a', time());

function Adicionar($iduser, $conn, $tipo) {
    if ($tipo == "Plano de Trabalho") {
        if ((isset($_FILES['Foto']) == TRUE) && ($_FILES['Foto'] != NULL)) {
            $imagem = $_FILES['Foto']["name"];
            $extensoes_permitidas = array("jpg", "png", "jfif", "jpeg");
            if (in_array(strtolower(pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)), $extensoes_permitidas)) {
                move_uploaded_file($_FILES["Foto"]["tmp_name"], ("images_curso/".$_FILES["Foto"]["name"]));
                $instrucao = $conn->prepare("UPDATE CURSO SET FOTO = '$imagem' WHERE IDCURSO = LAST_INSERT_ID()"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->execute();
            }
            else {
                echo "<div class='erro'> Por motivos de segurança, arquivos .".pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)." não são permitidos. </div>";
                $instrucao = $conn->prepare("DELETE FROM CURSO WHERE IDCURSO = LAST_INSERT_ID()");    
                $instrucao->execute();
                return "Não funcionou.";
            }
        }
    }

    else if ($tipo == "Relatorio de Atividades") {
        if ((isset($_FILES['Foto']) == TRUE) && ($_FILES['Foto'] != NULL)) {
            $imagem = $_FILES['Foto']["name"];
            $extensoes_permitidas = array("jpg", "png", "jfif", "jpeg");
            if (in_array(strtolower(pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)), $extensoes_permitidas)) {
                move_uploaded_file($_FILES["Foto"]["tmp_name"], ("images_curso/".$_FILES["Foto"]["name"]));
                $instrucao = $conn->prepare("UPDATE CURSO SET FOTO = '$imagem' WHERE IDCURSO = LAST_INSERT_ID()"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->execute();
            }
            else {
                echo "<div class='erro'> Por motivos de segurança, arquivos .".pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)." não são permitidos. </div>";
                $instrucao = $conn->prepare("DELETE FROM CURSO WHERE IDCURSO = LAST_INSERT_ID()");    
                $instrucao->execute();
                return "Não funcionou.";
            }
        }
    }

    else {
        echo "Um erro desconhecido ocorreu.";
        return "não funcionou.";
    }
}
?>

<!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gerenciar Arquivos / SGE</title>
    </head>
    <body>
        <span>
            <?php
            if (isset($_POST['PlanoDeTrabalhoSubmit'])) { // Caso o formulário de professor seja enviado.
                $resultado_final_decisivo_mega_importante = Adicionar($_SESSION["ID"], $conn, "Plano de Trabalho");
            }
            if (isset($_POST['RelatorioDeAtividadesSubmit'])) { // Caso o formulário de professor seja enviado.
                $resultado_final_decisivo_mega_importante = Adicionar($_SESSION["ID"], $conn, "Relatorio de Atividades");
            }
            ?>
        </span>

        <?php
            $instrucao = $conn->prepare("SELECT * FROM PLANO_DE_TRABALHO WHERE IDUSER = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $_SESSION['ID']); //s=string, i=int, d=double
            $instrucao->execute();
            $resultadoPlano = $instrucao->get_result();
            $resultadoPlano = $resultadoPlano->fetch_assoc();
            if ($resultadoPlano == NULL) {
                ?>
                    <form enctype="multipart/form-data" id="PlanoCadastro" action="Arquivos.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                        <p> Seu plano de ensino ainda não foi registrado. Por favor, insira um arquivo até </p>
                        <input class="campo" type="file" id="PlanoDeTrabalhoInput" name="PlanoDeTrabalhoInput" required><br>
                        <input class="botao" type="submit" name="PlanoDeTrabalhoSubmit" value="Salvar Plano de Trabalho"><br>
                    </form>
                <?php
            }
            else {

            }

            $instrucao = $conn->prepare("SELECT * FROM RELATORIO_DE_ATIVIDADES WHERE IDUSER = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $_SESSION['ID']); //s=string, i=int, d=double
            $instrucao->execute();
            $resultadoAtividades = $instrucao->get_result();
            $resultadoAtividades = $resultadoAtividades->fetch_assoc();
            if ($resultadoPlano == NULL) {
                ?>
                    <form enctype="multipart/form-data" id="AtividadesCadastro" action="Arquivos.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                        <p> Seu plano de ensino ainda não foi registrado. Por favor, insira um arquivo até </p>
                        <input class="campo" type="file" id="RelatorioDeAtividadesInput" name="RelatorioDeAtividadesInput" required><br>
                        <input class="botao" type="submit" name="RelatorioDeAtividadesSubmit" value="Salvar Relatório de Atividades"><br>
                    </form>                
                <?php
            }
            else {

            }
        ?>
    </body>
</html>