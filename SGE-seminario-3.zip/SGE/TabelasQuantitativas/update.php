<?php
include('../Config.php');

$regex = "/^(0|[1-9]\d*)(\.\d+)?$/";
if(preg_match($regex, $_POST["value"])) {
    if(strlen(substr(strrchr($_POST["value"], "."), 1)) > 1){
        $_POST["value"] = (string)round((double)$_POST["value"], 1, PHP_ROUND_HALF_UP);
    }
}

$InformacoesAluno = "SELECT * FROM NOTAS WHERE IDNOTA = '{$_POST["pk"]}'";
$resultadoAluno = $conn->query($InformacoesAluno);
$resultadoAluno = $resultadoAluno->fetch_assoc();

$query = "
 UPDATE NOTAS SET ".$_POST["name"]." = '".$_POST["value"]."' 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query);

$query = "
 UPDATE NOTAS SET NOTA_FINAL = ROUND(((PRIMEIRO_SEMESTRE * 0.4) + (SEGUNDO_SEMESTRE * 0.6)),1) 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query); 

date_default_timezone_set('America/Sao_Paulo');
$date = date('m/d/Y h:i:s a', time());
$string_date = (string)$date;

$query = "INSERT INTO HISTORICO_NOTAS(NOME, CONTEUDO, IDDISCIPLINA, DIA, ALUNO, COLUNA) VALUES('{$_SESSION['Nome']}','{$_POST['value']}',{$_GET['id']},'{$string_date}','{$resultadoAluno['NOME']}','{$_POST['name']}')";
mysqli_query($conn, $query);
?>
