<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    include('../Config.php');
    include('../Logout_Function.php');
    include('../Verify_Cookies.php');
    
    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    if (isset($_SESSION['Turma']) == FALSE) {
        if (isset($_GET['id'])) {
            $_SESSION['Turma'] = $_GET['id'];
        }
        else {
            header("location: ../Home.php");
            exit();
        }
    }
    if (isset($_GET['disciplina']) == FALSE) {
        header("location: ../Home.php");
        exit();
    }

    $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ?");
    $instrucao->bind_param("i", $_GET['disciplina']); //s=string, i=int, d=double
    $instrucao->execute();
    $resultadoDisciplina = $instrucao->get_result();
    $resultadoDisciplina = $resultadoDisciplina->fetch_assoc();

    $instrucao = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?");
    $instrucao->bind_param("i", $_GET['id']); //s=string, i=int, d=double
    $instrucao->execute();
    $resultadoTurma = $instrucao->get_result();
    $resultadoTurma = $resultadoTurma->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">
    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Edições - <?php echo $resultadoDisciplina['NOME']?> - <?php echo $resultadoTurma['NUMERO']?> / SGE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesadicionarcursos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
<div id="SelectDoHistorico">
        <?php
        $numero1 = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM HISTORICO_NOTAS ORDER BY IDHISTORICO_NOTAS DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Nenhuma edição recente foi feita nesta disciplina.</div>";
        } 
        else {
            echo '<table><tr>';
                while ($numero1 <= $resultadoID["IDHISTORICO_NOTAS"]) {

                    $sql = $conn->prepare("SELECT * FROM HISTORICO_NOTAS WHERE IDHISTORICO_NOTAS = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                    $sql->bind_param("i", $numero1); //s=string, i=int, d=double
                    $sql->execute();
                    $resultadoverificacao = $sql->get_result();
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {   
                        if ($i<=2) {
                            echo '<td><div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . ' editou '.$resultadolista["COLUNA"].' do aluno '.$resultadolista["ALUNO"].' às '.$resultadolista["DIA"].'</p>
                                <p>' . $resultadolista["CONTEUDO"] . '</p>  
                                </div></td>';
                        }
                        else {
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . ' editou '.$resultadolista["COLUNA"].' do aluno '.$resultadolista["ALUNO"].' às '.$resultadolista["DIA"].'</p>
                                <p>' . $resultadolista["CONTEUDO"] . '</p>  
                                </div></td>';
                                $i = 0;
                        }
                    }
                    $numero1 += 1;
                    $i++;
                }
        }

            echo '</table>';
        ?>

    </div>

</body>
</html>