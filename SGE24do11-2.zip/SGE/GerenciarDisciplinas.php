<?php
error_reporting(E_ERROR);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    }
    else {
        header("location: Home.php");
        
        exit();
    }
}

$selectnumero = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
$selectnumero->bind_param("i", $_SESSION['Turma']); //s=string, i=int, d=double
$selectnumero->execute();
$resultadonumero = $selectnumero->get_result();
$resultadonumero = $resultadonumero->fetch_assoc();

function Adicionar($Nome, $ProfessorResponsável, $SESSION, $conn)
{
    $elementos = func_get_args();

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) { //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        } //Pode mudar o return para "echo" para testar mais visivelmente.
    };

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome de uma disciplina não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM DISCIPLINA WHERE NOME = ? AND IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("si", $Nome, $SESSION); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Uma disciplina com esse nome já existe nessa turma.</div>";
        return "não funcionou.";
    }

    $instrucao_disciplina = $conn->prepare("INSERT INTO DISCIPLINA(NOME, IDTURMA) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao_disciplina->bind_param("si", $Nome, $SESSION); //s=string, i=int, d=double
    $instrucao_disciplina->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = LAST_INSERT_ID()");
    $instrucao->execute();
    $resultado_disciplina = $instrucao->get_result();
    $resultado_disciplina = $resultado_disciplina->fetch_assoc();

    foreach ($_POST['ProfessorResponsavel'] as $item){
        $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $item); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc();

        $instrucao = $conn->prepare("INSERT INTO LECIONA(IDDISCIPLINA, IDUSER) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("ii", $resultado_disciplina['IDDISCIPLINA'], $resultado['IDUSER']); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
            return "não funcionou.";
        }
    }

    $query = "SELECT * FROM ALUNO WHERE IDTURMA = $SESSION";
    $resultado = mysqli_query($conn, $query);
    $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);

    foreach($returned_rows as $row) {
        $instrucao = $conn->prepare("INSERT INTO NOTAS(IDDISCIPLINA, IDALUNO, NOME) VALUES(?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("iis", $resultado_disciplina['IDDISCIPLINA'], $row['IDALUNO'], $row['NOME']); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
            return "não funcionou.";
        }
    }

    header("location: AdicionarDisciplinas.php?id=".$_SESSION['Turma']); 
}

function Reutilizar($Numero, $SESSION, $conn)
{
    $elementos = func_get_args();

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) { //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        } //Pode mudar o return para "echo" para testar mais visivelmente.
    };

    $instrucao = $conn->prepare("SELECT * FROM TURMA WHERE NUMERO = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("i", $Numero); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado_idturma = $instrucao->get_result();
    $resultado_idturma = $resultado_idturma->fetch_assoc();

    $numero = 0;
    $ultimoID = "SELECT * FROM DISCIPLINA ORDER BY IDDISCIPLINA DESC LIMIT 1";
    $resultadoIDDisciplina = $conn->query($ultimoID);
    $resultadoIDDisciplina = $resultadoIDDisciplina->fetch_assoc();
    while ($numero <= $resultadoIDDisciplina["IDDISCIPLINA"]) {
        $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDTURMA = ? and IDDISCIPLINA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("ii", $resultado_idturma['IDTURMA'], $numero); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado_disciplina = $instrucao->get_result();
        $resultado_disciplina = $resultado_disciplina->fetch_assoc();
        if ($resultado_disciplina['NOME'] != NULL) {
            $instrucao_disciplina = $conn->prepare("INSERT INTO DISCIPLINA(NOME, IDTURMA) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
            $instrucao_disciplina->bind_param("si", $resultado_disciplina['NOME'], $SESSION); //s=string, i=int, d=double
            $instrucao_disciplina->execute();

            /* ------------------------------ */

            $query = "SELECT * FROM ALUNO WHERE IDTURMA = $SESSION";
            $resultado = mysqli_query($conn, $query);
            $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);

            foreach($returned_rows as $row) {
                $instrucao = $conn->prepare("INSERT INTO NOTAS(IDDISCIPLINA, IDALUNO, NOME) VALUES(LAST_INSERT_ID(),?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("is", $row['IDALUNO'], $row['NOME']); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conn->affected_rows != 1) {
                    echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
                    return "não funcionou.";
                }
            }

            /* ------------------------------ */

            $numero2 = 0;
            $ultimoID2 = "SELECT * FROM LECIONA ORDER BY IDLECIONA DESC LIMIT 1";
            $resultadoIDLeciona = $conn->query($ultimoID2);
            $resultadoIDLeciona = $resultadoIDLeciona->fetch_assoc();
            while ($numero2 <= $resultadoIDLeciona['IDLECIONA']) {
                $instrucao_leciona = $conn->prepare("SELECT * FROM LECIONA WHERE IDDISCIPLINA = ? AND IDLECIONA = ?");
                $instrucao_leciona->bind_param("ii", $resultado_disciplina["IDDISCIPLINA"], $numero2);
                $instrucao_leciona->execute();
                $resultado_leciona = $instrucao_leciona->get_result();
                $resultado_leciona = $resultado_leciona->fetch_assoc();
                if ($resultado_leciona['IDUSER'] != NULL) {
                    $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA ORDER BY IDDISCIPLINA DESC LIMIT 1");
                    $instrucao->execute();
                    $resultado_disciplina2 = $instrucao->get_result();
                    $resultado_disciplina2 = $resultado_disciplina2->fetch_assoc();

                    $instrucao_leciona = $conn->prepare("INSERT INTO LECIONA(IDDISCIPLINA, IDUSER) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                    $instrucao_leciona->bind_param("ii", $resultado_disciplina2['IDDISCIPLINA'], $resultado_leciona['IDUSER']); //s=string, i=int, d=double
                    $instrucao_leciona->execute();
                    if ($conn->affected_rows != 1) {
                        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
                        return "não funcionou.";
                    }
                }
                $numero2++;
            }
        }
        $numero++;

    }

    echo '<script> window.location.href = "/SGE/GerenciarDisciplinas.php?id='.$_SESSION['Turma'].'"; </script>';
    return "Funcionou.";
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Disciplinas / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        window.onmousedown = function (e) {
            var el = e.target;
            if (el.tagName.toLowerCase() == 'option' && el.closest('select').hasAttribute('multiple')) {
                e.preventDefault();

                // toggle selection
                if (el.hasAttribute('selected')) el.removeAttribute('selected');
                else el.setAttribute('selected', '');

                // hack to correct buggy behavior
                var select = el.parentNode.cloneNode(true);
                el.parentNode.parentNode.replaceChild(select, el.parentNode);
            }
        }
    </script>

</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarCursos.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
        <div class="voltar">
            <button type="button" data-bs-toggle="modal" data-bs-target="#ReutilizarDisciplinas">Reutilizar Disciplinas</button>

            <!-- Modal -->
            <div class="modal fade" id="ReutilizarDisciplinas" tabindex="-1" aria-labelledby="ReutilizarDisciplinasLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Reutilizar Disciplinas</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Selecione a turma cujas matérias você deseja reutilizar.</p><br>
                        <form enctype="multipart/form-data" id="ReutilizarCadastro" action="GerenciarDisciplinas.php" method="POST" style="text-align: left; display: block;" autocomplete="off">
                            <select name="TurmaSelecionadaParaDisciplinas" id="TurmaSelecionadaParaDisciplinas" size="4" required>
                            <?php 
                                $numero = 1;
                                $ultimoID = "SELECT * FROM TURMA ORDER BY IDTURMA DESC LIMIT 1";
                                $resultadoID = $conn->query($ultimoID);
                                $resultadoID = $resultadoID->fetch_assoc();
                                while ($numero <= $resultadoID["IDTURMA"]) {
                                    $instrucao = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?");
                                    $instrucao->bind_param("i", $numero);
                                    $instrucao->execute();
                                    $resultado_turma_option = $instrucao->get_result();
                                    $resultado_turma_option = $resultado_turma_option->fetch_assoc();
                                    if ($resultado_turma_option != NULL) {
                                        ?>
                                            <option value="<?php echo $resultado_turma_option["NUMERO"]?>"> <?php echo $resultado_turma_option["NUMERO"]?> </option>
                                        <?php
                                    }
                                    $numero++;
                                }
                            ?>
                            </select><br><br>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <input class="botao" type="submit" name="DisciplinaReutilizarSubmit" value="Pronto"><br>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <span>
        <?php
        if (isset($_POST['DisciplinaReutilizarSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Reutilizar($_POST['TurmaSelecionadaParaDisciplinas'], $_SESSION['Turma'], $conn);
            //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        }
        if (isset($_POST['DisciplinaCadastroSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Adicionar($_POST['NomeDisciplina'], @$_POST['ProfessorReponsavel'], $_SESSION['Turma'], $conn);
            //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        }
        ?>
    </span>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <div>
                <p><b>Cadastrar Disciplinas</b></p>
                <p><b>Turma <?php echo $resultadonumero["NUMERO"] ?></b></p>

                <form enctype="multipart/form-data" id="DisciplinaCadastro" action="GerenciarDisciplinas.php" method="POST" style="text-align: left; display: block;" autocomplete="off">
                    <label for="NomeDisciplina">Nome da Disciplina:</label><br>
                    <input class="campo" type="text" id="NomeDisciplina" name="NomeDisciplina" value="<?php echo @$_POST['NomeDisciplina']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                    <label for="ProfessorReponsavel">Professores Responsáveis:</label><br>
                    <select name="ProfessorResponsavel[]" id="ProfessorResponsavel" multiple="multiple" required>
                        <?php 
                            $numero = 1;
                            $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
                            $resultadoID = $conn->query($ultimoID);
                            $resultadoID = $resultadoID->fetch_assoc();
                            while ($numero <= $resultadoID["IDUSER"]) {
                                $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE IDUSER = ?");
                                $instrucao->bind_param("i", $numero);
                                $instrucao->execute();
                                $resultado_professores_option = $instrucao->get_result();
                                $resultado_professores_option = $resultado_professores_option->fetch_assoc();
                                if ($resultado_professores_option != NULL) {
                                    ?>
                                        <option value="<?php echo $resultado_professores_option["NOME"]?>"> <?php echo $resultado_professores_option["NOME"]?> </option>
                                    <?php
                                }
                                $numero++;
                            }
                        ?>
                    </select>

                    <input class="botao" type="submit" name="DisciplinaCadastroSubmit" value="Cadastrar Disciplina"><br>
                </form>
            </div>
        </div>
    </div>

    <div id="SelectDasDisciplinas">
        <?php
        $numero1 = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM DISCIPLINA ORDER BY IDDISCIPLINA DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Você não possui nenhuma disciplina cadastrada. Clique no botão do menu lateral para adicionar.</div>";
        } 
        else {
            echo '<table><tr>';
                while ($numero1 <= $resultadoID["IDDISCIPLINA"]) {

                    $sql = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ? AND IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                    $sql->bind_param("ii", $numero1, $_SESSION['Turma']); //s=string, i=int, d=double
                    $sql->execute();
                    $resultadoverificacao = $sql->get_result();
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {   
                        echo '</tr><tr>';
                        echo '<td><div class="quadrado"> 
                            <p>' . $resultadolista["NOME"] . '</p>  
                            <p> <a href="AlterarDisciplinas.php?id='. $resultadolista["IDDISCIPLINA"] .'">Editar</a> 
                            <a href="DeletarDisciplinas.php?id='. $resultadolista["IDDISCIPLINA"] .'" onclick="return confirm(\'Tem certeza que quer excluir essa disciplina?\');">Deletar</a> </p>' . '</p> </td></div>';
                    }
                    $numero1 += 1;
                }
        }

            echo '</table>';
        ?>

    </div>

</body>

</html>