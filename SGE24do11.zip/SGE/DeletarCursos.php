<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $query = "SELECT * FROM ALUNO INNER JOIN TURMA ON ALUNO.IDTURMA = TURMA.IDTURMA WHERE TURMA.IDCURSO = $IDARemover";
            $resultado = mysqli_query($conn, $query);
            $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
            foreach($returned_rows as $row) {
                $instrucao = $conn->prepare("DELETE FROM NOTAS WHERE IDALUNO = ?"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $row["IDALUNO"]); //s=string, i=int, d=double
                $instrucao->execute();
            }

            $query = "SELECT * FROM DISCIPLINA INNER JOIN TURMA ON DISCIPLINA.IDTURMA = TURMA.IDTURMA WHERE TURMA.IDCURSO = $IDARemover";
            $resultado = mysqli_query($conn, $query);
            $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
            foreach($returned_rows as $row) {
                $instrucao = $conn->prepare("DELETE FROM LECIONA WHERE IDDISCIPLINA = ?"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $row["IDDISCIPLINA"]); //s=string, i=int, d=double
                $instrucao->execute();

                $instrucao = $conn->prepare("DELETE FROM DISCIPLINA WHERE IDDISCIPLINA = ?"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $row["IDDISCIPLINA"]); //s=string, i=int, d=double
                $instrucao->execute();
            }

            $query = "SELECT * FROM ALUNO INNER JOIN TURMA ON ALUNO.IDTURMA = TURMA.IDTURMA WHERE TURMA.IDCURSO = $IDARemover";
            $resultado = mysqli_query($conn, $query);
            $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
            foreach($returned_rows as $row) {
                $instrucao = $conn->prepare("DELETE FROM ALUNO WHERE IDALUNO = ?"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $row["IDALUNO"]); //s=string, i=int, d=double
                $instrucao->execute();
            }
        
            $instrucao = $conn->prepare("DELETE FROM TURMA WHERE IDCURSO = ?");
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();

            $instrucao = $conn->prepare("DELETE FROM CURSO WHERE IDCURSO = ?");
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();
            header("location: GerenciarCursos.php");
        }
    }


?>