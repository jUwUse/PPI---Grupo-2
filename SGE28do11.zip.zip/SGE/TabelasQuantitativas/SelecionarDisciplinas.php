<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

unset($_SESSION["Turma"]);

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    } else {
        header("location: Home.php");

        exit();
    }
}

function Editavel($numero, $turma, $user, $conn)
{
    $valor = 1;
    $ultimoID = "SELECT * FROM LECIONA ORDER BY IDLECIONA DESC LIMIT 1";
    $resultadoID = $conn->query($ultimoID);
    $resultadoID = $resultadoID->fetch_assoc();

    $TipoUsuario = "SELECT * FROM USUARIO WHERE IDUSER = $user";
    $TipoUsuarioResultado = $conn->query($TipoUsuario);
    $TipoUsuarioResultado = $TipoUsuarioResultado->fetch_assoc();

    while ($valor <= $resultadoID['IDLECIONA']) {
        $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA INNER JOIN LECIONA ON DISCIPLINA.IDDISCIPLINA = LECIONA.IDDISCIPLINA WHERE DISCIPLINA.IDTURMA = ? AND DISCIPLINA.IDDISCIPLINA = ?");
        $instrucao->bind_param("ii", $turma, $numero); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $Informacoes = $resultado->fetch_assoc();

        if (($Informacoes != NULL && $Informacoes['IDUSER'] == $user) || ($TipoUsuarioResultado['TIPO'] == "ADM")) {
            echo "<script> document.getElementById('Editavel" . ($numero) . "').innerHTML += '<p> Editavel </p>'; </script>";
        }
        $valor++;
        $numero++;
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="../stylesselecionardisciplinas.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabelas Quantitativas / Selecionar Disciplinas / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div id="SelectDosCursos">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM DISCIPLINA ORDER BY IDDISCIPLINA DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Nenhuma disciplina foi cadastrada nessa turma.</div>";
        } else {
            echo '<table><tr>';
            while ($numero <= $resultadoID["IDDISCIPLINA"]) {
                $sql = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $sql->bind_param("i", $numero); //s=string, i=int, d=double
                $sql->execute();
                $resultadoverificacao = $sql->get_result();
                $resultadolista = $resultadoverificacao->fetch_assoc();
                foreach ($resultadoverificacao as $j) {
                    if ($resultadolista['IDTURMA'] == $_SESSION['Turma']) {
                        if ($i <= 3) {
                            echo '<td>
                                    <div class="quadrado" onclick="window.location.href = \'/SGE/TabelasQuantitativas/Tabelas.php?id=' . $_SESSION['Turma'] . '&disciplina=' . $resultadolista['IDDISCIPLINA'] . '\'">
                                    <i class="uil uil-edit"></i>
                                        <span style="margin-left: 8px;"></span>
                                    <b>' . $resultadolista["NOME"] . '</b>
                                    </div>
                                    </td>';
                            Editavel($numero, $_SESSION['Turma'], $_SESSION["ID"], $conn);

                            /* Editavel($numero, $turma, $user, $conn */
                        } else {
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado" onclick="window.location.href = \'/SGE/TabelasQuantitativas/Tabelas.php?id=' . $_SESSION['Turma'] . '&disciplina=' . $resultadolista['IDDISCIPLINA'] . '\'"> 
                                <i class="uil uil-edit"></i>
                                    <span style="margin-left: 8px;"></span>
                                <b>' . $resultadolista["NOME"] . '</b></div>
                                </td>';
                            Editavel($numero, $_SESSION['Turma'], $_SESSION["ID"], $conn);
                            $i = 0;
                        }
                        $i++;
                    }
                }
                $numero += 1;
            }
        }


        echo '</table>';
        ?>

    </div>

</body>

</html>