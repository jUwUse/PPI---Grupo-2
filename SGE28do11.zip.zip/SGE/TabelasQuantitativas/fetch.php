<?php
include('../Config.php');

$id = @$_GET['id'];

$query = "SELECT * FROM NOTAS WHERE IDDISCIPLINA = $id";
$result = mysqli_query($conn, $query);
$output = array();
while($row = mysqli_fetch_assoc($result))
{
 $output[] = $row;
}
echo json_encode($output);
?>