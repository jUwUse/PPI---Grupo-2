<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

function Adicionar($Nome, $Responsavel, $Matriz, $conn)
{
    $elementos = func_get_args();

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM SETOR WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Uma atividade setorial com esse nome já existe no sistema.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("INSERT INTO SETOR(NOME, MATRIZ) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("ss", $Nome, $Matriz); //s=string, i=int, d=double
    $instrucao->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.1</div>";
        return "não funcionou.";
    }

    $ultimoID = "SELECT * FROM SETOR ORDER BY IDSETOR DESC LIMIT 1";
    $resultadoIDSetor = $conn->query($ultimoID);
    $resultadoIDSetor = $resultadoIDSetor->fetch_assoc();

    $Unspaced = str_replace(' ', '_', $Nome);
    $instrucao = $conn->prepare("ALTER TABLE DADOS_QUALITATIVOS ADD COLUMN {$Unspaced} VARCHAR(100) DEFAULT NULL;");
    $instrucao->execute();

    foreach ($_POST['SetorResponsavel'] as $item) {
        $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $item); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc();

        $instrucao = $conn->prepare("INSERT INTO TRABALHA(IDSETOR, IDUSER) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("ss", $resultadoIDSetor['IDSETOR'], $resultado['IDUSER']); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.1</div>";
            return "não funcionou.";
        }
    }

    $query = "SELECT * FROM ALUNO";
    $resultado2 = mysqli_query($conn, $query);
    if ($resultado2) {
        $returned_rows = mysqli_fetch_all($resultado2, MYSQLI_ASSOC);

        foreach ($returned_rows as $row) {
            $instrucao = $conn->prepare("SELECT * FROM DADOS_QUALITATIVOS WHERE IDALUNO = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $row['IDALUNO']); //s=string, i=int, d=double
            $instrucao->execute();
            $resultado = $instrucao->get_result();
            $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
            if ($resultado == NULL) {
                $instrucao = $conn->prepare("INSERT INTO DADOS_QUALITATIVOS(IDALUNO, NOME) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("is", $row['IDALUNO'], $row['NOME']); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conn->affected_rows != 1) {
                    echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.3</div>";
                    return "não funcionou.";
                }
            }
        }
    }

    // -------------------------

    $_SESSION["SetorCadastrado"] = $Nome;
    header("location: /SGE/GerenciarSetores.php?");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesadicionarsetores.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Adicionar Setores / SGE</title>

    <script>
        window.onmousedown = function(e) {
            var el = e.target;
            if (el.tagName.toLowerCase() == 'option' && el.closest('select').hasAttribute('multiple')) {
                e.preventDefault();

                // toggle selection
                if (el.hasAttribute('selected')) el.removeAttribute('selected');
                else el.setAttribute('selected', '');

                // hack to correct buggy behavior
                var select = el.parentNode.cloneNode(true);
                el.parentNode.parentNode.replaceChild(select, el.parentNode);
            }
        }
    </script>

</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarSetores.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>
    <span>
        <?php
        if (isset($_POST['SetorCadastroSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Adicionar($_POST['NomeSetor'], $_POST['SetorResponsavel'], $_POST['MatrizSetor'], $conn);
            //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        }
        ?>
    </span>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <div>
                <p><b>Cadastrar Atividade Setorial</b></p>
                <form enctype="multipart/form-data" id="SetorCadastro" action="AdicionarSetores.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                    <label for="NomeSetor">Nome da Atividade:</label><br>
                    <input class="campo" type="text" id="NomeSetor" name="NomeSetor" value="<?php echo @$_POST['NomeSetor']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                    <label for="SetorResponsavel">Usuários Responsáveis:</label><br>
                    <div class="dropdown">
                        <button class="dropbtn">Selecione</button>
                        <select class="dropdown-content" name="SetorResponsavel[]" id="SetorResponsavel" multiple="multiple" required>
                            <?php
                            $numero = 1;
                            $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
                            $resultadoID = $conn->query($ultimoID);
                            $resultadoID = $resultadoID->fetch_assoc();
                            while ($numero <= $resultadoID["IDUSER"]) {
                                $instrucao = $conn->prepare("SELECT * FROM USUARIO WHERE IDUSER = ?");
                                $instrucao->bind_param("i", $numero);
                                $instrucao->execute();
                                $resultado_editores_option = $instrucao->get_result();
                                $resultado_editores_option = $resultado_editores_option->fetch_assoc();
                                if ($resultado_editores_option != NULL) {
                            ?>
                                    <option value="<?php echo $resultado_editores_option["NOME"] ?>"> <?php echo $resultado_editores_option["NOME"] ?> </option>
                            <?php
                                }
                                $numero++;
                            }
                            ?>
                        </select><br>
                    </div>
                    <br>
                    <label for="MatrizSetor">Setor Matricial:</label><br>
                    <input class="campo" type="text" id="MatrizSetor" name="MatrizSetor" value="<?php echo @$_POST['MatrizSetor']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                    <input class="botao" type="submit" name="SetorCadastroSubmit" value="Criar Setor"><br>
                </form>
            </div>
        </div>
    </div>

</body>

<!-- Fatal error: Uncaught mysqli_sql_exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'VARCHAR(100) DEFAULT NULL' at line 1 in C:\xampp\htdocs\SGE\AdicionarSetores.php:50 Stack trace: #0 C:\xampp\htdocs\SGE\AdicionarSetores.php(50): mysqli->prepare('ALTER TABLE DAD...') #1 C:\xampp\htdocs\SGE\AdicionarSetores.php(120): Adicionar('Acompanhamento ...', Array, 'CAE', Object(mysqli)) #2 {main} thrown in C:\xampp\htdocs\SGE\AdicionarSetores.php on line 50

</html>