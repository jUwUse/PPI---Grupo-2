<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $instrucao = $conn->prepare("SELECT * FROM SETOR WHERE IDSETOR = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();
            $resultado = $instrucao->get_result();
            $resultado = $resultado->fetch_assoc();
            $resultadoNomeSetor = $resultado['NOME'];

            $Unspaced = str_replace(' ', '_', $resultadoNomeSetor);
            $Unspaced_and_unaccented = strtr(utf8_decode($Unspaced), utf8_decode('àáâãäçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ'), 'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY');

            $instrucao = $conn->prepare("ALTER TABLE DADOS_QUALITATIVOS DROP COLUMN {$Unspaced_and_unaccented}");
            $instrucao->execute();
            $instrucao = $conn->prepare("DELETE FROM TRABALHA WHERE IDSETOR = '{$IDARemover}'");
            $instrucao->execute();
            $instrucao = $conn->prepare("DELETE FROM SETOR WHERE IDSETOR = '{$IDARemover}'");
            $instrucao->execute();

            header("location: GerenciarSetores.php");
        }
    }


?>