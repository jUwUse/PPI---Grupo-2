<?php

include ('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}
else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

$IDSelecionado = (int)$_GET['id'];

$instrucao = $conn->prepare("SELECT * FROM CURSO WHERE IDCURSO = $IDSelecionado"); //s=string, i=int, d=double
$instrucao->execute();
$resultado = $instrucao->get_result();
$resultadolista = $resultado->fetch_assoc();

for ($i = 1; $i <= $resultadolista['DURACAO']; $i++) {

    $instrucao = $conn->prepare("INSERT INTO TURMA(IDCURSO, ANO) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("ii", $IDSelecionado, $i); //s=string, i=int, d=double
    $instrucao->execute();

    $instrucao = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = LAST_INSERT_ID()"); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultadoturma = $resultado->fetch_assoc();
    $numero = strval($resultadoturma['ANO']) . strval($resultadoturma['IDCURSO']);

    // UPDATE SETORUSUARIO SET ATIVIDADES = ? WHERE IDSETORUSUARIO = $id
    // INSERT INTO TURMA(NUMERO) VALUES(?)
    $instrucao = $conn->prepare("UPDATE TURMA SET NUMERO = ? WHERE IDTURMA = LAST_INSERT_ID()"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("s", $numero); //s=string, i=int, d=double
    $instrucao->execute();
}

header("location: /SGE/GerenciarCursos.php");

?>