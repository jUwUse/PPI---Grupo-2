<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $sql = "SELECT * FROM USUARIO WHERE IDUSER = $IDARemover";
            $resultadoverificacao = $conn->query($sql);
            $resultadolista = $resultadoverificacao->fetch_assoc();

            if ($resultadolista['TIPO'] == "ADM") {
                ?>

                <script>
                    alert("Você não pode excluir um administrador!");
                    history.back();
                </script>

                <?php
            }

            else if ($resultadolista['TIPO'] == "Professor") {
                $instrucao = $conn->prepare("DELETE FROM PROFESSOR WHERE IDPROF = ?");
                $instrucao->bind_param("s", $IDARemover); //s=string, i=int, d=double
                $instrucao->execute();

                $instrucao = $conn->prepare("DELETE FROM USUARIO WHERE IDUSER = ?");
                $instrucao->bind_param("s", $IDARemover); //s=string, i=int, d=double
                $instrucao->execute();
                header("location: GerenciarUsuários.php");
            }
            
            else if ($resultadolista['TIPO'] == "Setor") {
                $instrucao = $conn->prepare("DELETE FROM SETORUSUARIO WHERE IDSETORUSUARIO = ?");
                $instrucao->bind_param("s", $IDARemover); //s=string, i=int, d=double
                $instrucao->execute();

                $instrucao = $conn->prepare("DELETE FROM USUARIO WHERE IDUSER = ?");
                $instrucao->bind_param("s", $IDARemover); //s=string, i=int, d=double
                $instrucao->execute();
                header("location: GerenciarUsuários.php");
            }
        }
    }


?>