<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesgerenciarcursos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Cursos / SGE</title>
</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href="/SGE/AdicionarCursos.php" class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Usuário</span>
            </a><br>
        </div>
    </div>

    <div id="SelectDosCursos">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM CURSO ORDER BY IDCURSO DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Você não possui nenhum curso cadastrado. Clique no botão do menu lateral para adicionar.</div>";
        } else {
            echo '<table><tr>';
            while ($numero <= $resultadoID["IDCURSO"]) {
                $sql = "SELECT * FROM CURSO WHERE IDCURSO = $numero";
                $resultadoverificacao = $conn->query($sql);
                $resultadolista = $resultadoverificacao->fetch_assoc();
                $numero += 1;

                foreach ($resultadoverificacao as $j) {
                    if ($i<=2) {
                        echo '<td>
                            <div class="quadrado"> <p onClick="location.href = \'Curso.php?id='. $resultadolista["IDCURSO"] .'\'">' . $resultadolista["NOME"] . '</p> <p> <a href="AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' . '</p> </div>
                            </td>'; 
                    }
                    
                    else {       
                        echo '</tr><tr>';
                        echo '<td><div class="quadrado"> <p onClick="location.href = \'Curso.php?id='. $resultadolista["IDCURSO"] .'\'">' . $resultadolista["NOME"] . '</p> <p> <a href="/SGE/AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' .'</p> </div></td>'; 
                        $i = 0;
                    }
                    $i ++;
                }
            }
            echo '</table>';
        }
        ?>

    </div>

</body>

</html>