<?php
    include ("Config.php");
    include ("Logout_Function.php");

    $IDSelecionado = (int)$_GET['id'];

    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $IDSelecionado";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistacurso = $resultadoverificacao->fetch_assoc();

    $sql = "SELECT * FROM TURMA WHERE IDCURSO = $IDSelecionado";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistacurso = $resultadoverificacao->fetch_assoc();

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }
    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CURSO <?php echo @$resultadolistacurso['NOME'];?> / SGE</title>
</head>
<body>
    <div id="SelectDasTurmas">
        <?php
            $numero = 1;
            $i = 0;
            $ultimoID = "SELECT * FROM CURSO WHERE IDCURSO = $IDSelecionado";
            $resultadoID = $conn->query($ultimoID);
            $resultadoID = $resultadoID->fetch_assoc();

            echo '<table><tr>';
            while ($numero <= $resultadoID["DURACAO"]) {
                $sql = "SELECT * FROM TURMA WHERE IDCURSO = $IDSelecionado AND ANO = $numero";
                $resultadoverificacao = $conn->query($sql);
                $resultadolista = $resultadoverificacao->fetch_assoc();
                $numero += 1;
                        
                foreach ($resultadoverificacao as $j) {
                        
                    if ($i<=2) {
                        echo '<td>
                            <div> <p onClick="location.href = \'Turma.php?id='. $resultadolista["IDTURMA"] .'\'">'. $resultadolista['NUMERO'] .'</p></div>
                            </td>'; 
                    }
                        
                    else {       
                        echo '</tr><tr>';
                        echo '<td><div> <p onClick="location.href = \'Turma.php?id='. $resultadolista["IDTURMA"] .'\'">'. $resultadolista['NUMERO'] .'</p></div></td>'; 
                        $i = 0;
                    }
                    $i ++;
                        
                }  
            }
            echo '</table>';
        ?>

        <a href="/SGE/AdicionarCursos.php">Adicionar Cursos</a>

    </div>
</body>
</html>