<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $query = "SELECT * FROM SETOR_SETORUSUARIO INNER JOIN SETOR ON SETOR_SETORUSUARIO.IDSETOR = SETOR.IDSETOR WHERE SETOR_SETORUSUARIO.IDSETOR = $IDARemover";
            $resultado = mysqli_query($conn, $query);
            $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
            foreach($returned_rows as $row) {
                $instrucao = $conn->prepare("DELETE FROM SETOR_SETORUSUARIO WHERE IDSETOR = ?"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $row["IDSETOR"]); //s=string, i=int, d=double
                $instrucao->execute();
            }

            $instrucao = $conn->prepare("DELETE FROM SETOR WHERE IDSETOR = ?");
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();
            header("location: GerenciarSetores.php");
        }
    }


?>