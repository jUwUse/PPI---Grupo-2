<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="../stylesgerenciarcursos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabelas Qualitativas / Selecionar Setor / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function Redireciona(numero) {
            window.location.href = "/SGE/TabelasQualitativas/Tabelas.php?id="+numero;
        }
    </script>
</head>

<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div id="SelectDosSetores">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM SETOR ORDER BY IDSETOR DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Nenhum setor foi cadastrado ainda.</div>";
        } 
        else {
            echo '<table><tr>';
                while ($numero <= $resultadoID["IDSETOR"]) {
                    $sql = "SELECT * FROM SETOR WHERE IDSETOR = $numero";
                    $resultadoverificacao = $conn->query($sql);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {
                        if ($i<=3) {
                            echo '<td>
                                <div class="quadrado" onClick="Redireciona('.$numero.')"> 
                                <p>' . $resultadolista["NOME"] . '</p> 
                                <p id="Setor'.$numero.'"></p>
                                </td>'; 
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado" onClick="Redireciona('.$numero.')"> 
                            <p>' . $resultadolista["NOME"] . '</p> 
                            <p id="Setor'.$numero.'"></p>
                            </div></td>'; 
                            $i = 0;
                        }
                        $i ++;
                    }
                    $numero += 1;
                }
        }

            echo '</table>';
        ?>

    </div>

</body>

</html>