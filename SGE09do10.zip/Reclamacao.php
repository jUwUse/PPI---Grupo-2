<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

function Reclamar($Nome, $Mensagem)
{
    include('ConfigMailer.php');

    $mail->addAddress(USERNAME);
    $mail->addReplyTo(REPLY_TO, REPLY_TO_NAME);
    $mail->IsHTML(true);

    $titulo = "Reclamacao de ";
    $titulo .= $Nome;
    $corpo = $Mensagem;

    $mail->Subject = $titulo;
    $mail->Body = $corpo;
    $mail->AltBody = $corpo;

    if (!$mail->send()) {
        echo "<div class='erro'>Houve um erro com o envio da reclamação. Tente novamente mais tarde. </div>";
        return "não funcionou.";
    } else {
        echo "<div class='recenviada'>Sua reclamação foi enviada com sucesso!</div>";
        return "funcionou.";
    }
}

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    header("location: Login.php");
    exit();
}

if (isset($_GET['Logout'])) {
    logout();
}

if (isset($_POST['ReclamacaoSubmit'])) {
    if (empty($_POST['ReclamacaoInput'])) {
        echo "<div class='erro'>Digite sua reclamação</div>";
    } else {
        $resultado_por_favor = Reclamar($_SESSION["Nome"], $_POST['ReclamacaoInput']);
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="stylesreclamacao.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Reclamacao / SGE</title>
</head>

    <div class="slidebar">
        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="sair">
            <a href="?Logout" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-signout"></i>
                <span style="margin-left: 8px;">Sair</span>
            </a><br>
        </div>

    </div>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">
            <div>
                <form action="Reclamacao.php" id="FormularioDeReclamacao" method="post" style="display: block;" autocomplete="off">
                    <p> <b>Digite sua reclamação no campo abaixo: </b></p>

                        <textarea class="digitar" id="ReclamacaoInput" name="ReclamacaoInput" rows="4" cols="50" value="<?php echo @$_POST['ReclamacaoInput']; ?>"></textarea><br>
                    
                    <input class="botao" type="submit" name="ReclamacaoSubmit" value="Enviar"><br>
                </form>
            </div>
        </div>
    </div>

    </body>

</html>