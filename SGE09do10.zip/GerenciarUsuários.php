<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

$Aplicado = @$_GET['FiltroSubmit'];
$lista = array(@$_GET['NomeFiltro'], @$_GET['TipoFiltro'], @$_GET['FiltroSIAPE'], @$_GET['FiltroSetor'], @$_GET['FiltroEmail']);
$lista_pos = array("NOME", "TIPO", "SIAPE", "ATIVIDADES", "EMAIL");

function SomenteNulo($lista) { //Verifica se todos os parâmetros estão vazios. Isso é, o filtro foi solicitado, mas sem selecionar nada.
    foreach ($lista as $i) {
        if ($i !== "" && $i !== NULL) {
            return false;
        }
    }
    return true;
}

function GerarSQL($lista, $lista_pos, $numero) { //Prepara o select com base nos parâmetros.
    if ($lista[1] == "Setor" && ($lista[2] != NULL && $lista[2] != "") || ($lista[1] == "Professor" && ($lista[3] != NULL && $lista[3] != "")) || (($lista[2] != NULL || $lista[2] != "") && ($lista[3] != NULL || $lista[3] != ""))) {
        return "erro.";
    }
    else {
        $primeiro_a_entrar = 0;
        if ($lista[3] != NULL && $lista[3] != "") {
            $sql = "SELECT * FROM USUARIO INNER JOIN SETORUSUARIO ON USUARIO.IDUSER = SETORUSUARIO.IDSETORUSUARIO WHERE USUARIO.IDUSER = $numero AND ";
            for ($z = 0; $z < sizeof($lista); $z++) {
                if ($lista[$z] != NULL && $lista[$z] != "") {
                    if ($primeiro_a_entrar == 0) {
                        $sql .= $lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                        $primeiro_a_entrar++;
                    }
                    else {
                        $sql .= "AND ".$lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                    }
                }
            }
            $sql .= ";";
        }
        else if ($lista[2] != NULL && $lista[2] != "") {
            $sql = "SELECT * FROM USUARIO INNER JOIN PROFESSOR ON USUARIO.IDUSER = PROFESSOR.IDPROF WHERE USUARIO.IDUSER = $numero AND ";
            for ($z = 0; $z < sizeof($lista); $z++) {
                if ($lista[$z] != NULL && $lista[$z] != "") {
                    if ($primeiro_a_entrar == 0) {
                        $sql .= $lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                        $primeiro_a_entrar++;
                    }
                    else {
                        $sql .= "AND ".$lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                    }
                }
            }
            $sql .= ";";
        }
        else {
            $sql = "SELECT * FROM USUARIO WHERE IDUSER = $numero AND ";
            for ($z = 0; $z < sizeof($lista); $z++) {
                if ($lista[$z] != NULL && $lista[$z] != "") {
                    if ($primeiro_a_entrar == 0) {
                        $sql .= $lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                        $primeiro_a_entrar++;
                    }
                    else {
                        $sql .= "AND ".$lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                    }
                }
            }
            $sql .= ";";
        }

        return $sql;
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="stylesgerenciarusuarios.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Usuários / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href="/SGE/AdicionarUsuários.php" class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Usuários</span>
            </a><br>
        </div>
    </div>

    <div class="CampodeFiltro">
        <form action="" class="FormulariodeFiltro" method="GET" >
            <label for="NomeFiltro">Nome do Usuário:</label><br>
            <input class="campo" type="text" id="NomeFiltro" name="NomeFiltro" value="<?php echo @$_GET['NomeFiltro']; ?>"><br>
            <span class="Botoes">
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#OpcoesOcultas" >
                    Mais opções
                </button>

                <button class="btn btn-light" type="button" onClick="location.href='/SGE/GerenciarUsuários.php'">
                    Limpar Filtro
                </button>

                <input class="btn btn-light" type="submit" name="FiltroSubmit" value="Aplicar">
            </span>

            <div class="collapse" id="OpcoesOcultas" style="margin-top: 10px;">
                <hr>
                <div class="d-inline-flex gap-5">
                    <span>
                        <input type="radio" id="TipoProfessor" name="TipoFiltro" value="Professor" <?php if(@isset($_GET['TipoFiltro']) == TRUE && @$_GET['TipoFiltro'] == "Professor") echo ' checked="checked"'?>>
                        <label for="TipoProfessor"> Professor </label><br>
                        <input type="radio" id="TipoSetor" name="TipoFiltro" value="Setor" <?php if(@isset($_GET['TipoFiltro']) == TRUE && @$_GET['TipoFiltro'] == "Setor") echo ' checked="checked"'?>>
                        <label for="TipoSetor"> Membro de Setor </label><br>
                        <input type="radio" id="TipoADM" name="TipoFiltro" value="ADM" <?php if(@isset($_GET['TipoFiltro']) == TRUE && @$_GET['TipoFiltro'] == "ADM") echo ' checked="checked"'?>>
                        <label for="TipoADM"> Administrador </label><br>
                    </span>

                    <span>
                        <label for="FiltroSIAPE">SIAPE:</label><br>
                        <input class="campoextra" type="number" id="FiltroSIAPE" name="FiltroSIAPE" value="<?php echo @$_GET['FiltroSIAPE']; ?>"><br>
                    </span>

                    <span>
                        <label for="FiltroSetor">Setor:</label><br>
                        <input class="campoextra" type="text" id="FiltroSetor" name="FiltroSetor" value="<?php echo @$_GET['FiltroSetor']; ?>"><br>
                    </span>

                    <span>
                        <label for="FiltroEmail">Email:</label><br>
                        <input class="campoextra" type="text" id="FiltroEmail" name="FiltroEmail" value="<?php echo @$_GET['FiltroEmail']; ?>"><br>
                    </span>
                </div>
            </div>
        </form>
        <hr>
    </div>

    <div id="SelectDosClientes">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM USUARIO ORDER BY IDUSER DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        echo '<table><tr>';

        if (somenteNulo($lista) == true || $Aplicado == NULL) {
            while ($numero <= $resultadoID["IDUSER"]) {
                $sql = "SELECT * FROM USUARIO WHERE IDUSER = $numero";
                $resultadoverificacao = $conn->query($sql);
                $resultadolista = $resultadoverificacao->fetch_assoc();
                $numero += 1;

                foreach ($resultadoverificacao as $j) {

                    if ($i <= 3) {
                        echo '<td>
                                <div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div>
                                </td>';
                    } else {
                        echo '</tr><tr>';
                        echo '<td><div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="/SGE/AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div></td>';
                        $i = 0;
                    }
                    $i++;
                }
            }
        }

        else {
            if (GerarSQL($lista, $lista_pos, $numero) == "erro.") {
                echo "Essa combinação de filtros não é possível.";
            }
            else {
                while ($numero <= $resultadoID["IDUSER"]) {
                    $funcaoDeFiltro = GerarSQL($lista, $lista_pos, $numero);
                    $resultadoverificacao = $conn->query($funcaoDeFiltro);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
                    $numero += 1;
                    foreach ($resultadoverificacao as $j) {

                        if ($i <= 3) {
                            echo '<td>
                                    <div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div>
                                    </td>';
                        } else {
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> <p> <b>' . $resultadolista["NOME"] . '</p> <p>' . $resultadolista["TIPO"] . '</p> <p>' . $resultadolista["EMAIL"] . '<p> <a href="/SGE/AlterarUsuários.php?id=' . $resultadolista["IDUSER"] . '">Editar</a> <a href="DeletarUsuários.php?id=' . $resultadolista["IDUSER"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse usuário?\')";>Deletar</a> </p></b>' . '</p> </div></td>';
                            $i = 0;
                        }
                        $i++;
                    }
                }
            }
        }
        echo '</table>';
        ?>

    </div>

</body>

</html>