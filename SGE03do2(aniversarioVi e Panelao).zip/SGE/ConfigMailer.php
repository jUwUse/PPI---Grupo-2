<?php
    define('MAILHOST', 'smtp.gmail.com'); // Protocolo de Transferência de Correio Simples do Google, é um dos protocolos que vimos nas aulas do George.
    define('USERNAME', 'Gustavotrouxudo@gmail.com'); //Email temporário kkk
    define('PASSWORD', 'siiy gknx whzs yyfo'); //APP password do Google, do email Gustavotrouxudo@gmail.com
    define('SEND_FROM', 'Gustavotrouxudo@gmail.com');
    define('SEND_FROM_NAME', 'Sistema de Gestao de Estudantes');
    define('REPLY_TO', 'Gustavotrouxudo@gmail.com');
    define('REPLY_TO_NAME', 'SGE');

    //https://www.youtube.com/watch?v=fSfNTACbplA
    // ^ Explica cada uma das coisas, embora a gente não tenha um email próprio do site.

    use PHPMAILER\PHPMAILER\Exception;
    use PHPMAILER\PHPMAILER\PHPMailer;
    use PHPMAILER\PHPMAILER\SMTP;

    require 'PHPMAILER\src\Exception.php';
    require 'PHPMAILER\src\PHPMailer.php';
    require 'PHPMAILER\src\SMTP.php';

    $mail = new PHPMailer(true);
    $mail->isSMTP();

    $mail->SMTPAuth = true; //Permite usar nosso login para enviar o email.
    $mail->Host = MAILHOST;
    $mail->Username = USERNAME;
    $mail->Password = PASSWORD;

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; //Adiciona uma camada de criptografia (STARTTLS) ao processo de envio de email.
    $mail->Port = 587; //Por padrão, parece que a porta tá como 25, tanto que tava dando um erro pra mim por causa disso. Atualmente, o ideal é 587, ou em alguns casos 465.
    $mail->setfrom(SEND_FROM, SEND_FROM_NAME);
?>