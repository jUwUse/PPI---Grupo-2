<?php
include('../Config.php');

$query = "SELECT * FROM DADOS_QUALITATIVOS";
$result = mysqli_query($conn, $query);
$output = array();
while($row = mysqli_fetch_assoc($result))
{
 $output[] = $row;
}
echo json_encode($output);
?>