<?php
    error_reporting(E_ALL ^ E_DEPRECATED);
    include ('Config.php');
    include('Logout_Function.php');

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }
    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Cursos / SGE</title>
</head>
<body>
    <div id="SelectDosCursos">
        <?php
            $numero = 1;
            $i = 0;
            $ultimoID = "SELECT * FROM CURSO ORDER BY IDCURSO DESC LIMIT 1";
            $resultadoID = $conn->query($ultimoID);
            $resultadoID = $resultadoID->fetch_assoc();
            if ($resultadoID == NULL) {
                echo "Você não possui nenhum curso cadastrado. Clique no botão abaixo para adicionar.";
            }
            else {
                echo '<table><tr>';
                while ($numero <= $resultadoID["IDCURSO"]) {
                    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $numero";
                    $resultadoverificacao = $conn->query($sql);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
                    $numero += 1;
                        
                    foreach ($resultadoverificacao as $j) {
                        
                        if ($i<=2) {
                            echo '<td>
                                <div> <p>' . $resultadolista["NOME"] . '</p> <p> <a href="AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'">Deletar</a> </p>' . '</p> </div>
                                </td>'; 
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div> <p>' . $resultadolista["NOME"] . '</p> <p> <a href="/SGE/AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'">Deletar</a> </p>' .'</p> </div></td>'; 
                            $i = 0;
                        }
                        $i ++;
                        
                    }  
                }
                echo '</table>';
            }
        ?>

        <a href="/SGE/AdicionarCursos.php">Adicionar Cursos</a>

    </div>
    
</body>
</html>