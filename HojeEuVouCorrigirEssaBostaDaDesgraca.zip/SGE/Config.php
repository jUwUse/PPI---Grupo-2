<?php
    session_start();

    define('DB_SERVER' , ':3307');
    define('DB_NAME', 'BD_PPIWOW');
    define('DB_USERNAME', 'user26');
    define('DB_PASSWORD', '');

    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    /* 

    if ($conn == true) {
        echo "boa";
    }
        
    */
?>



