<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    }
    else {
        header("location: Home.php");
        
        exit();
    }
}

$selectnumero = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
$selectnumero->bind_param("i", $_SESSION['Turma']); //s=string, i=int, d=double
$selectnumero->execute();
$resultadonumero = $selectnumero->get_result();
$resultadonumero = $resultadonumero->fetch_assoc();

function Adicionar($Foto, $Nome, $Matricula, $SESSION, $conn)
{
    $elementos = func_get_args();

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) { //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        } //Pode mudar o return para "echo" para testar mais visivelmente.
    };

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }
    if (strlen((string)$Matricula) != 10) {
        echo "<div class='erro'>A matrícula deve ter 10 caracteres.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM ALUNO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Um aluno com esse nome já existe no sistema.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("INSERT INTO ALUNO(NOME, MATRICULA, IDTURMA) VALUES(?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("sii", $Nome, $Matricula, $SESSION); //s=string, i=int, d=double
    $instrucao->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }

    if ($Foto != NULL) {
        if ((isset($_FILES['Foto']) == TRUE) && ($_FILES['Foto'] != NULL)) {
            $imagem = $_FILES['Foto']["name"];
            $extensoes_permitidas = array("jpg", "png", "jfif", "jpeg");
            if (in_array(strtolower(pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)), $extensoes_permitidas)) {
                move_uploaded_file($_FILES["Foto"]["tmp_name"], ("images_aluno/".$_FILES["Foto"]["name"]));
                $instrucao = $conn->prepare("UPDATE ALUNO SET FOTO = '$imagem' WHERE IDALUNO = LAST_INSERT_ID()"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->execute();
            }
            else {
                echo "<div class='erro'> Por motivos de segurança, arquivos .".pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)." não são permitidos. </div>";
                $instrucao = $conn->prepare("DELETE FROM ALUNO WHERE IDALUNO = LAST_INSERT_ID()");    
                $instrucao->execute();
                return "Não funcionou.";
            }
        }
    }

    /* -------------------------------------- */

    $ultimoID = "SELECT * FROM ALUNO ORDER BY IDALUNO DESC LIMIT 1";
    $resultadoID = $conn->query($ultimoID);
    $resultadoID = $resultadoID->fetch_assoc();

    $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("i", $SESSION); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc();

    $query = "SELECT * FROM DISCIPLINA WHERE IDTURMA = $SESSION";
    $resultado = mysqli_query($conn, $query);
        $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);

        foreach($returned_rows as $row) {
            $instrucao = $conn->prepare("INSERT INTO NOTAS(IDDISCIPLINA, IDALUNO, NOME) VALUES(?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
            $instrucao->bind_param("iis", $row['IDDISCIPLINA'], $resultadoID['IDALUNO'], $resultadoID['NOME']); //s=string, i=int, d=double
            $instrucao->execute();
            if ($conn->affected_rows != 1) {
                echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
                return "não funcionou.";
            }
        }

    $instrucao = $conn->prepare("INSERT INTO DADOS_QUALITATIVOS(NOME, IDALUNO) VALUES(?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("si", $Nome, $resultadoID['IDALUNO']); //s=string, i=int, d=double
    $instrucao->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }
    

    /* -------------------------------------- */

    $_SESSION["AlunoCadastrado"] = $Nome;
    header("location: Turma.php?id=".$_SESSION['Turma']);
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesadicionaralunos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Adicionar Alunos / SGE</title>
</head>

<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarCursos.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>
    <span>
        <?php
        if (isset($_POST['AlunoCadastroSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Adicionar($_POST['Foto'], $_POST['NomeAluno'], $_POST['MatriculaAluno'], $_SESSION['Turma'], $conn);
            //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        }
        ?>
    </span>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <div>
                <p><b>Cadastrar Aluno - Turma <?php echo $resultadonumero["NUMERO"] ?></b></p></b></p>
                <form enctype="multipart/form-data" id="AlunoCadastro" action="AdicionarAlunos.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                    <label for="NomeAluno">Nome:</label><br>
                    <input class="campo" type="text" id="NomeAluno" name="NomeAluno" value="<?php echo @$_POST['NomeAluno']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                    <label for="MatriculaAluno">Matrícula</label><br>
                    <input class="campo" type="number" id="MatriculaAluno" name="MatriculaAluno" value="<?php echo @$_POST['MatriculaAluno']; ?>" required><br>

                    <label for="Foto">Foto de Usuário:</label><br>
                    <input class="campo" type="file" id="Foto" name="Foto" value="<?php echo @$_FILES['Foto']['name']; ?>"><br>

                    <input class="botao" type="submit" name="AlunoCadastroSubmit" value="Cadastrar Aluno"><br>
                </form>
            </div>
        </div>
    </div>

</body>

</html>