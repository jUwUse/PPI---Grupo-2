<?php
error_reporting(E_ERROR);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="stylesgerenciardisciplinas.css">
    <title>Sobre Nós / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div style="padding-top: 50px; color: white; align-items: center; width: 50%; margin: auto; text-align: center;">
        <h1><b>Sobre Nós</b><hr></h1>
        <p> Uma plataforma acadêmico-profissional exclusiva para o IFFAR-FW,<br>dedicada a tornar o seu trabalho mais prático.</p>
        <br>
        <br>
    </div>

    <div style="color: white; margin-right: 50%; text-align: center">
        <h2><b>Sobre o Sistema</b></h2>
        <div style="text-align: justify; text-justify: inter-word; padding-left: 10%;">
            <p> A organização de dados estudantis é crucial para assegurar que os processos acadêmicos fluem sem problemas. No entanto, apesar de diversos sistemas web terem sido testados para garantir tal eficiência, parece que sempre apresentam falhas. Por quê?</p>
    </div>

    <div style="color: white; margin-right: -200%; text-align: center">
        <h2><b>Quem Somos</b></h2>
        <div style="text-align: justify; text-justify: inter-word">
            <p> </p>
    </div>
</body>
</html>