<?php
    require("./fpdf185/fpdf.php");
    include("./config.php");

    // Informações do Aluno
    $IDAEditar = (int)$_GET['id'];
    $sql = "SELECT * FROM ALUNO WHERE IDALUNO = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistapreenche = $resultadoverificacao->fetch_assoc();

    //Informações da Turma
    

    //Informações da Disciplina

    //Informações das Notas

    $pdf = new FPDF("L", "mm", "A4");

    $pdf->AddPage();
    $pdf->SetFont("Arial", "B", "10");

    $pdf->Cell(71, 10, "Desemprenho Escolar do(a) ". strtoupper($resultadolistapreenche["NOME"]) . " (". $resultadolistapreenche["MATRICULA"]. ")", 0, 1);

    $pdf->Cell(80, 6, "Disciplina", 1, 0, "C");
    $pdf->Cell(40, 6, "Nota", 1, 0, "C");
    $pdf->Cell(40, 6, "Faltas", 1, 0, "C");

    $pdf->Output();

?>