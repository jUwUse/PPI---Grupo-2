<?php
error_reporting(E_ALL ^ E_DEPRECATED); //Erros depreciados significam que há uma maneira mais aceita de fazer, mas não são necessariamente errados. Para mostrar esses erros, só apaga essa linha.

include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

function cadastro($Nome, $Email, $Senha, $SenhaConfirmada, $SIAPE, $Atividades, $Tipo, $conn) {
    /* -----------------Verificação----------------------- */

    $elementos = func_get_args(); // Basicamente, bota todos os argumentos da função numa lista.
    // print_r($elementos); // Printa os argumentos para verificar se está funcionando.

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) { //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        } //Pode mudar o return para "echo" para testar mais visivelmente.
    };

    $Email = filter_var($Email, FILTER_SANITIZE_EMAIL); //Remove caracteres indesejados do email
    if (filter_var($Email, FILTER_VALIDATE_EMAIL) != TRUE) { //Verifica se o email tá na estrutura certa
        echo "<div class='erro'>O Email inserido não é válido.</div>";
        return "não funcionou.";
    }

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }

    if (strlen((string)$Email) > 255) {
        echo "<div class='erro'>O email não pode ter mais de 255 caracteres.</div>";
        return "não funcionou.";
    }

    if (($SIAPE != NULL) && (strlen((string)$SIAPE) != 7)) {
        echo "<div class='erro'>O SIAPE deve ter 7 dígitos.</div>";
        return "não funcionou.";
    }

    if (strlen((string)$Senha) > 30) {
        echo "<div class='erro'>A senha não pode ter mais de 30 caracteres.</div>";
        return "não funcionou.";
    } else if (strlen((string)$Senha) < 8) {
        echo "<div class='erro'>Crie uma senha de, no mínimo, 8 caracteres.</div>";
        return "não funcionou.";
    }

    if ($SenhaConfirmada != $Senha) {
        echo "<div class='erro'>O campo de confirmar senha não bate com a senha original.</div>";
        return "não funcionou.";
    }

    if ($SIAPE != NULL && $Atividades != NULL) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }

    // Quando trabalhando com banco de dados, parece que é bom usar instruções preparadas (para evitar problemas de segurança)
    $instrucao = $conn->prepare("SELECT EMAIL FROM USUARIO WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Email); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Este email já existe no sistema.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Este nome já existe no sistema.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT SIAPE FROM PROFESSOR WHERE SIAPE = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("i", $SIAPE); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Este SIAPE já existe no sistema.</div>";
        return "não funcionou.";
    }

    $Senha_Encriptada = password_hash($Senha, PASSWORD_DEFAULT);

    /* -----------------Cadastro--------------------------- */

    $instrucao = $conn->prepare("INSERT INTO USUARIO(NOME, SENHA, EMAIL, TIPO) VALUES(?,?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("ssss", $Nome, $Senha_Encriptada, $Email, $Tipo); //s=string, i=int, d=double
    $instrucao->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    } 
    else {
        if ($Tipo == "Professor") {
            $instrucao = $conn->prepare("INSERT INTO PROFESSOR(IDPROF, SIAPE) VALUES(LAST_INSERT_ID(), ?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
            $instrucao->bind_param("i", $SIAPE); //s=string, i=int, d=double
            $instrucao->execute();
            if ($conn->affected_rows != 1) {
                echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
                return "não funcionou.";
            }
        } 
        else if ($Tipo == "Setor") {
            $instrucao = $conn->prepare("INSERT INTO SETORUSUARIO(IDSETORUSUARIO, ATIVIDADES) VALUES(LAST_INSERT_ID(), ?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
            $instrucao->bind_param("s", $Atividades); //s=string, i=int, d=double
            $instrucao->execute();
            if ($conn->affected_rows != 1) {
                echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
                return "não funcionou.";
            }
        }
        else if ($Tipo != "ADM"){
            echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
            return "não funcionou.";
        }

        if ((isset($_FILES['Foto'.$Tipo]) == TRUE) && ($_FILES['Foto'.$Tipo] != NULL)) {
            $imagem = $_FILES['Foto'.$Tipo]["name"];
            if (strtolower(pathinfo($_FILES["Foto".$Tipo]["name"], PATHINFO_EXTENSION)) == ("jpg" || "jpeg" || "png" || "jfif")) {
                move_uploaded_file($_FILES["Foto".$Tipo]["tmp_name"], ("images_user/".$_FILES["Foto".$Tipo]["name"]));
                $instrucao = $conn->prepare("UPDATE USUARIO SET FOTO = '$imagem' WHERE IDUSER = LAST_INSERT_ID()"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->execute();
            }
        }

        $_SESSION["UsuarioCadastrado"] = $Nome;
        header("location: /SGE/GerenciarUsuários.php");
        return "funcionou.";
    }
}
?>

<script>
    function FormHide(tipo) {
        if (tipo == "professor") {
            document.getElementById("SignUpFormSetor").style.display = "none";
            document.getElementById("SignUpFormADM").style.display = "none";

            if (document.getElementById("SignUpFormProfessor").style.display != "block") {
                document.getElementById("SignUpFormProfessor").style.display = "block";
            }
        } else if (tipo == "setor") {
            document.getElementById("SignUpFormProfessor").style.display = "none";
            document.getElementById("SignUpFormADM").style.display = "none";

            if (document.getElementById("SignUpFormSetor").style.display != "block") {
                document.getElementById("SignUpFormSetor").style.display = "block";
            }
        } else if (tipo == "ADM") {
            document.getElementById("SignUpFormProfessor").style.display = "none";
            document.getElementById("SignUpFormSetor").style.display = "none";

            if (document.getElementById("SignUpFormADM").style.display != "block") {
                document.getElementById("SignUpFormADM").style.display = "block";
            }
        }
    }
</script>

</script>

<script>
    function FormHide(tipo) {
        const botaoum = document.querySelector('.botaoum');
        const botaodois = document.querySelector('.botaodois');
        const botaotres = document.querySelector('.botaotres');


        botaoum.classList.remove('clicar', 'descer');
        botaodois.classList.remove('clicar', 'descer');
        botaotres.classList.remove('clicar', 'descer');


        if (tipo == "professor") {
            document.getElementById("SignUpFormSetor").style.display = "none";
            document.getElementById("SignUpFormADM").style.display = "none";
            document.getElementById("SignUpFormProfessor").style.display = "block";
            botaoum.classList.add('clicar');
            botaoum.classList.remove('descer', 'descerdois');
            botaodois.classList.add('descer');
            botaotres.classList.add('descerdois');
        } else if (tipo == "setor") {
            document.getElementById("SignUpFormProfessor").style.display = "none";
            document.getElementById("SignUpFormADM").style.display = "none";
            document.getElementById("SignUpFormSetor").style.display = "block";
            botaodois.classList.add('clicar');
            botaodois.classList.remove('descer', 'descerdois');
            botaoum.classList.remove('descerdois');
            botaoum.classList.add('descer');
            botaotres.classList.add('descerdois');
        } else if (tipo == "ADM") {
            document.getElementById("SignUpFormProfessor").style.display = "none";
            document.getElementById("SignUpFormSetor").style.display = "none";
            document.getElementById("SignUpFormADM").style.display = "block";
            botaotres.classList.add('clicar');
            botaotres.classList.remove('descer', 'descerdois');
            botaoum.classList.add('descerdois');
            botaodois.classList.add('descer');
        }
    }
</script>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesadicionarusuarios.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Adicionar Usuários / SGE</title>

</head>

<body>
    <span>

        <?php

        if (isset($_POST['ProfessorSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = cadastro($_POST['NomeProfessor'], $_POST['EmailProfessor'], $_POST['SenhaProfessor'], $_POST['senhaProfessorConfirmar'], $_POST['SIAPEProfessor'], NULL, "Professor", $conn);
            // function cadastro($Nome, $Email, $Senha, $SenhaConfirmada, $SIAPE, $Atividades, $Tipo) {
        }

        if (isset($_POST['SetorUserSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = cadastro($_POST['nomeSetor'], $_POST['EmailSetor'], $_POST['senhaSetor'], $_POST['senhaSetorConfirmar'], NULL, $_POST['atividadeSetor'], "Setor", $conn);
        }

        if (isset($_POST['ADMUserSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = cadastro($_POST['nomeADM'], $_POST['EmailADM'], $_POST['senhaADM'], $_POST['senhaADMConfirmar'], NULL, NULL, "ADM", $conn);
        }

        ?>
    </span>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarUsuários.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div>
        <div>
            <button class="botaoum clicar" type="button" onclick="FormHide('professor')">Professor</button>
            <button class="botaodois" type="button" onclick="FormHide('setor')">Setor</button>
            <button class="botaotres" type="button" onclick="FormHide('ADM')">Administrador</button>
            <div>

                <div class="container-fluid">
                    <div class="row quadrado align-items-center">

                        <div>
                            <p><b>Cadastrar Usuário</b></p>
                            <form enctype="multipart/form-data" id="SignUpFormProfessor" action="AdicionarUsuários.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                                <label for="NomeProfessor">Nome Completo:</label><br>
                                <input class="campo" type="text" id="NomeProfessor" name="NomeProfessor" value="<?php echo @$_POST['NomeProfessor']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                                <label for="EmailProfessor">Email</label><br>
                                <input class="campo" type="email" id="EmailProfessor" name="EmailProfessor" value="<?php echo @$_POST['EmailProfessor']; ?>" required><br>

                                <label for="SenhaProfessor">Senha:</label><br>
                                <input class="campo" type="password" id="SenhaProfessor" name="SenhaProfessor" value="<?php echo @$_POST['SenhaProfessor']; ?>" required><br>

                                <label for="senhaProfessorConfirmar">Confirmar Senha</label><br>
                                <input class="campo" type="password" id="senhaProfessorConfirmar" name="senhaProfessorConfirmar" value="<?php echo @$_POST['senhaProfessorConfirmar']; ?>" required><br>

                                <label for="SIAPEProfessor">Matrícula SIAPE:</label><br>
                                <input class="campo" type="number" id="SIAPEProfessor" name="SIAPEProfessor" value="<?php echo @$_POST['SIAPEProfessor']; ?>" required><br>

                                <label for="FotoProfessor">Foto de Usuário:</label><br>
                                <input class="campo" type="file" id="Foto" name="FotoProfessor" value="<?php echo @$_POST['FotoProfessor']; ?>"><br>

                                <input class="botao" type="submit" name="ProfessorSubmit" value="Cadastrar"><br>

                            </form>
                        </div>

                        <div>
                            <form enctype="multipart/form-data" id="SignUpFormSetor" action="AdicionarUsuários.php" method="post" style="text-align: left; display: none;" autocomplete="off">
                                <label for="nomeSetor">Nome Completo:</label><br>
                                <input class="campo" type="text" id="nomeSetor" name="nomeSetor" value="<?php echo @$_POST['nomeSetor']; ?>" required><br>

                                <label for="EmailSetor">Email</label><br>
                                <input class="campo" type="email" id="EmailSetor" name="EmailSetor" value="<?php echo @$_POST['EmailSetor']; ?>" required><br>

                                <label for="senhaSetor">Senha:</label><br>
                                <input class="campo" type="password" id="senhaSetor" name="senhaSetor" value="<?php echo @$_POST['senhaSetor']; ?>" required><br>

                                <label for="senhaSetorConfirmar">Confirmar Senha</label><br>
                                <input class="campo" type="password" id="senhaSetorConfirmar" name="senhaSetorConfirmar" value="<?php echo @$_POST['senhaSetorConfirmar']; ?>" required><br>

                                <label for="atividadeSetor">Atividade de Acompanhamento</label><br>
                                <input class="campo" type="text" id="atividadeSetor" name="atividadeSetor" value="<?php echo @$_POST['atividadeSetor']; ?>" required><br>

                                <label for="FotoSetor">Foto de Usuário:</label><br>
                                <input class="campo" type="file" id="FotoSetor" name="FotoSetor" value="<?php echo @$_POST['FotoSetor']; ?>"><br>

                                <input class="botao" type="submit" name="SetorUserSubmit" value="Cadastrar"><br>
                            </form>
                        </div>

                        <div>
                            <form enctype="multipart/form-data" id="SignUpFormADM" action="AdicionarUsuários.php" method="post" style="text-align: left; display: none;" autocomplete="off">
                                <label for="nomeADM">Nome Completo:</label><br>
                                <input class="campo" type="text" id="nomeADM" name="nomeADM" value="<?php echo @$_POST['nomeADM']; ?>" required><br>

                                <label for="EmailADM">Email</label><br>
                                <input class="campo" type="email" id="EmailADM" name="EmailADM" value="<?php echo @$_POST['EmailADM']; ?>" required><br>

                                <label for="senhaADM">Senha:</label><br>
                                <input class="campo" type="password" id="senhaADM" name="senhaADM" value="<?php echo @$_POST['senhaADM']; ?>" required><br>

                                <label for="senhaADMConfirmar">Confirmar Senha</label><br>
                                <input class="campo" type="password" id="senhaADMConfirmar" name="senhaADMConfirmar" value="<?php echo @$_POST['senhaADMConfirmar']; ?>" required><br>

                                <label for="FotoADM">Foto de Usuário:</label><br>
                                <input class="campo" type="file" id="FotoADM" name="FotoADM" value="<?php echo @$_POST['FotoADM']; ?>"><br>

                                <input class="botao" type="submit" name="ADMUserSubmit" value="Cadastrar"><br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

</body>

</html>