<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $query = "UPDATE EVENTO SET PRAZO1 = NULL, PRAZO2 = NULL WHERE IDEVENTO = '{$IDARemover}'";
            mysqli_query($conn, $query);

            header("location: /SGE/GerenciarEventos.php");
        }
    }
?>