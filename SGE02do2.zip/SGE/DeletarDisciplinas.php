<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();
            $resultado = $instrucao->get_result();
            $resultado = $resultado->fetch_assoc();

            $instrucao = $conn->prepare("DELETE FROM LECIONA WHERE IDDISCIPLINA = '{$IDARemover}'");
            $instrucao->execute();
            $instrucao = $conn->prepare("DELETE FROM NOTAS WHERE IDDISCIPLINA = '{$IDARemover}'");
            $instrucao->execute();
            $instrucao = $conn->prepare("DELETE FROM HISTORICO_NOTAS WHERE IDDISCIPLINA = '{$IDARemover}'");
            $instrucao->execute();
            $instrucao = $conn->prepare("DELETE FROM DISCIPLINA WHERE IDDISCIPLINA = '{$IDARemover}'");
            $instrucao->execute();

            header("location: GerenciarDisciplinas.php");
        }
    }


?>