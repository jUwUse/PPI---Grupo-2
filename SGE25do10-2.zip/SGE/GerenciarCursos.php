<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

$Aplicado = @$_GET['FiltroSubmit'];
$lista = array(@$_GET['NomeFiltro'], @$_GET['FiltroCoordenador'], @$_GET['FiltroDuracao']);
$lista_pos = array("NOME", "COORDENADOR", "DURACAO");

function SomenteNulo($lista) { //Verifica se todos os parâmetros estão vazios. Isso é, o filtro foi solicitado, mas sem selecionar nada.
    foreach ($lista as $i) {
        if ($i !== "" && $i !== NULL) {
            return false;
        }
    }
    return true;
}

function GerarSQL($lista, $lista_pos, $numero) { //Cria o comando de select com base nos parâmetros fornecidos no filtro.
    $primeiro_a_entrar = 0;
    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $numero AND ";
    for ($z = 0; $z < sizeof($lista); $z++) {
        if ($lista[$z] != NULL && $lista[$z] != "") {
            if ($primeiro_a_entrar == 0) {
                $sql .= $lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                $primeiro_a_entrar++;
            }
            else {
                $sql .= "AND ".$lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
            }
        }
    }
    $sql .= ";";
    return $sql;
}

function MostrandoTurmas($numero, $duracao, $conn) { //Exibe as turmas abaixo dos curso. Boa sorte.
    for ($ano = 1; $ano <= $duracao; $ano++) {
        $sqlturma = "SELECT * FROM TURMA WHERE IDCURSO = $numero AND ANO = $ano";
        $resultadoverificacaoturma = $conn->query($sqlturma);
        $resultadolistaturma = $resultadoverificacaoturma->fetch_assoc();
        echo "<script> document.getElementById('ParteDasTurmas".($numero)."').innerHTML += '<a href=\"/SGE/Turma.php?id=".$resultadolistaturma["IDTURMA"]."\">". $resultadolistaturma["NUMERO"] ."</a>'; </script>";
    }
    $ano = 1;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="stylesgerenciarcursos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Cursos / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href="/SGE/AdicionarCursos.php" class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Curso</span>
            </a><br>
        </div>
    </div>

    <div class="CampodeFiltro">
        <form action="" class="FormulariodeFiltro" method="GET" >
            <label for="NomeFiltro">Nome do Curso:</label><br>
            <input class="campo" type="text" id="NomeFiltro" name="NomeFiltro" value="<?php echo @$_GET['NomeFiltro']; ?>"><br>
            <span class="Botoes">
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#OpcoesOcultas" >
                    Mais opções
                </button>

                <button class="btn btn-light" type="button" onClick="location.href='/SGE/GerenciarCursos.php'">
                    Limpar Filtro
                </button>

                <input class="btn btn-light" type="submit" name="FiltroSubmit" value="Aplicar">
            </span>

            <div class="collapse" id="OpcoesOcultas" style="margin-top: 10px;">
                <hr>
                <div class="d-inline-flex gap-5">
                    <span>
                        <label for="FiltroDuracao">Duracao:</label><br>
                        <input class="campoextra" type="number" id="FiltroDuracao" name="FiltroDuracao" value="<?php echo @$_GET['FiltroDuracao']; ?>"><br>
                    </span>

                    <span>
                        <label for="FiltroCoordenador">Nome do Coordenador:</label><br>
                        <input class="campoextra" type="text" id="FiltroCoordenador" name="FiltroCoordenador" value="<?php echo @$_GET['FiltroCoordenador']; ?>"><br>
                    </span>
                </div>
            </div>
        </form>
        <hr>
    </div>

    <div id="SelectDosCursos">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM CURSO ORDER BY IDCURSO DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Você não possui nenhum curso cadastrado. Clique no botão do menu lateral para adicionar.</div>";
        } 
        else {
            echo '<table><tr>';
            if (somenteNulo($lista) == true || $Aplicado == NULL) {
                while ($numero <= $resultadoID["IDCURSO"]) {
                    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $numero";
                    $resultadoverificacao = $conn->query($sql);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {
                        if ($i<=3) {
                            echo '<td>
                                <div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . '</p> 
                                <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_curso/'.$resultadolista['FOTO'].'" alt="logo"> </p>
                                <p id="ParteDasTurmas'.$numero.'"></p> 
                                <p> <a href="AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> 
                                <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' . '</p> </div>
                                </td>'; 
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> 
                            <p>' . $resultadolista["NOME"] . '</p> 
                            <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_curso/'.$resultadolista['FOTO'].'" alt="logo"> </p>
                            <p id="ParteDasTurmas'.$numero.'"></p> 
                            <p> <a href="/SGE/AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> 
                            <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' .'</p> </div></td>'; 
                            $i = 0;
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        $i ++;
                    }
                    $numero += 1;
                }
            }
            else {
                while ($numero <= $resultadoID["IDCURSO"]) {
                    $funcaoDeFiltro = GerarSQL($lista, $lista_pos, $numero);
                    $resultadoverificacao = $conn->query($funcaoDeFiltro);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
                    foreach ($resultadoverificacao as $j) {
                        if ($i<=3) {
                            echo '<td>
                                <div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . '</p> 
                                <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_curso/'.$resultadolista['FOTO'].'" alt="logo"> </p>
                                <p id="ParteDasTurmas'.$numero.'"></p> 
                                <p> <a href="AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> 
                                <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' . '</p> </div>
                                </td>'; 
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> 
                            <p>' . $resultadolista["NOME"] . '</p> 
                            <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_curso/'.$resultadolista['FOTO'].'" alt="logo"> </p>
                            <p id="ParteDasTurmas'.$numero.'"></p> 
                            <p> <a href="/SGE/AlterarCursos.php?id='. $resultadolista["IDCURSO"] .'">Editar</a> 
                            <a href="DeletarCursos.php?id='. $resultadolista["IDCURSO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p>' .'</p> </div></td>'; 
                            $i = 0;
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        $i ++;
                    }
                    $numero += 1;
                }
            }
        }

            echo '</table>';
        ?>

    </div>

</body>

</html>