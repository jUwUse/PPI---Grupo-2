<?php
include("Config.php");
include("Logout_Function.php");

$IDSelecionado = (int)$_GET['id'];

$sql = "SELECT * FROM CURSO WHERE IDCURSO = $IDSelecionado";
$resultadoverificacao = $conn->query($sql);
$resultadolistacurso = $resultadoverificacao->fetch_assoc();

$sql = "SELECT * FROM TURMA WHERE IDCURSO = $IDSelecionado";
$resultadoverificacao = $conn->query($sql);
$resultadolistacurso = $resultadoverificacao->fetch_assoc();

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylescurso.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>CURSO <?php echo @$resultadolistacurso['NOME']; ?> / SGE</title>
</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarCursos.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href="/SGE/AdicionarCursos.php" class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Curso</span>
            </a><br>
        </div>

    </div>

    <div id="SelectDasTurmas">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM CURSO WHERE IDCURSO = $IDSelecionado";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();

        echo '<table><tr>';
        while ($numero <= $resultadoID["DURACAO"]) {
            $sql = "SELECT * FROM TURMA WHERE IDCURSO = $IDSelecionado AND ANO = $numero";
            $resultadoverificacao = $conn->query($sql);
            $resultadolista = $resultadoverificacao->fetch_assoc();
            $numero += 1;

            foreach ($resultadoverificacao as $j) {

                if ($i <= 2) {
                    echo '<td>
                            <div class="quadrado"> <p onClick="location.href = \'Turma.php?id=' . $resultadolista["IDTURMA"] . '\'">' . $resultadolista['NUMERO'] . '</p></div>
                            </td>';
                } else {
                    echo '</tr><tr>';
                    echo '<td><div class="quadrado"> <p onClick="location.href = \'Turma.php?id=' . $resultadolista["IDTURMA"] . '\'">' . $resultadolista['NUMERO'] . '</p></div></td>';
                    $i = 0;
                }
                $i++;
            }
        }
        echo '</table>';
        ?>

    </div>
</body>

</html>