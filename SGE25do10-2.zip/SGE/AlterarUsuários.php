<?php //Preenche os dados.
include("Config.php");

function Alterar($Nome, $Siape, $Atividades, $tipo, $conn, $id)
{
    if ($tipo == "professor") {
        if ($Nome == NULL && $Siape == NULL) {
            echo "<div class='erro'>Insira as informações que deseja alterar.</div>";
            return "não funcionou.";
        } else if (strlen((string)$Nome) > 100) {
            echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
            return "não funcionou.";
        } else if (strlen((string)$Siape) != 7 && $Siape != NULL) {
            echo "<div class='erro'>O SIAPE deve ter 7 caracteres.</div>";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM USUARIO WHERE NOME = ? AND IDUSER != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "<div class='erro'>Outro usuário já possui este nome.</div>";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT SIAPE FROM PROFESSOR WHERE SIAPE = ? AND IDPROF != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder) //s=string, i=int, d=double
        $instrucao->bind_param("i", $Siape);
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "<div class='erro'>Outro usuário já possui este SIAPE.</div>";
            return "não funcionou.";
        }

        if ($Nome != NULL) {
            $instrucao = $conn->prepare("UPDATE USUARIO SET NOME = ? WHERE IDUSER = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
            $instrucao->execute();
        }

        if ($Siape != NULL) {
            $instrucao = $conn->prepare("UPDATE PROFESSOR SET SIAPE = ? WHERE IDPROF = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $Siape); //s=string, i=int, d=double
            $instrucao->execute();
            header('Location: GerenciarUsuários.php');
            return "funcionou";
        }

        header('Location: GerenciarUsuários.php');
    } else if ($tipo == "setor") {
        if ($Nome == NULL && $Atividades == NULL) {
            echo "<div class='erro'>Insira as informações que deseja alterar.</div>";
            return "não funcionou.";
        } else if (strlen((string)$Nome) > 100) {
            echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM USUARIO WHERE NOME = ? AND IDUSER != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "<div class='erro'>Outro usuário já possui este nome.</div>";
            return "não funcionou.";
        }
        if ($Nome != NULL) {
            $instrucao = $conn->prepare("UPDATE USUARIO SET NOME = ? WHERE IDUSER = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
            $instrucao->execute();
        }

        if ($Atividades != NULL) {
            $instrucao = $conn->prepare("UPDATE SETORUSUARIO SET ATIVIDADES = ? WHERE IDSETORUSUARIO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Atividades); //s=string, i=int, d=double
            $instrucao->execute();
            header('Location: GerenciarUsuários.php');
            return "funcionou";
        }

        header('Location: GerenciarUsuários.php');
    }
}

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

$IDAEditar = (int)$_GET['id'];
$sql = "SELECT * FROM USUARIO WHERE IDUSER = $IDAEditar";
$resultadoverificacao = $conn->query($sql);
$resultadolista = $resultadoverificacao->fetch_assoc();

if ($resultadolista['TIPO'] == "Professor") {
    $sql = "SELECT * FROM PROFESSOR WHERE IDPROF = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistaprof = $resultadoverificacao->fetch_assoc();
    // $_POST['PermissoesAlteracaoProfessor'] = $resultadolista["PERMISSAO"];

?>

    <script>
        document.getElementById("FormularioDeAlteracaoSetor").style.display = "none";
        document.getElementById("FormularioDeAlteracaoProfessor").style.display = "block";
    </script>

<?php
} else if ($resultadolista['TIPO'] == "Setor") {
    $sql = "SELECT * FROM SETORUSUARIO WHERE IDSETORUSUARIO = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistasetor = $resultadoverificacao->fetch_assoc();

?>

    <script>
        document.getElementById("FormularioDeAlteracaoSetor").style.display = "block";
        document.getElementById("FormularioDeAlteracaoProfessor").style.display = "none";
    </script>

<?php
} else {
?>

    <script>
        alert("Você não pode alterar um administrador!");
        window.history.back();
    </script>

<?php
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesalterarusuarios.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Alterar Usuários / SGE</title>

    <script>
        function Cancelar() {
            location.href = '/SGE/GerenciarUsuários.php';
        }
    </script>

</head>

<body>
    <?php
    if (isset($_POST['AlteracaoSubmitProfessor'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = Alterar($_POST['NomeAlteracaoProfessor'], $_POST['SiapeAlteracaoProfessor'], NULL, "professor", $conn, $IDAEditar);
        // function Alterar($Nome, $Siape, $Atividades, $tipo, $conn, $id)
    }

    if (isset($_POST['AlteracaoSubmitSetor'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = Alterar($_POST['NomeAlteracaoSetor'], NULL, $_POST['AtividadesAlteracaoSetor'], "setor", $conn, $IDAEditar);
    }
    ?>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarUsuários.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <form action="" id="FormularioDeAlteracaoProfessor" method="post">
                <label for="NomeAlteracaoProfessor">Nome:</label><br>
                <input class="campo" type="text" id="NomeAlteracaoProfessor" name="NomeAlteracaoProfessor" placeholder="<?php echo @$resultadolista["NOME"] ?>" value="<?php echo @$_POST['NomeAlteracaoProfessor'] ?>"><br>

                <label for="SiapeAlteracaoProfessor">SIAPE:</label><br>
                <input class="campo" type="number" id="SiapeAlteracaoProfessor" name="SiapeAlteracaoProfessor" placeholder="<?php echo @$resultadolistaprof["SIAPE"] ?>" value="<?php echo @$_POST['SiapeAlteracaoProfessor'] ?>"><br>

                <!-- 
        <label for="PermissoesAlteracaoProfessor">Permissões:</label><br>
        <input type="text" id="PermissoesAlteracaoProfessor" name="PermissoesAlteracaoProfessor" value="<?php echo @$_POST['PermissoesAlteracaoProfessor']; ?>"><br>
        -->

                <input class="botaoum" type="submit" name="AlteracaoSubmitProfessor" value="Salvar Alterações"><br>
                <input class="botaodois" type="button" onclick="Cancelar()" name="AlteracaoCancel" value="Cancelar"><br>
            </form>

            <form action="" id="FormularioDeAlteracaoSetor" method="post">
                <label for="NomeAlteracaoSetor">Nome:</label><br>
                <input class="campo" type="text" id="NomeAlteracaoSetor" name="NomeAlteracaoSetor" placeholder="<?php echo @$resultadolista["NOME"] ?>" value="<?php echo @$_POST['NomeAlteracaoSetor'] ?>"><br>

                <label for="AtividadesAlteracaoSetor">Atividades:</label><br>
                <input class="campo" type="text" id="AtividadesAlteracaoSetor" name="AtividadesAlteracaoSetor" placeholder="<?php echo @$resultadolistasetor["ATIVIDADES"] ?>" value="<?php echo @$_POST['AtividadesAlteracaoSetor'] ?>"><br>

                <!-- 
        <label for="PermissoesAlteracaoSetor">Permissões:</label><br>
        <input type="text" id="PermissoesAlteracaoSetor" name="PermissoesAlteracaoSetor" value="<?php echo @$_POST['PermissoesAlteracaoSetor']; ?>"><br>
        -->

                <input class="botaoum" type="submit" name="AlteracaoSubmitSetor" value="Salvar Alterações"><br>
                <input class="botaodois" type="button" onclick="Cancelar()" name="AlteracaoCancel" value="Cancelar"><br>
            </form>

        </div>
    </div>

    <!-- ---------------------------------------------------- -->

    <?php //Esconde o formulário indesejado.
    $sql = "SELECT * FROM USUARIO WHERE IDUSER = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolista = $resultadoverificacao->fetch_assoc();

    if ($resultadolista['TIPO'] == "Professor") {
    ?>

        <script>
            document.getElementById("FormularioDeAlteracaoSetor").style.display = "none";
            document.getElementById("FormularioDeAlteracaoProfessor").style.display = "block";
        </script>

    <?php
    } else if ($resultadolista['TIPO'] == "Setor") {
    ?>

        <script>
            document.getElementById("FormularioDeAlteracaoSetor").style.display = "block";
            document.getElementById("FormularioDeAlteracaoProfessor").style.display = "none";
        </script>

    <?php
    }

    ?>

</body>

</html>