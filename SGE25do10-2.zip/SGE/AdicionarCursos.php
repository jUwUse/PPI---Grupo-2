<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

function Adicionar($Nome, $Duracao, $Coordenador, $conn)
{
    $elementos = func_get_args();

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) { //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        } //Pode mudar o return para "echo" para testar mais visivelmente.
    };

    if (strlen((string)$Nome) > 100) {
        echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }
    if (strlen((string)$Coordenador) > 100) {
        echo "<div class='erro'>O nome do coordenador não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }
    if ($Duracao < 1) {
        echo "<div class='erro'>Um curso precisa ter, no mínimo, 1 ano de duração</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT NOME FROM CURSO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultado != NULL) {
        echo "<div class='erro'>Um curso com esse nome já existe no sistema.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("INSERT INTO CURSO(NOME, DURACAO, COORDENADOR) VALUES(?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
    $instrucao->bind_param("sis", $Nome, $Duracao, $Coordenador); //s=string, i=int, d=double
    $instrucao->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT * FROM CURSO WHERE IDCURSO = LAST_INSERT_ID()"); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultadolistaid = $resultado->fetch_assoc();

    if ((isset($_FILES['Foto']) == TRUE) && ($_FILES['Foto'] != NULL)) {
        $imagem = $_FILES['Foto']["name"];
        if (strtolower(pathinfo($_FILES["Foto"]["name"], PATHINFO_EXTENSION)) == ("jpg" || "jpeg" || "png" || "jfif")) {
            move_uploaded_file($_FILES["Foto"]["tmp_name"], ("images_curso/".$_FILES["Foto"]["name"]));
            $instrucao = $conn->prepare("UPDATE CURSO SET FOTO = '$imagem' WHERE IDCURSO = LAST_INSERT_ID()"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->execute();
        }
    }

    header("location: /SGE/AdicionarTurmas.php?id=".$resultadolistaid['IDCURSO']);
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesadicionarcursos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Adicionar Cursos / SGE</title>
</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarCursos.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>
    <span>
        <?php
        if (isset($_POST['CursoCadastroSubmit'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Adicionar($_POST['NomeCurso'], $_POST['DuracaoCurso'], $_POST['CoordenadorCurso'], $conn);
            //function Adicionar($Nome, $Duracao, $Coordenador, $conn) {
        }
        ?>
    </span>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <div>
                <p><b>Cadastrar Curso</b></p>
                <form enctype="multipart/form-data" id="CursoCadastro" action="AdicionarCursos.php" method="post" style="text-align: left; display: block;" autocomplete="off">
                    <label for="NomeCurso">Nome do Curso:</label><br>
                    <input class="campo" type="text" id="NomeCurso" name="NomeCurso" value="<?php echo @$_POST['NomeCurso']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                    <label for="DuracaoCurso">Duracao (em anos)</label><br>
                    <input class="campo" type="number" id="DuracaoCurso" name="DuracaoCurso" value="<?php echo @$_POST['DuracaoCurso']; ?>" required><br>

                    <label for="CoordenadorCurso">Coordenador do Curso:</label><br>
                    <input class="campo" type="text" id="CoordenadorCurso" name="CoordenadorCurso" value="<?php echo @$_POST['CoordenadorCurso']; ?>"><br>

                    <label for="Foto">Logo do Curso:</label><br>
                    <input class="campo" type="file" id="Foto" name="Foto" value="<?php echo @$_POST['Foto']; ?>"><br>

                    <input class="botao" type="submit" name="CursoCadastroSubmit" value="Criar Curso"><br>
                </form>
            </div>
        </div>
    </div>

</body>

</html>