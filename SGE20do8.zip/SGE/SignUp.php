<?php
    error_reporting(E_ALL ^ E_DEPRECATED); //Erros depreciados significam que há uma maneira mais aceita de fazer, mas não são necessariamente errados. Para mostrar esses erros, só apaga essa linha.

    function cadastro($Nome, $Email, $Senha, $SenhaConfirmada, $SIAPE, $Atividades, $Tipo) {
        /* -----------------Verificação----------------------- */
        include ('Config.php');
        
        $elementos = func_get_args(); // Basicamente, bota todos os argumentos da função numa lista.
        // print_r($elementos); // Printa os argumentos para verificar se está funcionando.

        foreach ($elementos as $valor) {
            if(preg_match("/([<|>])/", $valor) == TRUE){ //preg_match verifica se há a presença do padrão especificado no valor (não sei a sintaxe direito)
                echo "Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.";
                return "não funcionou.";
            } //Pode mudar o return para "echo" para testar mais visivelmente.
        };

        $Email = filter_var($Email, FILTER_SANITIZE_EMAIL); //Remove caracteres indesejados do email
        if (filter_var($Email, FILTER_VALIDATE_EMAIL) != TRUE) { //Verifica se o email tá na estrutura certa
            echo "O Email inserido não é válido.";
            return "não funcionou.";
        }

        if (strlen((string)$Nome) > 100) {
            echo "O nome não pode ter mais de 100 caracteres.";
            return "não funcionou.";
        }

        if (strlen((string)$Email) > 255) {
            echo "O email não pode ter mais de 255 caracteres.";
            return "não funcionou.";
        }

        if (($SIAPE != NULL) && (strlen((string)$SIAPE) != 7)) {
            echo "O SIAPE deve ter 7 dígitos.";
            return "não funcionou.";
        }

        if (strlen((string)$Senha) > 30) {
            echo "A senha não pode ter mais de 30 caracteres.";
            return "não funcionou.";
        }
        else if (strlen((string)$Senha) < 8) {
            echo "Crie uma senha de, no mínimo, 8 caracteres.";
            return "não funcionou.";
        }

        if ($SenhaConfirmada != $Senha) {
            echo "O campo de confirmar senha não bate com a senha original.";
            return "não funcionou.";
        }

        if ($SIAPE != NULL && $Atividades != NULL) {
            echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
            return "não funcionou.";
        }

        // Quando trabalhando com banco de dados, parece que é bom usar instruções preparadas (para evitar problemas de segurança)
        $instrucao = $conn->prepare("SELECT EMAIL FROM USUARIO WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Email); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "Este email já existe no sistema.";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "Este nome já existe no sistema.";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT SIAPE FROM PROFESSOR WHERE SIAPE = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("i", $SIAPE); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "Este SIAPE já existe no sistema.";
            return "não funcionou.";
        }

        $Senha_Encriptada = password_hash($Senha, PASSWORD_DEFAULT);

        /* -----------------Cadastro--------------------------- */

        $instrucao = $conn->prepare("INSERT INTO USUARIO(NOME, SENHA, EMAIL, TIPO) VALUES(?,?,?,?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
        $instrucao->bind_param("ssss", $Nome, $Senha_Encriptada, $Email, $Tipo); //s=string, i=int, d=double
        $instrucao->execute();
        if ($conn->affected_rows != 1) {
            echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
            return "não funcionou.";
        }
        else {
            if ($Tipo == "Professor") {
                $instrucao = $conn->prepare("INSERT INTO PROFESSOR(IDPROF, SIAPE) VALUES(LAST_INSERT_ID(), ?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("i", $SIAPE); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conn->affected_rows != 1) {
                    echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
                    return "não funcionou.";
                }
                else {
                    return "funcionou.";
                }
            }
            else if ($Tipo == "Setor") {
                $instrucao = $conn->prepare("INSERT INTO SETORUSUARIO(IDSETORUSUARIO, ATIVIDADES) VALUES(LAST_INSERT_ID(), ?)"); //Mesma coisa de antes, mas agora inserindo um dado ao invés de selecionando
                $instrucao->bind_param("s", $Atividades); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conn->affected_rows != 1) {
                    echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
                    return "não funcionou.";
                }
                else {
                    return "funcionou.";
                }
            }
            else {
                echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
                return "não funcionou.";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro / SGE</title>

    <script>
        function FormHide(tipo) {
            if(tipo=="professor") {
                document.getElementById("SignUpFormSetor").style.display = "none";
                
                if(document.getElementById("SignUpFormProfessor").style.display != "block"){
                    document.getElementById("SignUpFormProfessor").style.display = "block";
                }
            }

            else if(tipo=="setor") {
                document.getElementById("SignUpFormProfessor").style.display = "none";

                if(document.getElementById("SignUpFormSetor").style.display != "block"){
                    document.getElementById("SignUpFormSetor").style.display = "block";
                }
            }
        }

    </script>

</head>
<body>
    <span>

        <?php

            if(isset($_POST['ProfessorSubmit'])) { // Caso o formulário de professor seja enviado.
                $resultado_final_decisivo_mega_importante = cadastro($_POST['NomeProfessor'], $_POST['EmailProfessor'], $_POST['SenhaProfessor'], $_POST['senhaProfessorConfirmar'], $_POST['SIAPEProfessor'], NULL, "Professor");
                // function cadastro($Nome, $Email, $Senha, $SenhaConfirmada, $SIAPE, $Atividades, $Tipo) {
            }

            if(isset($_POST['SetorUserSubmit'])) { // Caso o formulário de professor seja enviado.
                $resultado_final_decisivo_mega_importante = cadastro($_POST['nomeSetor'], $_POST['EmailSetor'], $_POST['senhaSetor'], $_POST['senhaSetorConfirmar'], NULL, $_POST['atividadeSetor'], "Setor");
            }

        ?>
    </span>

    <div>
        <div>
            <button type="button" onclick="FormHide('professor')">Professor</button>
            <button type="button" onclick="FormHide('setor')">Setor</button>
        <div>

        <div>
            <form id="SignUpFormProfessor" action="SignUp.php" method="post" style="text-align: center; display: block;" autocomplete="off">
                <label for="NomeProfessor">Nome Completo:</label><br>
                <input type="text" id="NomeProfessor" name="NomeProfessor" value="<?php echo @$_POST['NomeProfessor']; ?>" required><br> <!-- O @ só impede erros irrelevantes de aparecerem. -->

                <label for="EmailProfessor">Email</label><br>
                <input type="email" id="EmailProfessor" name="EmailProfessor" value="<?php echo @$_POST['EmailProfessor']; ?>" required><br>

                <label for="SenhaProfessor">Senha:</label><br>
                <input type="password" id="SenhaProfessor" name="SenhaProfessor" value="<?php echo @$_POST['SenhaProfessor']; ?>" required><br>

                <label for="senhaProfessorConfirmar">Confirmar Senha</label><br>
                <input type="password" id="senhaProfessorConfirmar" name="senhaProfessorConfirmar" value="<?php echo @$_POST['senhaProfessorConfirmar']; ?>" required><br>

                <label for="SIAPEProfessor">Matrícula SIAPE:</label><br>
                <input type="number" id="SIAPEProfessor" name="SIAPEProfessor" value="<?php echo @$_POST['SIAPEProfessor']; ?>" required><br>

                <input type="submit" name="ProfessorSubmit" value="Cadastrar"><br>

            </form>
        </div>

        <div>
            <form id="SignUpFormSetor" action="SignUp.php" method="post" style="text-align: center; display: none;" autocomplete="off">
                <label for="nomeSetor">Nome Completo:</label><br>
                <input type="text" id="nomeSetor" name="nomeSetor" value="<?php echo @$_POST['nomeSetor']; ?>" required><br>

                <label for="EmailSetor">Email</label><br>
                <input type="email" id="EmailSetor" name="EmailSetor" value="<?php echo @$_POST['EmailSetor']; ?>" required><br>

                <label for="senhaSetor">Senha:</label><br>
                <input type="password" id="senhaSetor" name="senhaSetor" value="<?php echo @$_POST['senhaSetor']; ?>" required><br>

                <label for="senhaSetorConfirmar">Confirmar Senha</label><br>
                <input type="password" id="senhaSetorConfirmar" name="senhaSetorConfirmar" value="<?php echo @$_POST['senhaSetorConfirmar']; ?>" required><br>

                <label for="atividadeSetor">Atividade de Acompanhamento</label><br>
                <input type="text" id="atividadeSetor" name="atividadeSetor" value="<?php echo @$_POST['atividadeSetor']; ?>" required><br>

                <input type="submit" name="SetorUserSubmit" value="Cadastrar"><br>
            </form>

            <?php
                    if (@$resultado_final_decisivo_mega_importante == "funcionou.") { //O hashtag só impede alguns erros irrelevantes de aparecerem.
                        ?> <!-- Fecha o PHP, pra escrever em HTML -->
                            <p> Parábens! Seu cadastro foi concluído. </p>
                        <?php // Abre o PHP, porque se não a chave ia ficar de fora.
                    }
            ?>
        </div>

        Já possui uma conta?
                <a href="/SGE/Login.php">Fazer Login</a><br>
    </div>
    
</body>
</html>