<?php
    error_reporting(E_ALL ^ E_DEPRECATED); // Criei uma página separada para o logout porque ele meio que pode ser feito de várias páginas, eu acho. Daí é melhor chamar a função por fora do que definir ela sempre.
    include ('Config.php');
    include('Logout_Function.php');

    function Alterar($Email, $Senha, $SenhaConfirmada, $SenhaOriginal, $Nome, $conexao) {
        if ($Email == NULL && $Senha == NULL) {
            echo "Insira as informações que deseja alterar.";
            return "não funcionou.";
        }
        elseif ($SenhaOriginal == NULL) {
            echo "Insira sua senha original para autorizar a alteração.";
            return "não funcionou.";
        }
        elseif (password_verify($SenhaOriginal, $_SESSION["Senha"]) == FALSE) { // Caso perca o banco de dados, mude isso para TRUE na hora de alterar a senha do ADM. Seguindo esse passo e o de login, um novo usuário ADM primordial terá sido criado.
            echo "Sua senha original não está correta.";
            return "não funcionou.";
        }
        else {
            if ($Email != NULL) {
                $Email = filter_var($Email, FILTER_SANITIZE_EMAIL); //Remove caracteres indesejados do email
                if (filter_var($Email, FILTER_VALIDATE_EMAIL) != TRUE) { //Verifica se o email tá na estrutura certa
                    echo "O Email inserido não é válido.";
                    return "não funcionou.";
                }
    
                if (strlen((string)$Email) > 255) {
                    echo "O email não pode ter mais de 255 caracteres.";
                    return "não funcionou.";
                }

                $instrucao = $conexao->prepare("UPDATE USUARIO SET EMAIL = ? WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->bind_param("ss", $Email, $Nome); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conexao->affected_rows != 1) {
                    echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
                    return "não funcionou.";
                }
                else {
                    $_SESSION["Email"] = $Email;
                }

            }
    
            if ($Senha != NULL) {
                if (strlen((string)$Senha) > 30) {
                    echo "A senha não pode ter mais de 30 caracteres.";
                    return "não funcionou.";
                }
                else if (strlen((string)$Senha) < 8) {
                    echo "Crie uma senha de, no mínimo, 8 caracteres.";
                    return "não funcionou.";
                }
        
                if ($SenhaConfirmada != $Senha) {
                    echo "O campo de confirmar senha não bate com a senha original.";
                    return "não funcionou.";
                }

                $Senha_Encriptada = password_hash($Senha, PASSWORD_DEFAULT);

                $instrucao = $conexao->prepare("UPDATE USUARIO SET SENHA = ? WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->bind_param("ss", $Senha_Encriptada, $Nome); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conexao->affected_rows != 1) {
                    echo "Um erro desconhecido ocorreu. Tente novamente mais tarde.";
                    return "não funcionou.";
                }
                else {
                    $instrucao = $conexao->prepare("SELECT SENHA FROM USUARIO WHERE NOME = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                    $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
                    $instrucao->execute();
                    $resultado = $instrucao->get_result();
                    $resultadoverificacao = $resultado->fetch_assoc();

                    $_SESSION["Senha"] = $resultadoverificacao["SENHA"];
                }
            }

            header('Location: Home.php');
            return "funcionou";
        }

    }

    /* function printar($Email, $Senha, $SenhaConfirmada, $SenhaOriginal) { //Essa função somente testa se os valores estão sendo enviados.
        $elementos = func_get_args(); 
        if ($Senha != NULL) { //Isso foi feito pra verificar se quando você deixa um campo vazio ele é enviado como NULL (sim)
            print_r($elementos);
        }
    } */

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        header("location: Login.php");
        exit();
    }

    if (isset($_GET['Logout'])) {
        logout();
    }

    if (isset($_POST['AlteracaoSubmit'])) {
        echo "<script type='text/javascript'>',
                'Hide('FormularioDeAlteracao');',
                '</script>";

            $resultado_final_decisivo_mega_importante = Alterar($_POST['EmailAlteracao'], $_POST['SenhaAlteracao'], $_POST['SenhaNovaConfirmar'], $_POST['AlterarConfirmarSenha'], $_SESSION["Nome"], $conn);
    }

    if ($_SESSION['Tipo'] == "ADM") {
        echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" style="display: block;"> Gerenciar Usuários</a><br>';
        echo '<a href="/SGE/GerenciarCursos.php" id="CriarUser" style="display: block;"> Gerenciar Cursos</a><br>';
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página inicial / SGE</title>

    <script>
        function Hide(ID) {
            if (ID=="DadosDoUsuario") {
                document.getElementById(ID).style.display = 'none';
                document.getElementById("FormularioDeAlteracao").style.display = 'block';
            }

            if (ID=="FormularioDeAlteracao") {
                document.getElementById("DadosDoUsuario").style.display = 'block';
                document.getElementById(ID).style.display = 'none';
            }

            if (ID=="DadosDoUsuario") {
                document.getElementById(ID).style.display = 'none';
                document.getElementById("FormularioDeAlteracao").style.display = 'block';
            }

        }
    </script>
</head>
<body>
    <a href="?Logout" style="display:block;">Sair</a><br> <!-- O ponto de pergunta faz com que um parametro seja passado, ao invés de ir para outra página.-->
    <a href="/SGE/Reclamacao.php">Relatar Problema</a><br>

    <span id="DadosDoUsuario" style="display: block;">
        <p> Seu nome: <?php echo $_SESSION["Nome"]?></p>
        <p> Seu tipo: <?php echo $_SESSION["Tipo"]?></p>
        <p> Seu email: <?php echo $_SESSION["Email"]?></p>

        <button type="button" onclick="Hide('DadosDoUsuario')">Atualizar Dados</button><br><br>
    </span>

    <form action="Home.php" id="FormularioDeAlteracao" method="post" style="display: none;" autocomplete="off">
        <p> <?php echo $_SESSION["Nome"]?></p>
        <p> <?php echo $_SESSION["Tipo"]?></p>
        <p> <?php echo $_SESSION["Email"]?></p>

        <label for="EmailAlteracao">Email:</label><br>
        <input type="email" id="EmailAlteracao" name="EmailAlteracao" value="<?php echo @$_POST['EmailAlteracao']; ?>"><br>
        <label for="SenhaAlteracao">Senha Nova:</label><br>
        <input type="password" id="SenhaAlteracao" name="SenhaAlteracao" value="<?php echo @$_POST['SenhaAlteracao']; ?>"><br>

        <label for="SenhaNovaConfirmar">Confirme nova senha:</label><br>
        <input type="password" id="SenhaNovaConfirmar" name="SenhaNovaConfirmar" value="<?php echo @$_POST['SenhaNovaConfirmar']; ?>"><br>

        <label for="AlterarConfirmarSenha">Insira sua senha atual:</label><br>
        <input type="password" id="AlterarConfirmarSenha" name="AlterarConfirmarSenha" value="<?php echo @$_POST['AlterarConfirmarSenha']; ?>"><br>

        <input type="submit" name="AlteracaoSubmit" value="Salvar Alterações"><br>
        <input type="button" onclick="Hide('FormularioDeAlteracao')" name="AlteracaoCancel" value="Cancelar"><br>
    </form>

</body>
</html>