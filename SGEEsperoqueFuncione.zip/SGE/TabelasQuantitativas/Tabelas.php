<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

unset($_SESSION["Turma"]);

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    }
    else {
        header("location: ../Home.php");
        exit();
    }
}
if (isset($_GET['disciplina']) == FALSE) {
    header("location: ../Home.php");
    exit();
}

$instrucao = $conn->prepare("SELECT * FROM DISCIPLINA WHERE IDDISCIPLINA = ?");
$instrucao->bind_param("i", $_GET['disciplina']); //s=string, i=int, d=double
$instrucao->execute();
$resultadoDisciplina = $instrucao->get_result();
$resultadoDisciplina = $resultadoDisciplina->fetch_assoc();

$instrucao = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?");
$instrucao->bind_param("i", $_GET['id']); //s=string, i=int, d=double
$instrucao->execute();
$resultadoTurma = $instrucao->get_result();
$resultadoTurma = $resultadoTurma->fetch_assoc();

// --------------------- //

$instrucao = $conn->prepare("SELECT * FROM LECIONA WHERE IDUSER = ? AND IDDISCIPLINA = ?");
$instrucao->bind_param("ii", $_SESSION['ID'], $_GET['disciplina']); //s=string, i=int, d=double
$instrucao->execute();
$resultadoPermissao = $instrucao->get_result();
$resultadoPermissao = $resultadoPermissao->fetch_assoc();
if ($resultadoPermissao != NULL || $_SESSION['Tipo'] == "ADM") {
    $PossuiPermissao = TRUE;
}
else {
    $PossuiPermissao = FALSE;
}

// ---------------------- //

$instrucaoPrimeiro = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'PRIMEIRO_SEMESTRE'");
$instrucaoPrimeiro->execute();
$resultadoSubPrimeiro = $instrucaoPrimeiro->get_result();
$quantiaSubPrimeiro = $resultadoSubPrimeiro->num_rows;
$resultadoSubPrimeiroLegal = [];
while ($row = $resultadoSubPrimeiro->fetch_assoc()) {
    $resultadoSubPrimeiroLegal[] = $row;
}

$instrucaoSegundo = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'SEGUNDO_SEMESTRE'");
$instrucaoSegundo->execute();
$resultadoSubSegundo = $instrucaoSegundo->get_result();
$quantiaSubSegundo = $resultadoSubSegundo->num_rows;
$resultadoSubSegundoLegal = [];
while ($row = $resultadoSubSegundo->fetch_assoc()) {
    $resultadoSubSegundoLegal[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabela de <?php echo $resultadoDisciplina['NOME']?> - <?php echo $resultadoTurma['NUMERO']?> / SGE</title>

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script> 
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap3-editable/js/bootstrap-editable.js"></script>
    <link rel="stylesheet" href="../stylestabquanti.css">
</head>
<body>
    <div class="botaozinhos" style="margin-left: 70px;">
        <button id="Historico" class="btn btn-light" onClick="location.href= './HistoricoQuantitativas.php?id=<?php echo $_SESSION['Turma'] ?>&disciplina=<?php echo $resultadoDisciplina['IDDISCIPLINA'] ?>'"> Histórico </button>
        <button id="Historico" class="btn btn-light" onClick="location.href= '/SGE/AdicionarCriterio.php?id=<?php echo $_SESSION['Turma'] ?>&disciplina=<?php echo $resultadoDisciplina['IDDISCIPLINA'] ?>'"> Adicionar Critérios </button>
    </div>

<!-- Aqui vai ser a mais pura cópia. Tutorial abaixo, caso funcionar:
    https://www.youtube.com/watch?v=lkDO2xqbifE
-->
    <table id="sample_data" class="table table-bordered table-striped"> 
        <thead>
            <tr> 
                <th>NOME</th>
                <?php 
                    if ($quantiaSubPrimeiro <= 1) {
                        ?>
                            <th>PRIMEIRO SEMESTRE</th>
                        <?php
                    }
                    else {
                        foreach ($resultadoSubPrimeiroLegal as $subPrimeiro) {
                            $nome = strtr(strtoupper($subPrimeiro['NOME']), "_", " ");
                            if ($nome == 'GERAL') {
                                $nome .= "_".strtoupper((string)$subPrimeiro['PERTENCE']);
                            }
                            ?>
                                <th><?php echo strtoupper($nome)?></th>
                            <?php
                        }
                    }
                ?>
                <?php 
                    if ($quantiaSubSegundo <= 1) {
                        ?>
                            <th>SEGUNDO SEMESTRE</th>
                        <?php
                    }
                    else {
                        foreach ($resultadoSubSegundoLegal as $subSegundo) {
                            $nome = strtr(strtoupper($subSegundo['NOME']), "_", " ");
                            if ($nome == 'GERAL') {
                                $nome .= "_".strtoupper((string)$subSegundo['PERTENCE']);
                            }
                            ?>
                                <th><?php echo strtoupper($nome)?></th>
                            <?php
                        }
                    }
                ?>
                <th>NOTA FINAL</th>
                <th>FALTAS</th>
                <th>OBSERVAÇÕES</th>
            </tr>
        </thead>
        <tbody id="employee_data"></tbody>
    </table>

    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>
</body>
</html>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
        function fetch_employee_data() {
            $.ajax({
                url:"/SGE/TabelasQuantitativas/fetch.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                method:"POST",
                dataType:"json",
                success:function(data){
                    
                    for(var count = 0; count < data.length; count++) {
                        var html_data = '<tr id="row'+count+'"><td id="editable" data-emptytext="" style="background-color: #2C2C2D; color: white; data-column="NOME" data-row="'+count+'"">'+data[count].NOME+'</td>';
                        <?php 
                            if ($quantiaSubPrimeiro <= 1) {
                                ?>
                                    html_data += '<td id="PRIMEIRO_SEMESTRE" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="PRIMEIRO_SEMESTRE" data-name="PRIMEIRO_SEMESTRE" class="PRIMEIRO_SEMESTRE" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].PRIMEIRO_SEMESTRE+'</td>';
                                <?php
                            }
                            else {
                                foreach ($resultadoSubPrimeiroLegal as $subPrimeiro) {
                                    $nome = strtoupper($subPrimeiro['NOME']);
                                    if ($nome == 'GERAL') {
                                        $nome .= "_".strtoupper((string)$subPrimeiro['PERTENCE']);
                                    }
                                    ?>
                                        html_data += '<td id="<?php echo $nome?>" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="PRIMEIRO_SEMESTRE" data-pertence=PRIMEIRO_SEMESTRE data-name="<?php echo $nome?>" class="<?php echo $nome?>" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].<?php echo $nome?>+'</td>';
                                    <?php
                                }
                            }
                        ?>
                        <?php 
                            if ($quantiaSubSegundo <= 1) {
                                ?>
                                html_data += '<td id="SEGUNDO_SEMESTRE" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="SEGUNDO_SEMESTRE" data-name="SEGUNDO_SEMESTRE" class="SEGUNDO_SEMESTRE" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].SEGUNDO_SEMESTRE+'</td>';
                                <?php
                            }
                            else {
                                foreach ($resultadoSubSegundoLegal as $subSegundo) {
                                    $nome = strtoupper($subSegundo['NOME']);
                                    if ($nome == 'GERAL') {
                                        $nome .= "_".strtoupper((string)$subSegundo['PERTENCE']);
                                    }
                                    ?>
                                        html_data += '<td id="<?php echo $nome?>" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-pertence=SEGUNDO_SEMESTRE data-column="SEGUNDO_SEMESTRE" data-name="<?php echo $nome?>" class="<?php echo $nome?>" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].<?php echo $nome?>+'</td>';
                                    <?php
                                }
                            }
                        ?>
                        html_data += '<td id="NOTA_FINAL" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="NOTA_FINAL" data-name="NOTA_FINAL" class="NOTA_FINAL" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].NOTA_FINAL+'</td>';
                        html_data += '<td id="FALTAS" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="FALTAS" data-name="FALTAS" class="FALTAS" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].FALTAS+'</td>';
                        html_data += '<td id="OBSERVACOES" data-emptytext="" style="background-color: #2C2C2D; color: white;" data-column="OBSERVACOES" data-name="OBSERVACOES" class="OBSERVACOES" data-type="text" data-pk="'+data[count].IDNOTA+'" data-row="'+count+'">'+data[count].OBSERVACOES+'</td>';
                        $('#employee_data').append(html_data);
                    }

                    $('td').on('shown', function() { //Isso é executado quando o menu de edição aparece
                        var selectedCell = $(this).data('editable').$element[0];

                        $(this).data('editable').input.$input.on('keydown', function(e) {
                            if (e.which == 9) { // TAB key
                                e.preventDefault();
                                $(selectedCell).editable('hide'); // Close current editor

                                // Move to the next cell
                                var nextCell = $(selectedCell).closest('tr').find('td.editable').nextAll().filter(function() {
                                    return $(this).data('editable') !== undefined; // Check if the cell is editable
                                }).first();

                                if (nextCell.length) {
                                    nextCell.editable('show');
                                } else {
                                    console.log("No next editable cell found.");
                                }
                            }
                        });
                    });
                }
            })
        }
        fetch_employee_data();

        <?php if ($PossuiPermissao == TRUE) {
                if ($quantiaSubPrimeiro <= 1) {
                    ?>
                        $('#employee_data').editable({
                            container: 'body',
                            selector: 'td.PRIMEIRO_SEMESTRE',
                            url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                            title: 'PRIMEIRO_SEMESTRE',
                            type: "POST",
                            emptytext: '',
                            highlight: 'rgb(50, 173, 50)',
                            dataType: 'json',

                            validate: function(value){
                                if($.trim(value) == ''){
                                    return 'Este campo deve ser preenchido.';
                                }
                                var regex = /^-?\d*\.?\d+$/;
                                if(!regex.test(value)) {
                                    return 'Somente números são permitidos.';
                                }

                                if(parseFloat(value) > 10) {
                                    return 'O valor máximo é 10.';
                                }
                                if(parseFloat(value) < 0) {
                                    return 'O valor mínimo é 0.';
                                }
                            }
                        });
                    <?php
                }
                else {
                    ?>
                        for(var z = 1; z < document.getElementById('sample_data').rows[0].cells.length; z++) {
                            var simplificar = document.getElementById("sample_data").rows[0].cells[z].innerHTML;
                            if (simplificar != "NOME" && simplificar != "NOTA_FINAL" && simplificar != "FALTAS" && simplificar != "OBSERVAÇÕES") {
                                $('#employee_data').editable({
                                container: 'body',
                                selector: 'td.'+document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                                url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                                title: document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                                type: "POST",
                                emptytext: '',
                                highlight: 'rgb(50, 173, 50)',
                                dataType: 'json',

                                data: function(params) {
                                    params.pertence = $(this).attr('data-pertence'); // Add data-pertence to the data object
                                    return params;
                                },

                                validate: function(value){
                                    if($.trim(value) == ''){
                                        return 'Este campo deve ser preenchido.';
                                    }
                                    var regex = /^-?\d*\.?\d+$/;
                                    if(!regex.test(value)) {
                                        return 'Somente números são permitidos.';
                                    }

                                    if(parseFloat(value) > 10) {
                                        return 'O valor máximo é 10.';
                                    }
                                    if(parseFloat(value) < 0) {
                                        return 'O valor mínimo é 0.';
                                    }
                                }
                            });
                            }
                        }
                    <?php
                }
                if ($quantiaSubSegundo <= 1) {
                    ?>
                    $('#employee_data').editable({
                        container: 'body',
                        selector: 'td.SEGUNDO_SEMESTRE',
                        url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                        title: 'SEGUNDO_SEMESTRE',
                        type: "POST",
                        emptytext: '',
                        highlight: 'rgb(50, 173, 50)',
                        dataType: 'json',

                        validate: function(value){
                            if($.trim(value) == ''){
                                return 'Este campo deve ser preenchido.';
                            }
                            var regex = /^-?\d*\.?\d+$/;
                            if(!regex.test(value)) {
                                return 'Somente números são permitidos.';
                            }
                            if(parseFloat(value) > 10) {
                                return 'O valor máximo é 10.';
                            }
                            if(parseFloat(value) < 0) {
                                return 'O valor mínimo é 0.';
                            }
                        }
                    });
                    <?php
                }
                else {
                    ?>
                        for(var z = 1; z < document.getElementById('sample_data').rows[0].cells.length; z++) {
                            var simplificar = document.getElementById("sample_data").rows[0].cells[z].innerHTML;
                            if (simplificar != "NOME" && simplificar != "NOTA_FINAL" && simplificar != "FALTAS" && simplificar != "OBSERVAÇÕES") {
                                $('#employee_data').editable({
                                container: 'body',
                                selector: 'td.'+document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                                url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                                title: document.getElementById("sample_data").rows[0].cells[z].innerHTML,
                                type: "POST",
                                emptytext: '',
                                highlight: 'rgb(50, 173, 50)',
                                dataType: 'json',

                                data: function(params) {
                                    params.pertence = $(this).attr('data-pertence'); // Add data-pertence to the data object
                                    return params;
                                },

                                validate: function(value){
                                    if($.trim(value) == ''){
                                        return 'Este campo deve ser preenchido.';
                                    }
                                    var regex = /^-?\d*\.?\d+$/;
                                    if(!regex.test(value)) {
                                        return 'Somente números são permitidos.';
                                    }

                                    if(parseFloat(value) > 10) {
                                        return 'O valor máximo é 10.';
                                    }
                                    if(parseFloat(value) < 0) {
                                        return 'O valor mínimo é 0.';
                                    }
                                }
                            });
                            }
                        }
                    <?php
                }
                ?>
                
                
                

                $('#employee_data').editable({
                    container: 'body',
                    selector: 'td.OBSERVACOES',
                    url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                    title: 'OBSERVACOES',
                    type: "POST",
                    emptytext: '',
                    highlight: 'rgb(50, 173, 50)',
                    dataType: 'json',

                    validate: function(value){
                        if($.trim(value) == ''){
                            return 'Este campo deve ser preenchido.';
                        }
                    }
                });

                $('#employee_data').editable({
                    container: 'body',
                    selector: 'td.FALTAS',
                    url: "/SGE/TabelasQuantitativas/update.php?id=<?php echo $resultadoDisciplina['IDDISCIPLINA']?>",
                    title: 'FALTAS',
                    type: "POST",
                    emptytext: '',
                    highlight: 'rgb(50, 173, 50)',
                    dataType: 'json',

                    validate: function(value){
                        if($.trim(value) == ''){
                            return 'Este campo deve ser preenchido.';
                        }
                        var regex = /^-?\d*\.?\d+$/;
                        if(!regex.test(value)) {
                            return 'Somente números são permitidos.';
                        }

                        var regex = /\d\./;
                        if(regex.test(value)) {
                            return 'Somente números inteiros são permitidos.'
                        }
                        if(parseFloat(value) < 0) {
                            return 'O valor mínimo é 0.';
                        }
                    }
                });
            <?php
        }
        ?>

    });
</script>