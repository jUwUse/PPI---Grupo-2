<?php
include('../Config.php');

$regex = "/^(0|[1-9]\d*)(\.\d+)?$/";
if(preg_match($regex, $_POST["value"])) {
    if(strlen(substr(strrchr($_POST["value"], "."), 1)) > 1){
        $_POST["value"] = (string)round((double)$_POST["value"], 1, PHP_ROUND_HALF_UP);
    }
}

$InformacoesAluno = "SELECT * FROM NOTAS WHERE IDNOTA = '{$_POST["pk"]}'";
$resultadoAluno = $conn->query($InformacoesAluno);
$resultadoAluno = $resultadoAluno->fetch_assoc();

if ($_POST["name"] == "GERAL_PRIMEIRO_SEMESTRE") {
    $query = "
    UPDATE NOTAS SET GERAL_PRIMEIRO_SEMESTRE = '".$_POST["value"]."' 
    WHERE IDNOTA = '".$_POST["pk"]."'";
   mysqli_query($conn, $query);
}
elseif ($_POST["name"] == "GERAL_SEGUNDO_SEMESTRE") {
    $query = "
    UPDATE NOTAS SET GERAL_SEGUNDO_SEMESTRE = '".$_POST["value"]."' 
    WHERE IDNOTA = '".$_POST["pk"]."'";
   mysqli_query($conn, $query);
}
else {
    $query = "
    UPDATE NOTAS SET ".$_POST["name"]." = '".$_POST["value"]."' 
    WHERE IDNOTA = '".$_POST["pk"]."'";
    mysqli_query($conn, $query);
}

$instrucao = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'PRIMEIRO_SEMESTRE'");
$instrucao->execute();
$resultado = $instrucao->get_result();
$quantiaPrimeiro = $resultado->num_rows;
$resultadoPrimeiro = $resultado->fetch_assoc();
if ($quantiaPrimeiro > 1) {
    $query = "SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'PRIMEIRO_SEMESTRE'";
    $resultado = mysqli_query($conn, $query);
    $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
    foreach($returned_rows as $row) {
        if (strtoupper($row["NOME"]) == "GERAL") {
            $soma = "(GERAL_PRIMEIRO_SEMESTRE * ({$row['PESO']}/100)) ";
        }
        else {
            $soma .= "+ ({$row['NOME']} * ({$row['PESO']}/100)) ";
        }
    }

    $query = "
    UPDATE NOTAS SET PRIMEIRO_SEMESTRE = ROUND({eval($soma)},1)
    WHERE IDNOTA = ".$_POST["pk"]."";
    mysqli_query($conn, $query);
}

$instrucao = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'SEGUNDO_SEMESTRE'");
$instrucao->execute();
$resultado = $instrucao->get_result();
$quantiaPrimeiro = $resultado->num_rows;
$resultadoPrimeiro = $resultado->fetch_assoc();
if ($quantiaPrimeiro > 1) {
    $query = "SELECT * FROM SUBAVALIACAO WHERE PERTENCE = 'SEGUNDO_SEMESTRE'";
    $resultado = mysqli_query($conn, $query);
    $returned_rows = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
    foreach($returned_rows as $row) {
        if (strtoupper($row["NOME"]) == "GERAL") {
            $soma = "(GERAL_SEGUNDO_SEMESTRE * ({$row['PESO']}/100)) ";
        }
        else {
            $soma .= "+ ({$row['NOME']} * ({$row['PESO']}/100)) ";
        }
    }
    
    $query = "
    UPDATE NOTAS SET SEGUNDO_SEMESTRE = ROUND({eval($soma)},1)
    WHERE IDNOTA = ".$_POST["pk"]."";
    mysqli_query($conn, $query);
}


$query = "
 UPDATE NOTAS SET NOTA_FINAL = ROUND(((PRIMEIRO_SEMESTRE * 0.4) + (SEGUNDO_SEMESTRE * 0.6)),1) 
 WHERE IDNOTA = '".$_POST["pk"]."'";
mysqli_query($conn, $query); 

date_default_timezone_set('America/Sao_Paulo');
$date = date('d/m/Y G:i:s', time());
$string_date = (string)$date;

$query = "INSERT INTO HISTORICO_NOTAS(NOME, CONTEUDO, IDDISCIPLINA, DIA, ALUNO, COLUNA) VALUES('{$_SESSION['Nome']}','{$_POST['value']}',{$_GET['id']},'{$string_date}','{$resultadoAluno['NOME']}','{$_POST['name']}')";
mysqli_query($conn, $query);
?>
