<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('Config.php');
include('Logout_Function.php');

if (!isset($_SESSION['Email'])) {
    logout();
}

$lista_insert = array("Parcial_1", "Semestral_1", "Parcial_2", "Semestral_2", "Plano_de_Trabalho", "Relatorio_de_Atividades", "Recuperacao_Paralela", "Final_de_Ano");
foreach ($lista_insert as $row) {
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = '{$row}'");
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc();
    if ($resultado == NULL) {
        $query = "INSERT INTO EVENTO(NOME, PRAZO1, PRAZO2) VALUES('{$row}', NULL, NULL)";
        $conn->query($query);
    }
}

date_default_timezone_set('America/Sao_Paulo');
$data_Atual = date('Y-m-d', time());

function isPrazoValid($prazo1, $prazo2, $currentDate)
{
    if (is_null($prazo1) && is_null($prazo2)) {
        return "NO_PRAZO_DEFINED";
    }
    if (!is_null($prazo1) && $currentDate <= $prazo1) {
        return "PRAZO1_VALID";
    }
    if (!is_null($prazo2) && (is_null($prazo1) || $currentDate > $prazo1) && $currentDate <= $prazo2) {
        return "PRAZO2_VALID";
    }
    return "PRAZO_EXPIRED";
}

function getPrazoStatus($conn, $documento)
{
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
    $instrucao->bind_param("s", $documento);
    $instrucao->execute();
    $resultado = $instrucao->get_result()->fetch_assoc();
    return [
        'status' => isPrazoValid($resultado["PRAZO1"], $resultado["PRAZO2"], $GLOBALS['data_Atual']),
        'prazo' => (!is_null($resultado["PRAZO1"]) && $GLOBALS['data_Atual'] <= $resultado["PRAZO1"]) ? $resultado["PRAZO1"] : $resultado["PRAZO2"]
    ];
}

function usuarioJaEnviouNoPrazo($conn, $iduser, $tipo, $prazoFinal)
{
    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM $tabela WHERE IDUSER = ? AND DATA_ENVIO <= ?");
    $instrucao->bind_param("is", $iduser, $prazoFinal);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    if ($instrucao->fetch()) {
        return $arquivo;
    }
    return false;
}

function removerArquivo($conn, $iduser, $tipo)
{
    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $pastas = [
        "Plano de Trabalho" => "images_plano/",
        "Relatorio de Atividades" => "images_relatorio/",
    ];

    $instrucao = $conn->prepare("SELECT ARQUIVO FROM $tabela WHERE IDUSER = ?");
    $instrucao->bind_param("i", $iduser);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);

    if ($instrucao->fetch() && $arquivo) {
        $caminho = $pastas[$tipo] . $arquivo;

        if (file_exists($caminho)) {
            unlink($caminho);
        }

        $instrucao->close();

        $deleteInstrucao = $conn->prepare("DELETE FROM $tabela WHERE IDUSER = ?");
        $deleteInstrucao->bind_param("i", $iduser);
        $deleteInstrucao->execute();
        $deleteInstrucao->close();

        echo "<div class='sucesso'>Arquivo removido com sucesso!</div>";
    } else {
        echo "<div class='erro'>Erro ao remover o arquivo.</div>";
    }
}

function Adicionar($iduser, $conn, $tipo, $prazoStatus, $prazoFinal)
{

    if ($prazoStatus == "NO_PRAZO_DEFINED" || $prazoStatus == "PRAZO_EXPIRED") {
        echo "<div class='erro'>Não é possível enviar este documento, pois o prazo não foi definido por um administrador ainda.</div>";
        return;
    }

    if (usuarioJaEnviouNoPrazo($conn, $iduser, $tipo, $prazoFinal)) {
        echo "<div class='erro'>Você já enviou um documento deste tipo.</div>";
        return;
    }

    $pastas = [
        "Plano de Trabalho" => "images_plano/",
        "Relatorio de Atividades" => "images_relatorio/",
    ];

    if (!isset($_FILES['Arquivo']) || $_FILES['Arquivo']['error'] !== UPLOAD_ERR_OK) {
        echo "<div class='erro'>Erro no upload do arquivo.</div>";
        return;
    }

    $imagem = basename($_FILES['Arquivo']["name"]);
    $extensoes_permitidas = array("pdf");
    $extensao = strtolower(pathinfo($imagem, PATHINFO_EXTENSION));

    if (!in_array($extensao, $extensoes_permitidas)) {
        echo "<div class='erro'>Arquivos .$extensao não são permitidos.</div>";
        return;
    }

    $caminho = $pastas[$tipo] . $imagem;
    if (!is_dir($pastas[$tipo])) {
        mkdir($pastas[$tipo], 0777, true);
    }

    if (!move_uploaded_file($_FILES["Arquivo"]["tmp_name"], $caminho)) {
        echo "<div class='erro'>Falha ao mover o arquivo.</div>";
        return;
    }

    echo "<div class='sucesso'>Arquivo enviado com sucesso!</div>";

    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $instrucao = $conn->prepare("INSERT INTO $tabela (IDUSER, ARQUIVO, ENVIADO, DATA_ENVIO) VALUES(?, ?, ?, ?)");
    $enviado = 1;
    $dataEnvio = date('Y-m-d');
    $instrucao->bind_param("isss", $iduser, $imagem, $enviado, $dataEnvio);
    $instrucao->execute();
}

$prazoPlano = getPrazoStatus($conn, 'Plano_de_Trabalho');
$prazoRelatorio = getPrazoStatus($conn, 'Relatorio_de_Atividades');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['removerArquivo'])) {
        removerArquivo($conn, $_SESSION["ID"], $_POST['tipoDocumento']);
    } elseif (isset($_POST['PlanodeTrabalhoSubmit'])) {
        Adicionar($_SESSION["ID"], $conn, "Plano de Trabalho", $prazoPlano['status'], $prazoPlano['prazo']);
    } elseif (isset($_POST['RelatoriodeAtividadesSubmit'])) {
        Adicionar($_SESSION["ID"], $conn, "Relatorio de Atividades", $prazoRelatorio['status'], $prazoRelatorio['prazo']);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido; ?>.css">
    <link rel="stylesheet" href="stylesarquivos.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Gerenciar Arquivos / SGE</title>
</head>

<body>

    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>

    <?php foreach (["Plano de Trabalho" => $prazoPlano, "Relatorio de Atividades" => $prazoRelatorio] as $doc => $prazoInfo) : ?>
        <h3><?= $doc ?></h3>
        <?php $arquivoEnviado = usuarioJaEnviouNoPrazo($conn, $_SESSION["ID"], $doc, $prazoInfo['prazo']); ?>
        <?php if ($arquivoEnviado) : ?>
            <p><strong>Você já enviou um documento deste tipo.</strong></p>
            <form method="post" style="display: flex; flex-direction: column; align-items: center;">
                <input type="hidden" name="tipoDocumento" value="<?= $doc ?>">
                <button type="submit" name="removerArquivo">Remover Arquivo</button>
            </form>
        <?php else : ?>
            <form enctype="multipart/form-data" method="post" style="display: flex; flex-direction: column; align-items: center;">
                <input type="file" name="Arquivo" required>
                <button class="enviar" type="submit" name="<?= str_replace(' ', '', $doc) ?>Submit">Enviar</button>
            </form>
        <?php endif; ?>
        <hr class="linha">
    <?php endforeach; ?>

</body>

</html>