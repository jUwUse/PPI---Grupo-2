<?php
    include ("Config.php");
    include ("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    }

    else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }

        else {
            $IDARemover = (int)$_GET['id'];

            $instrucao = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE IDSUBAVALIACAO = ?");
            $instrucao->bind_param("i", $IDARemover);
            $instrucao->execute();
            $resultado = $instrucao->get_result();
            $resultadoARemover = $resultado->fetch_assoc();

            $instrucaoAAumentar = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE NOME = 'Geral' AND PERTENCE = ?");
            $instrucaoAAumentar->bind_param("s", $resultadoARemover['PERTENCE']);
            $instrucaoAAumentar->execute();
            $resultadoAAumentar = $instrucaoAAumentar->get_result();
            $resultadoAAumentar = $resultadoAAumentar->fetch_assoc();

            $PesoAtual = $resultadoAAumentar['PESO'];
            $PesoRemovido = $resultadoARemover['PESO'];
            $PesoNovo = $PesoAtual + $PesoRemovido;

            $query = $conn->prepare("UPDATE SUBAVALIACAO SET PESO = ? WHERE NOME = 'Geral' AND PERTENCE = ?");
            $query->bind_param("is", $PesoNovo, $resultadoAAumentar['PERTENCE']);
            $query->execute();

            $query = $conn->prepare("ALTER TABLE NOTAS DROP COLUMN IF EXISTS {$resultadoARemover['NOME']}");
            $query->execute();

            $instrucao = $conn->prepare("DELETE FROM SUBAVALIACAO WHERE IDSUBAVALIACAO = ?");
            $instrucao->bind_param("i", $IDARemover); //s=string, i=int, d=double
            $instrucao->execute();
            header("location: AdicionarCriterio.php");
        }
    }


?>