<?php
// Tabela de Eventos:
// 1 - Entrega Parcial 1
// 2 - Entrega Semestre 1
// 3 - Entrega Parcial 2
// 4 - Entrega Semestre 2
// 5 - Entrega Plano de Trabalho
// 6 - Entrega Relatório de Atividades
// 7 - Entrega Recuperação Paralela
// 8 - Conselho Pós-AIA (final de ano letivo)

error_reporting(E_ERROR);
include('Config.php');
include('Logout_Function.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

$lista_insert = array("Parcial_1", "Semestral_1", "Parcial_2", "Semestral_2", "Plano_de_Trabalho", "Relatorio_de_Atividades", "Recuperacao_Paralela", "Final_de_Ano");
foreach ($lista_insert as $row) {
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = '{$row}'");
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc();
    if ($resultado == NULL) {
        $query = "INSERT INTO EVENTO(NOME, PRAZO1, PRAZO2) VALUES('{$row}', NULL, NULL)";
        $conn->query($query);
    }
}

function AdicionarAnual($Nome, $Data, $conn)
{
    $ordem_de_preferencia = array("Parcial_1", "Semestral_1", "Parcial_2", "Semestral_2", "Final_de_Ano");
    $elementos = func_get_args();

    if ($Data == NULL) {
        echo "Preencha a data.";
        return "Não funcionou.";
    }

    if (array_search("{$Nome}", $ordem_de_preferencia) != 0) {
        $n = array_search("{$Nome}", $ordem_de_preferencia);
        while ($n >= 0) {
            $n--;
            $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
            $instrucao->bind_param("s", $ordem_de_preferencia[$n]);
            $instrucao->execute();
            $resultado_anterior = $instrucao->get_result();
            $resultado_anterior = $resultado_anterior->fetch_assoc();
            if ($resultado_anterior["PRAZO1"] != NULL) {
                if ($resultado_anterior["PRAZO1"] > $Data) {
                    echo $Nome . " Não pode acontecer antes de " . $resultado_anterior['NOME'];
                    return "Não funcionou.";
                }
            }
        }
    }

    if (array_search("{$Nome}", $ordem_de_preferencia) != 4) {
        $n = array_search("{$Nome}", $ordem_de_preferencia);
        while ($n <= 4) {
            $n++;
            $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
            $instrucao->bind_param("s", $ordem_de_preferencia[$n]);
            $instrucao->execute();
            $resultado_posterior = $instrucao->get_result();
            $resultado_posterior = $resultado_posterior->fetch_assoc();
            if ($resultado_posterior["PRAZO1"] != NULL) {
                if ($resultado_posterior["PRAZO1"] < $Data) {
                    echo $Nome . " Não pode acontecer antes de " . $resultado_posterior['NOME'];
                    return "Não funcionou.";
                }
            }
        }
    }

    $query = "UPDATE EVENTO SET PRAZO1 = '{$Data}' WHERE NOME = '{$Nome}'";
    mysqli_query($conn, $query);

    header("location: /SGE/GerenciarEventos.php");
}

function AdicionarSemestral($Nome, $Data1, $Data2, $conn)
{
    $elementos = func_get_args();
    if ($Data1 == NULL && $Data2 == NULL) {
        echo "<div class='erro'>Preencha ambas as datas</div>";
        return "Não funcionou.";
    }
    if ($Data1 > $Data2) {
        echo "<div class='erro'>A primeira data não deve vir após a segunda.</div>";
        return "Não funcionou.";
    } elseif ($Data2 < $Data1) {
        echo "<div class='erro'>A segunda data não deve vir antes da primeira.</div>";
        return "Não funcionou.";
    }

    $query = "UPDATE EVENTO SET PRAZO1 = '{$Data1}', PRAZO2 = '{$Data2}' WHERE NOME = '{$Nome}'";
    mysqli_query($conn, $query);

    header("location: /SGE/GerenciarEventos.php");
}

$inclui = "";
$numero = 1;
$ultimoID = "SELECT * FROM EVENTO ORDER BY IDEVENTO DESC LIMIT 1";
$resultadoID = $conn->query($ultimoID);
$resultadoID = $resultadoID->fetch_assoc();
while ($numero <= $resultadoID['IDEVENTO']) {
    $sql = "SELECT * FROM EVENTO WHERE IDEVENTO = $numero";
    $resultadoverificacao = $conn->query($sql);
    $resultadolista = $resultadoverificacao->fetch_assoc();
    if ($resultadolista['PRAZO1'] != NULL) {
        $inclui .= (string)$resultadolista['NOME'];
    };
    $numero += 1;
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="stylesGerenciarEventos.css">
    <title>Gerenciar Eventos / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <?php
    // Anuais
    if (isset($_POST['Parcial_1Submit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarAnual("Parcial_1", $_POST['calendarioParcial_1'], $conn);
    }
    if (isset($_POST['Parcial_2Submit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarAnual("Parcial_2", $_POST['calendarioParcial_2'], $conn);
    }
    if (isset($_POST['Semestral_1Submit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarAnual("Semestral_1", $_POST['calendarioSemestral_1'], $conn);
    }
    if (isset($_POST['Semestral_2Submit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarAnual("Semestral_2", $_POST['calendarioSemestral_2'], $conn);
    }
    if (isset($_POST['Final_de_AnoSubmit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarAnual("Final_de_Ano", $_POST['calendarioFinal_de_Ano'], $conn);
    }

    // Semestrais
    if (isset($_POST['Plano_de_TrabalhoSubmit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarSemestral("Plano_de_Trabalho", $_POST['calendarioPlano_de_Trabalho1'], $_POST['calendarioPlano_de_Trabalho2'], $conn);
    }
    if (isset($_POST['Relatorio_de_AtividadesSubmit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarSemestral("Relatorio_de_Atividades", $_POST['calendarioRelatorio_de_Atividades1'], $_POST['calendarioRelatorio_de_Atividades2'], $conn);
    }
    if (isset($_POST['Recuperacao_ParalelaSubmit'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = AdicionarSemestral("Recuperacao_Paralela", $_POST['calendarioRecuperacao_Paralela1'], $_POST['calendarioRecuperacao_Paralela2'], $conn);
    }
    ?>

    <div class="slidebar">

        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
        <hr>

        <div class="conta">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-user-circle"></i>
                <span style="margin-left: 8px;">Minha conta</span>
            </a><br>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-clipboard-notes"></i>
                <span style="margin-left: 8px;">Tabelas</span>
            </a><br>
            <div class="abretab">
                <div class="tabquanti">
                    <a href="/SGE/TabelasQuantitativas/SelecionarTurmas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Quantitativas</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/TabelasQualitativas/Tabelas.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Tabelas Qualitativas</span>
                    </a><br>
                </div>
            </div>
        </div>

        <div class="tabelas">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-folder-open"></i>
                <span style="margin-left: 8px;">Arquivos</span>
            </a><br>
            <div class="abretab">
                <div class="arq">
                    <a href="/SGE/Arquivos.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Plano de Trabalho e Relatório de Atividades</span>
                    </a><br>
                </div>

                <div class="tabquali">
                    <a href="/SGE/ArquivosRecuperacao.php" class="menu-item" style="display:flex; align-items:center;">
                        <span style="margin-left: 8px;">Recuperação Paralela</span>
                    </a><br>
                </div>
            </div>
        </div>


        <div class="admlinks">
            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-users-alt"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-book-open"></i>';
                echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';

                echo '<a href="/SGE/GerenciarSetores.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-user-check"></i>';
                echo '<span style="margin-left: 8px;">Atividade Setorial</span></a><br>';
            }
            ?>
        </div>

        <?php
        if ($_SESSION['Tipo'] != 'ADM') {
            echo '<div class="baixo">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>

        <?php
        if ($_SESSION['Tipo'] == 'ADM') {
            echo '<div class="btsadm">';
            echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
            echo '<i class="uil uil-signout"></i>';
            echo '<span style="margin-left: 8px;">Sair</span></a><br>';

            echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
            echo '<i class="uil uil-exclamation-triangle"></i>';
            echo '<span style="margin-left: 8px;">Relatar Sugestão</span></a><br>';
            echo '</div>';
        }
        ?>


        <!-- Barra que segue o mouse -->
        <div class="highlight-bar"></div>

    </div>
    <div id="IncluiFalso">
        <form enctype="multipart/form-data" id="PrazoCadastro" action="GerenciarEventos.php" method="post" autocomplete="off">

            <table>
                <h3>Você não adicionou prazos aos seguintes eventos:</h3>
                <?php

                for ($i = 1; $i <= 8; $i++) {
                    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE IDEVENTO = {$i}");
                    $instrucao->execute();
                    $resultado = $instrucao->get_result();
                    $resultado = $resultado->fetch_assoc();
                    if (!str_contains($inclui, (string)$resultado['NOME'])) {
                        $Spaced =  str_replace('_', ' ', (string)$resultado['NOME']);
                        if ($Spaced != "Plano de Trabalho" && $Spaced != "Relatorio de Atividades" && $Spaced != "Recuperacao Paralela") {
                ?>

                            <td>
                                <div class="quadradoevento">
                                    <h2><?php echo $Spaced ?></h2>
                                    <label for="calendario<?php echo (string)$resultado['NOME'] ?>">Adicionar Data para <?php echo $Spaced ?></label><br>
                                    <input type="date" id="calendario<?php echo (string)$resultado['NOME'] ?>" name="calendario<?php echo (string)$resultado['NOME'] ?>"></input>
                                    <input class="botaoum" type="submit" name="<?php echo (string)$resultado['NOME'] ?>Submit" value="Salvar Data"><br>
                                </div>
                            </td>
                        <?php
                        } else {
                        ?>
                            <td>
                                <div class="quadradoevento2">
                                    <h2><?php echo $Spaced ?></h2>
                                    <label for="calendario<?php echo (string)$resultado['NOME'] ?>1">Adicionar Data para Primeiro Semestre de <?php echo $Spaced ?></label><br>
                                    <input type="date" id="calendario<?php echo (string)$resultado['NOME'] ?>1" name="calendario<?php echo (string)$resultado['NOME'] ?>1"></input>
                                    <br><br>
                                    <label for="calendario<?php echo (string)$resultado['NOME'] ?>2">Adicionar Data para Segundo Semestre de <?php echo $Spaced ?></label><br>
                                    <input type="date" id="calendario<?php echo (string)$resultado['NOME'] ?>2" name="calendario<?php echo (string)$resultado['NOME'] ?>2"></input>
                                    <input class="botao" type="submit" name="<?php echo (string)$resultado['NOME'] ?>Submit" value="Salvar Data"><br>
                                </div>
                            </td>
                <?php
                        }
                    }
                    if (($i % 2 == 0)) {
                        echo '</tr><tr>';
                    }
                }
                ?>
            </table>
        </form>
    </div>

    <div id="IncluiVerdadeiro">
        <table>
            <h3>Você já adicionou prazos aos seguintes eventos:</h3>
            <?php

            for ($i = 1; $i <= 8; $i++) {
                $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE IDEVENTO = {$i}");
                $instrucao->execute();
                $resultado = $instrucao->get_result();
                $resultado = $resultado->fetch_assoc();
                if (str_contains($inclui, (string)$resultado['NOME'])) {
                    $Spaced =  str_replace('_', ' ', (string)$resultado['NOME']);
            ?>
                    <td>
                        <div class="quadradoevento3">
                            <h2><?php echo $Spaced ?></h2>
                            <hr style="border: solid 1px #f0ffff;">
                            <p> Você já determinou uma data limite para esse evento.</p>
                            <hr style="border: solid 1px #f0ffff;">
                            <p> <?php echo $resultado["PRAZO1"] ?></p>
                            <?php
                            if ($resultado['PRAZO2'] != NULL) {
                            ?>
                                <p> <?php echo $resultado["PRAZO2"] ?></p>
                            <?php
                            }
                            echo '<p> <a href="AlterarEventos.php?id=' . $resultado["IDEVENTO"] . '">Editar</a>
                            <a href="DeletarEventos.php?id=' . $resultado["IDEVENTO"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse evento?\');">Deletar</a> </p>' . '</p> </div>'
                            ?>
                        </div>
                    </td>
            <?php
                }
                if (($i % 2 == 0)) {
                    echo '</tr><tr>';
                }
            }
            ?>
        </table>
    </div>


</body>

</html>