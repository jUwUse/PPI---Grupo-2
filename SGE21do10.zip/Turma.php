<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} 
else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

if (isset($_SESSION['Turma']) == FALSE) {
    if (isset($_GET['id'])) {
        $_SESSION['Turma'] = $_GET['id'];
    }
    else {
        header("location: Home.php");
        
        exit();
    }
}

if (isset($_GET['id'])) {
    $_SESSION['Turma'] = $_GET['id'];
}

//Pra fazer o título :P
$selectnumero = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
$selectnumero->bind_param("i", $_SESSION['Turma']); //s=string, i=int, d=double
$selectnumero->execute();
$resultadonumero = $selectnumero->get_result();
$resultadonumero = $resultadonumero->fetch_assoc();

//Parte do Filtro
$Aplicado = @$_GET['FiltroSubmit'];
$lista = array(@$_GET['NomeFiltro'], @$_GET['FiltroMedia'], @$_GET['FiltroMatricula']);
$lista_pos = array("NOME", "MEDIA", "MATRICULA");

function SomenteNulo($lista) { //Verifica se todos os parâmetros estão vazios. Isso é, o filtro foi solicitado, mas sem selecionar nada.
    foreach ($lista as $i) {
        if ($i !== "" && $i !== NULL) {
            return false;
        }
    }
    return true;
}

function GerarSQL($lista, $lista_pos, $numero, $idturma) { //Cria o comando de select com base nos parâmetros fornecidos no filtro.
    $primeiro_a_entrar = 0;
    $sql = "SELECT * FROM ALUNO WHERE IDTURMA = $idturma AND IDALUNO = $numero AND ";
    for ($z = 0; $z < sizeof($lista); $z++) {
        if ($lista[$z] != NULL && $lista[$z] != "") {
            if ($primeiro_a_entrar == 0) {
                $sql .= $lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
                $primeiro_a_entrar++;
            }
            else {
                $sql .= "AND ".$lista_pos[$z] . ' LIKE "%' . $lista[$z] . '%"';
            }
        }
    }
    $sql .= ";";
    return $sql;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="stylesturma.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Turma <?php echo $resultadonumero['NUMERO']?> / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarCursos.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>

        <div class="add">
            <a href='/SGE/AdicionarAlunos.php?id=<?php echo $_SESSION['Turma']?>' class="menu-item" style="display:flex; align-items:center; white-space: nowrap;">
                <i class="uil uil-plus-circle"></i>
                <span style="margin-left: 8px;">Adicionar Alunos</span>
            </a><br>
        </div>
    </div>

    <div class="header">
        <h1> Turma <?php echo $resultadonumero["NUMERO"] ?></h1>
    </div>

    <div class="CampodeFiltro">
        <form action="" class="FormulariodeFiltro" method="GET" >
            <label for="NomeFiltro">Nome do Aluno:</label><br>
            <input class="campo" type="text" id="NomeFiltro" name="NomeFiltro" value="<?php echo @$_GET['NomeFiltro']; ?>"><br>
            <span class="Botoes">
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#OpcoesOcultas" >
                    Mais opções
                </button>

                <button class="btn btn-light" type="button" onClick="location.href='/SGE/GerenciarCursos.php'">
                    Limpar Filtro
                </button>

                <input class="btn btn-light" type="submit" name="FiltroSubmit" value="Aplicar">
            </span>

            <div class="collapse" id="OpcoesOcultas" style="margin-top: 10px;">
                <hr>
                <div class="d-inline-flex gap-5">
                    <span>
                        <label for="FiltroMedia">Media:</label><br>
                        <input class="campoextra" type="number" id="FiltroMedia" name="FiltroMedia" value="<?php echo @$_GET['FiltroMedia']; ?>"><br>
                    </span>

                    <span>
                        <label for="FiltroMatricula">Matrícula:</label><br>
                        <input class="campoextra" type="text" id="FiltroMatricula" name="FiltroMatricula" value="<?php echo @$_GET['FiltroMatricula']; ?>"><br>
                    </span>
                </div>
            </div>
        </form>
        <hr>
    </div>

    <div id="SelectDosCursos">
        <?php
        $numero = 1;
        $numero2 = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM ALUNO ORDER BY IDALUNO DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Você não possui nenhum aluno cadastrado. Clique no botão do menu lateral para adicionar.</div>";
        } 
        else {
            echo '<table><tr>';
            if (somenteNulo($lista) == true || $Aplicado == NULL) {
                while ($numero <= $resultadoID["IDALUNO"]) {
                    $sql = $conn->prepare("SELECT * FROM ALUNO WHERE IDALUNO = ? AND IDTURMA = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                    $sql->bind_param("ii", $numero, $_SESSION['Turma']); //s=string, i=int, d=double
                    $sql->execute();
                    $resultadoverificacao = $sql->get_result();
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {
                        if ($i<=3) {
                            echo '<td>
                                <div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . '</p> 
                                <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_aluno/'.$resultadolista['FOTO'].'" alt="foto de '.$resultadolista["NOME"].'"> </p>
                                <p>' . $resultadolista["MATRICULA"] . '</p> 
                                <p>' . $resultadolista["MEDIA"] . '</p> 
                                <p> <a href="AlterarAlunos.php?id='. $resultadolista["IDALUNO"] .'">Editar</a> 
                                <a href="DeletarAlunos.php?id='. $resultadolista["IDALUNO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p> </div>
                                </td>'; 
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> 
                            <p>' . $resultadolista["NOME"] . '</p> 
                            <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_aluno/'.$resultadolista['FOTO'].'" alt="foto de '.$resultadolista["NOME"].'"> </p>
                            <p>' . $resultadolista["MATRICULA"] . '</p> 
                            <p>' . $resultadolista["MEDIA"] . '</p> 
                            <p> <a href="AlterarAlunos.php?id='. $resultadolista["IDALUNO"] .'">Editar</a> 
                            <a href="DeletarAlunos.php?id='. $resultadolista["IDALUNO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p> </div></td>'; 
                            $i = 0;
                        }
                        $i ++;
                    }
                    $numero += 1;
                }
            }
            else {
                while ($numero <= $resultadoID["IDALUNO"]) {
                    if ($numero2 <= $resultadonumero["IDTURMA"]) {
                        $funcaoDeFiltro = GerarSQL($lista, $lista_pos, $numero2, $_SESSION['Turma']);
                        $resultadoverificacao = $conn->query($funcaoDeFiltro);
                        $resultadolista = $resultadoverificacao->fetch_assoc();
                        foreach ($resultadoverificacao as $j) {
                            if ($i<=3) {
                                echo '<td>
                                    <div class="quadrado"> 
                                    <p>' . $resultadolista["NOME"] . '</p> 
                                    <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_aluno/'.$resultadolista['FOTO'].'" alt="foto de '.$resultadolista["NOME"].'"> </p>
                                    <p>' . $resultadolista["MATRICULA"] . '</p> 
                                    <p>' . $resultadolista["MEDIA"] . '</p> 
                                    <p> <a href="AlterarAlunos.php?id='. $resultadolista["IDALUNO"] .'">Editar</a> 
                                    <a href="DeletarAlunos.php?id='. $resultadolista["IDALUNO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p> </div>
                                    </td>'; 
                            }
                            
                            else {       
                                echo '</tr><tr>';
                                echo '<td><div class="quadrado"> 
                                <p>' . $resultadolista["NOME"] . '</p> 
                                <p> <img style="border-radius: 50%;" width="70" height="70" src="./images_aluno/'.$resultadolista['FOTO'].'" alt="foto de '.$resultadolista["NOME"].'"> </p>
                                <p>' . $resultadolista["MATRICULA"] . '</p> 
                                <p>' . $resultadolista["MEDIA"] . '</p> 
                                <p> <a href="AlterarAlunos.php?id='. $resultadolista["IDALUNO"] .'">Editar</a> 
                                <a href="DeletarAlunos.php?id='. $resultadolista["IDALUNO"] .'" onclick="return confirm(\'Tem certeza que quer excluir esse curso?\');">Deletar</a> </p> </div></td>'; 
                                $i = 0;
                            }
                            $i ++;
                        }
                    }
                    $numero += 1;
                    $numero2 = 1;
                }
            }
        }

            echo '</table>';
        ?>

    </div>

</body>

</html>