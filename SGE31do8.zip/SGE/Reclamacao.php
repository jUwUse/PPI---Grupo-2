<?php
    error_reporting(E_ALL ^ E_DEPRECATED); 
    include ('Config.php');
    include('Logout_Function.php');

    function Reclamar($Nome, $Mensagem) {
        include ('ConfigMailer.php');

        $mail->addAddress(USERNAME);
        $mail->addReplyTo(REPLY_TO, REPLY_TO_NAME);
        $mail->IsHTML(true);

        $titulo = "Reclamacao de ";
        $titulo .= $Nome;
        $corpo = $Mensagem;

        $mail->Subject = $titulo;
        $mail->Body = $corpo;
        $mail->AltBody = $corpo;

        if(!$mail->send()) {
            echo "Houve um erro com o envio da reclamação. Tente novamente mais tarde.";
            return "não funcionou.";
        }
        else {
            echo "Sua reclamação foi enviada com sucesso!";
            return "funcionou.";
        }

    }

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        header("location: Login.php");
        exit();
    }

    if (isset($_GET['Logout'])) {
        logout();
    }

    if (isset($_POST['ReclamacaoSubmit'])) {
        if (empty($_POST['ReclamacaoInput'])) {
            echo "Digite sua reclamação";
        }
        else {
            $resultado_por_favor = Reclamar($_SESSION["Nome"], $_POST['ReclamacaoInput']);
        }
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reclamacao / SGE</title>
</head>
<body>
    <a href="?Logout">Sair</a><br><br>
    <a href="/SGE/Home.php">Minha conta</a><br>

    <form action="Reclamacao.php" id="FormularioDeReclamacao" method="post" style="display: block;" autocomplete="off">
        <p> Digite sua reclamação no campo abaixo: </p>
        
        <textarea id="ReclamacaoInput" name="ReclamacaoInput" rows="4" cols="50" value="<?php echo @$_POST['ReclamacaoInput']; ?>"></textarea><br>

        <input type="submit" name="ReclamacaoSubmit" value="Enviar"><br>
    </form>
</body>
</html>