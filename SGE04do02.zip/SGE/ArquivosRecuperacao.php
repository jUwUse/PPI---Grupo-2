<?php   
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('Config.php');
include('Logout_Function.php');

if (!isset($_SESSION['Email'])) {
    logout();
}

date_default_timezone_set('America/Sao_Paulo');
$data_Atual = date('Y-m-d', time());

function isPrazoValid($prazo1, $prazo2, $currentDate) {
    if (is_null($prazo1) && is_null($prazo2)) {
        return "NO_PRAZO_DEFINED";
    }
    if (!is_null($prazo1) && $currentDate <= $prazo1) {
        return "PRAZO1_VALID";
    }
    if (!is_null($prazo2) && (is_null($prazo1) || $currentDate > $prazo1) && $currentDate <= $prazo2) {
        return "PRAZO2_VALID";
    }
    return "PRAZO_EXPIRED";
}

function getPrazoStatus($conn, $documento) {
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
    $instrucao->bind_param("s", $documento);
    $instrucao->execute();
    $resultado = $instrucao->get_result()->fetch_assoc();
    return [
        'status' => isPrazoValid($resultado["PRAZO1"], $resultado["PRAZO2"], $GLOBALS['data_Atual']),
        'prazo' => (!is_null($resultado["PRAZO1"]) && $GLOBALS['data_Atual'] <= $resultado["PRAZO1"]) ? $resultado["PRAZO1"] : $resultado["PRAZO2"]
    ];
}

function usuarioJaEnviouRecuperacao($conn, $iduser, $idDisciplina, $prazoFinal) {
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ? AND DATA_ENVIO <= ?");
    $instrucao->bind_param("iis", $iduser, $idDisciplina, $prazoFinal);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    if ($instrucao->fetch()) {
        return $arquivo;
    }
    return false;
}

function removerArquivoRecuperacao($conn, $iduser, $idDisciplina) {
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ?");
    $instrucao->bind_param("ii", $iduser, $idDisciplina);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    
    if ($instrucao->fetch() && $arquivo) {
        $caminho = "images_recuperacao/" . $arquivo;
        
        if (file_exists($caminho)) {
            unlink($caminho);
        }
        
        $instrucao->close();
        
        $deleteInstrucao = $conn->prepare("DELETE FROM RECUPERACAO_PARALELA WHERE IDUSER = ? AND IDDISCIPLINA = ?");
        $deleteInstrucao->bind_param("ii", $iduser, $idDisciplina);
        $deleteInstrucao->execute();
        $deleteInstrucao->close();

        echo "<div class='sucesso'>Arquivo removido com sucesso!</div>";
    } else {
        echo "<div class='erro'>Erro ao remover o arquivo.</div>";
    }
}

$prazoRecuperacao = getPrazoStatus($conn, 'Recuperacao_Paralela');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['removerArquivoRecuperacao'])) {
        removerArquivoRecuperacao($conn, $_SESSION["ID"], $_POST['idDisciplina']);
    } elseif (isset($_POST['RecuperacaoParalelaSubmit']) && isset($_FILES['Arquivo'])) {
        $idDisciplina = $_POST['idDisciplina'];
        $arquivoNome = basename($_FILES['Arquivo']['name']);
        $caminhoDestino = "images_recuperacao/" . $arquivoNome;
        
        if (move_uploaded_file($_FILES['Arquivo']['tmp_name'], $caminhoDestino)) {
            $stmt = $conn->prepare("INSERT INTO RECUPERACAO_PARALELA (IDUSER, IDDISCIPLINA, ARQUIVO, DATA_ENVIO) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $_SESSION["ID"], $idDisciplina, $arquivoNome, $data_Atual);
            $stmt->execute();
            $stmt->close();
            echo "<div class='sucesso'>Arquivo enviado com sucesso!</div>";
        } else {
            echo "<div class='erro'>Erro ao enviar o arquivo.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Recuperação Paralela / SGE</title>
</head>
<body>
    <h3>Recuperação Paralela</h3>
    <?php 
    $instrucao = $conn->prepare("SELECT D.IDDISCIPLINA, D.NOME, D.IDTURMA FROM LECIONA L JOIN DISCIPLINA D ON L.IDDISCIPLINA = D.IDDISCIPLINA WHERE L.IDUSER = ?");
    $instrucao->bind_param("i", $_SESSION["ID"]);
    $instrucao->execute();
    $disciplinas = $instrucao->get_result();
    while ($disciplina = $disciplinas->fetch_assoc()) : 
        $arquivoEnviado = usuarioJaEnviouRecuperacao($conn, $_SESSION["ID"], $disciplina['IDDISCIPLINA'], $prazoRecuperacao['prazo']);
        $instrucaoTurma = $conn->prepare("SELECT * FROM TURMA WHERE IDTURMA = {$disciplina['IDTURMA']}");
        $instrucaoTurma->execute();
        $NumeroTurma = $instrucaoTurma->get_result();
        $NumeroTurma = $NumeroTurma->fetch_assoc()
    ?>
        <h4><?= $disciplina['NOME'] ?><?php echo ' Turma '.$NumeroTurma['NUMERO']?></h4>
        <?php if ($arquivoEnviado) : ?>
            <p><strong>Você já enviou um documento para esta disciplina.</strong></p>
            <form method="post">
                <input type="hidden" name="idDisciplina" value="<?= $disciplina['IDDISCIPLINA'] ?>">
                <button type="submit" name="removerArquivoRecuperacao">Remover Arquivo</button>
            </form>
        <?php else : ?>
            <form enctype="multipart/form-data" method="post">
                <input type="hidden" name="idDisciplina" value="<?= $disciplina['IDDISCIPLINA'] ?>">
                <input type="file" name="Arquivo" required>
                <button type="submit" name="RecuperacaoParalelaSubmit">Enviar</button>
            </form>
        <?php endif; ?>
    <?php endwhile; ?>
</body>
</html>