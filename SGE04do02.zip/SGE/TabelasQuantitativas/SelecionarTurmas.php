<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('../Config.php');
include('../Logout_Function.php');
include('../Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
}

function MostrandoTurmas($numero, $duracao, $conn) { //Exibe as turmas abaixo dos curso. Boa sorte.
    for ($ano = 1; $ano <= $duracao; $ano++) {
        $sqlturma = "SELECT * FROM TURMA WHERE IDCURSO = $numero AND ANO = $ano";
        $resultadoverificacaoturma = $conn->query($sqlturma);
        $resultadolistaturma = $resultadoverificacaoturma->fetch_assoc();
        echo "<script> document.getElementById('ParteDasTurmas".($numero)."').innerHTML += '<a class=\"confia\" href=\"/SGE/TabelasQuantitativas/SelecionarDisciplinas.php?id=".$resultadolistaturma["IDTURMA"]."\">". $resultadolistaturma["NUMERO"] ."</a>'; </script>";
    }
    $ano = 1;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="../stylesselecionarturmas.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Tabelas Quantitativas / Selecionar Turmas / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div id="SelectDosCursos">
        <?php
        $numero = 1;
        $i = 0;
        $ultimoID = "SELECT * FROM CURSO ORDER BY IDCURSO DESC LIMIT 1";
        $resultadoID = $conn->query($ultimoID);
        $resultadoID = $resultadoID->fetch_assoc();
        if ($resultadoID == NULL) {
            echo "<div class='nenhumcurso'>Nenhum curso foi cadastrado ainda.</div>";
        } 
        else {
            echo '<table><tr>';
                while ($numero <= $resultadoID["IDCURSO"]) {
                    $sql = "SELECT * FROM CURSO WHERE IDCURSO = $numero";
                    $resultadoverificacao = $conn->query($sql);
                    $resultadolista = $resultadoverificacao->fetch_assoc();
    
                    foreach ($resultadoverificacao as $j) {
                        if ($i<=2) {
                            echo '<td>
                                <div class="quadrado"> 
                                <img src="../images_curso/'.$resultadolista['FOTO'].'" alt="logo">
                                </b>' . $resultadolista["NOME"] . '</b>
                                <hr>
                                <p> Escolha uma turma para continuar </p>
                                <p id="ParteDasTurmas'.$numero.'"></p></div>
                                </td>'; 
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        
                        else {       
                            echo '</tr><tr>';
                            echo '<td><div class="quadrado"> 
                            <img src="../images_curso/'.$resultadolista['FOTO'].'" alt="logo">
                            <b>' . $resultadolista["NOME"] . '</b>
                            <hr>
                            <p> Escolha uma turma para continuar </p>
                            <p id="ParteDasTurmas'.$numero.'"></p> 
                            </div></td>'; 
                            $i = 0;
                            MostrandoTurmas($numero, $resultadolista["DURACAO"], $conn);
                        }
                        $i ++;
                    }
                    $numero += 1;
                }
        }

            echo '</table>';
        ?>

    </div>

</body>

</html>