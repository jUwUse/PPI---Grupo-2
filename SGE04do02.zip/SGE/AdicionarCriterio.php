<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include('Config.php');
include('Logout_Function.php');
include('Verify_Cookies.php');

if (isset($_SESSION['Email']) == FALSE) {
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") {
        header("location: Home.php");
        exit();
    }
}

// Fetch subavaliacoes from the database
function fetch_subavaliacoes($pertence) {
    global $conn;
    $query = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE PERTENCE = ?");
    $query->bind_param("s", $pertence);
    $query->execute();
    $result = $query->get_result();
    $subavaliacoes = [];
    while ($row = $result->fetch_assoc()) {
        $subavaliacoes[] = $row;
    }
    return $subavaliacoes;
}

function get_total_peso($pertence) {
    global $conn;
    $query = $conn->prepare("SELECT SUM(PESO) as total_peso FROM SUBAVALIACAO WHERE PERTENCE = ?");
    $query->bind_param("s", $pertence);
    $query->execute();
    $result = $query->get_result();
    $row = $result->fetch_assoc();
    return $row['total_peso'];
}

function get_geral_peso($pertence) {
    global $conn;
    $query = $conn->prepare("SELECT PESO FROM SUBAVALIACAO WHERE NOME = 'Geral' AND PERTENCE = ?");
    $query->bind_param("s", $pertence);
    $query->execute();
    $result = $query->get_result();
    $row = $result->fetch_assoc();
    return $row['PESO'];
}

function update_geral_peso($pertence, $novo_peso) {
    global $conn;
    $query = $conn->prepare("UPDATE SUBAVALIACAO SET PESO = ? WHERE NOME = 'Geral' AND PERTENCE = ?");
    $query->bind_param("is", $novo_peso, $pertence);
    $query->execute();
}

function AdicionarSub($Nome, $Peso, $conn, $Pertence) {
    $elementos = func_get_args();

    foreach ($elementos as $valor) {
        if ($valor != $conn && preg_match("/([<|>])/", $valor) == TRUE) {
            echo "<div class='erro'>Para evitar problemas de segurança, os caracteres '<' e '>' não são permitidos.</div>";
            return "não funcionou.";
        }
    }

    if (strlen($Nome) > 100) {
        echo "<div class='erro'>O nome de uma disciplina não pode ter mais de 100 caracteres.</div>";
        return "não funcionou.";
    }
    if ($Peso <= 0) {
        echo "<div class='erro'>O peso de uma subavaliação deve ser maior que zero.</div>";
        return "não funcionou.";
    }

    $total_peso = get_total_peso($Pertence);
    $peso_geral = get_geral_peso($Pertence);

    if (($total_peso + $Peso) > 100) {
        if ($peso_geral >= ($total_peso + $Peso - 100)) {
            $novo_peso_geral = $peso_geral - ($total_peso + $Peso - 100);
            update_geral_peso($Pertence, $novo_peso_geral);
        } else {
            echo "<div class='erro'>O peso total das subavaliações não pode exceder 100%, mesmo ajustando o peso de 'Geral'.</div>";
            return "não funcionou.";
        }
    }

    $instrucao = $conn->prepare("SELECT * FROM SUBAVALIACAO WHERE NOME = ? AND PERTENCE = ?");
    $instrucao->bind_param("ss", strtoupper($Nome), $Pertence);
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc();
    if ($resultado != NULL) {
        echo "<div class='erro'>Uma subavaliação com esse nome já existe nesse semestre.</div>";
        return "não funcionou.";
    }

    $instrucao_disciplina = $conn->prepare("INSERT INTO SUBAVALIACAO(NOME, PERTENCE, PESO) VALUES(?, ?, ?)");
    $instrucao_disciplina->bind_param("ssi", strtoupper($Nome), $Pertence, $Peso);
    $instrucao_disciplina->execute();
    if ($conn->affected_rows != 1) {
        echo "<div class='erro'>Um erro desconhecido ocorreu. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    }

    $NomeCompleto = "GERAL_".$Pertence;
    $instrucao = $conn->prepare("ALTER TABLE NOTAS ADD COLUMN IF NOT EXISTS {$NomeCompleto} INT DEFAULT 0");
    $instrucao->execute();

    $Unspaced = str_replace(' ', '_', $Nome);
    $Unspaced_and_unaccented = strtr(utf8_decode($Unspaced), utf8_decode('àáâãäçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ'), 'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY');
    $Unspaced_and_unaccented_and_miniscule = strtoupper($Unspaced_and_unaccented);
    $instrucao = $conn->prepare("ALTER TABLE NOTAS ADD COLUMN {$Unspaced_and_unaccented_and_miniscule} INT DEFAULT 0;");
    $instrucao->execute();

    // Update "Geral" peso
    $novo_total_peso = $total_peso + $Peso;
    if ($novo_total_peso <= 100) {
        $novo_peso_geral = 100 - $novo_total_peso;
        update_geral_peso($Pertence, $novo_peso_geral);
    }
    header("location: AdicionarCriterio.php");
}

$subavaliacoes_primeiro = fetch_subavaliacoes('PRIMEIRO_SEMESTRE');
$subavaliacoes_segundo = fetch_subavaliacoes('SEGUNDO_SEMESTRE');
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="stylesgerenciardisciplinas.css">
    <title>Adicionar Critérios Avaliativos / SGE</title>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <span>
        <?php
        if (isset($_POST['ModalSubmit'])) {
            $resultado_final_decisivo_mega_importante = AdicionarSub($_POST['nome'], $_POST['peso'], $conn, $_POST['pertence']);
        }
        ?>
    </span>

    <table>
        <tr>
            <td>
                <div class="quadradodisciplina">
                    <p>Primeiro Semestre (100%)</p>
                    <div class="accordion" id="accordionExample1">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne1">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1">
                                    Detalhes
                                </button>
                            </h2>
                            <div id="collapseOne1" class="accordion-collapse collapse" aria-labelledby="headingOne1" data-bs-parent="#accordionExample1">
                                <div class="accordion-body">
                                    <?php foreach ($subavaliacoes_primeiro as $subavaliacao): ?>
                                        <p><?php echo $subavaliacao['NOME'] . " - Peso: " . $subavaliacao['PESO']; ?></p>
                                        <?php 
                                            if ($subavaliacao['NOME'] != "Geral") {
                                                echo '<p> <a href="DeletarCriterio.php?id=' . $subavaliacao["IDSUBAVALIACAO"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse criterio?\');">Deletar</a> </p>';
                                            };
                                        ?>
                                        
                                    <?php endforeach; ?>
                                    <button class="btn btn-primary" onclick="openModal('PRIMEIRO_SEMESTRE')">Adicionar SubAvaliacao</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </td>

            <td>
                <div class="quadradodisciplina">
                    <p>Segundo Semestre (100%)</p>
                    <div class="accordion" id="accordionExample2">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo2">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo2" aria-expanded="true" aria-controls="collapseTwo2">
                                    Detalhes
                                </button>
                            </h2>
                            <div id="collapseTwo2" class="accordion-collapse collapse" aria-labelledby="headingTwo2" data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    <?php foreach ($subavaliacoes_segundo as $subavaliacao): ?>
                                        <p><?php echo $subavaliacao['NOME'] . " - Peso: " . $subavaliacao['PESO']; ?></p>
                                        <?php 
                                            if ($subavaliacao['NOME'] != "Geral") {
                                                echo '<p> <a href="DeletarCriterio.php?id=' . $subavaliacao["IDSUBAVALIACAO"] . '" onclick="return confirm(\'Tem certeza que quer excluir esse criterio?\');">Deletar</a> </p>';
                                            };
                                        ?>
                                    <?php endforeach; ?>
                                    <button class="btn btn-primary" onclick="openModal('SEGUNDO_SEMESTRE')">Adicionar SubAvaliacao</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="addSubAvaliacaoModal" tabindex="-1" aria-labelledby="addSubAvaliacaoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addSubAvaliacaoModalLabel">Adicionar SubAvaliacao</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addSubAvaliacaoForm" action="AdicionarCriterio.php" method="POST">
                        <div class="mb-3">
                            <label for="nome" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>
                        <div class="mb-3">
                            <label for="peso" class="form-label">Peso</label>
                            <input type="number" class="form-control" id="peso" name="peso" required>
                        </div>
                        <input type="hidden" id="pertence" name="pertence">
                        <button type="submit" name="ModalSubmit" class="btn btn-primary">Adicionar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openModal(pertence) {
            const modalTitle = document.getElementById('addSubAvaliacaoModalLabel');
            if (pertence === 'PRIMEIRO_SEMESTRE') {
                modalTitle.textContent = 'Adicionar SubAvaliacao - Primeiro Semestre';
            } else if (pertence === 'SEGUNDO_SEMESTRE') {
                modalTitle.textContent = 'Adicionar SubAvaliacao - Segundo Semestre';
            }
            
            const modal = new bootstrap.Modal(document.getElementById('addSubAvaliacaoModal'));
            document.getElementById('pertence').value = pertence;
            modal.show();
        }

    </script>
</body>
</html>