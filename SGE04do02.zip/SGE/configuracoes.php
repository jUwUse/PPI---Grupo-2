<?php
    error_reporting(E_ALL ^ E_DEPRECATED); // Criei uma página separada para o logout porque ele meio que pode ser feito de várias páginas, eu acho. Daí é melhor chamar a função por fora do que definir ela sempre.
    include('Config.php');
    include('Logout_Function.php');
    include('Verify_Cookies.php');

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        header("location: Login.php");
        exit();
    }

    if (isset($_GET['Logout'])) {
        logout();
    }

    if (isset($_GET["Temas"])) {
        $style_escolhido = $_GET['Temas'];
        setcookie('estilo', $style_escolhido, time()+60*60*24*100, "/");
        header("location: configuracoes.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="<?php echo $tema_escolhido;?>.css">
    <link rel="stylesheet" href="stylesconfig.css">
    <title>Configurações / SGE</title>

</head>
<body>
    <div class="container-fluid">
        <div class="slidebar">
            <img class="logoiff" src="images/logoiff.png" alt="Logoiff">
            <hr>
            <div class="conta">
                <a href="/SGE/Home.php" class="menu-item" style="display:flex; align-items:center;">
                    <i class="uil uil-user-circle"></i>
                    <span style="margin-left: 8px;">Minha conta</span>
                </a><br>
            </div>
            <div class="tabelas">
                <a href="www.youtube.com/watch?v=yTsINmrAK4I" class="menu-item" style="display:flex; align-items:center;">
                    <i class="uil uil-clipboard-notes"></i>
                    <span style="margin-left: 8px;">Tabelas</span>
                </a><br>
            </div>
            <div class="arquivos">
                <a href="www.youtube.com/watch?v=yTsINmrAK4I" class="menu-item" style="display:flex; align-items:center;">
                    <i class="uil uil-folder-open"></i>
                    <span style="margin-left: 8px;">Arquivos</span>
                </a><br>
            </div>

            <div class="admlinks">
                <?php
                if ($_SESSION['Tipo'] == 'ADM') {
                    echo '<a href="/SGE/GerenciarUsuários.php" id="CriarUser" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                    echo '<i class="uil uil-users-alt"></i>';
                    echo '<span style="margin-left: 8px;">Gerenciar Usuários</span></a><br>';

                    echo '<a href="/SGE/GerenciarCursos.php" id="CriarCursos" class="menu-item" style="display: flex; align-items: center; white-space: nowrap;">';
                    echo '<i class="uil uil-book-open"></i>';
                    echo '<span style="margin-left: 8px;">Gerenciar Cursos</span></a><br>';
                }
                ?>
            </div>

            <?php
            if ($_SESSION['Tipo'] != 'ADM') {
                echo '<div class="baixo">';
                echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-signout"></i>';
                echo '<span style="margin-left: 8px;">Sair</span></a><br>';

                echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
                echo '<i class="uil uil-exclamation-triangle"></i>';
                echo '<span style="margin-left: 8px;">Relatar Problema</span></a><br>';
                echo '</div>';
            }
            ?>

            <?php
            if ($_SESSION['Tipo'] == 'ADM') {
                echo '<div class="baixoadm">';
                echo '<a href="?Logout" style="display: flex; align-items: center; white-space: nowrap;">';
                echo '<i class="uil uil-signout"></i>';
                echo '<span style="margin-left: 8px;">Sair</span></a><br>';

                echo '<a href="/SGE/Reclamacao.php" style="display: flex; align-items: center; white-space: nowrap;;">';
                echo '<i class="uil uil-exclamation-triangle"></i>';
                echo '<span style="margin-left: 8px;">Relatar Problema</span></a><br>';
                echo '</div>';
            }
            ?>

                <!-- Barra que segue o mouse -->
            <div class="highlight-bar"></div>
                
        </div>
    </div>

    <div class="row quadrado">
            <span id="formColor" style="display: block;">
                <form action="configuracoes.php" id="FormularioDeCores" method="GET" autocomplete="off">
                    <label for="Temas">Tema de cor:</label><br>
                    <select name="Temas" id="Temas">
                        <option value="styleszdefault">Roxo (Padrão)</option>
                        <option value="styleszdark">Escuro</option>
                        <option value="stylesziffar">IFFAR</option>
                    </select>
                    <br>
                    <br>
                    <input type="submit" value="Salvar Alterações">
                </form>

                <br>
            </span>
    </div>
</body>
</html>