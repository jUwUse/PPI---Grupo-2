<?php //Preenche os dados.
include("Config.php");
include("Logout_Function.php");

if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
    logout();
} else {
    if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
        header("location: Home.php");
        exit();
    }
}

function Alterar($Data1, $Data2, $conn, $id, $PossuiDois, $Nome) {
    $elementos = func_get_args();
    if ($Data1 == NULL && $Data2 == NULL) {
        echo "<div class='erro'>Insira as informações que deseja alterar.</div>";
        return "não funcionou.";
    }

    if ($PossuiDois == 1) {
        if ($Data1 == NULL || $Data2 == NULL) {
            echo "<div class='erro'> Insira ambas as datas.</div>";
            return "não funcionou.";
        }

        if ($Data1 > $Data2) {
            echo "A primeira data não deve vir após a segunda.";
            return "Não funcionou.";
        }

        elseif ($Data2 < $Data1) {
            echo "A segunda data não deve vir antes da primeira.";
            return "Não funcionou.";
        }
    
        $query = "UPDATE EVENTO SET PRAZO1 = '{$Data1}', PRAZO2 = '{$Data2}' WHERE IDEVENTO = '{$id}'";
        mysqli_query($conn, $query);
    
        header("location: /SGE/GerenciarEventos.php");
    }

    if ($PossuiDois != 1) {
        $ordem_de_preferencia = array("Parcial_1", "Semestral_1", "Parcial_2", "Semestral_2", "Final_de_Ano");
    
        if ($Data1 == NULL) {
            echo "Preencha a data.";
            return "Não funcionou.";
        }
    
        if (array_search("{$Nome}", $ordem_de_preferencia) != 0) {
            $n = array_search("{$Nome}", $ordem_de_preferencia);
            while ($n >= 0) {
                $n--;
                $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
                $instrucao->bind_param("s", $ordem_de_preferencia[$n]);
                $instrucao->execute();
                $resultado_anterior = $instrucao->get_result();
                $resultado_anterior = $resultado_anterior->fetch_assoc();
                if($resultado_anterior["PRAZO1"] != NULL) {
                    if($resultado_anterior["PRAZO1"] > $Data1) {
                        echo $Nome." Não pode acontecer antes de ".$resultado_anterior['NOME'];
                        return "Não funcionou.";
                    }
                }
            }
        }
    
        if (array_search("{$Nome}", $ordem_de_preferencia) != 4) {
            $n = array_search("{$Nome}", $ordem_de_preferencia);
            while ($n <= 4) {
                $n++;
                $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
                $instrucao->bind_param("s", $ordem_de_preferencia[$n]);
                $instrucao->execute();
                $resultado_posterior = $instrucao->get_result();
                $resultado_posterior = $resultado_posterior->fetch_assoc();
                if($resultado_posterior["PRAZO1"] != NULL) {
                    if($resultado_posterior["PRAZO1"] < $Data1) {
                        echo $Nome." Não pode acontecer depois de ".$resultado_posterior['NOME'];
                        return "Não funcionou.";
                    }
                }
            }
        }
    
        $query = "UPDATE EVENTO SET PRAZO1 = '{$Data1}' WHERE NOME = '{$Nome}'";
        mysqli_query($conn, $query);
    
        header("location: /SGE/GerenciarEventos.php");
    }
}

$IDAEditar = (int)$_GET['id'];
$sql = "SELECT * FROM EVENTO WHERE IDEVENTO = $IDAEditar";
$resultadoverificacao = $conn->query($sql);
$resultadolista = $resultadoverificacao->fetch_assoc();
$Spaced =  str_replace('_', ' ', (string)$resultadolista['NOME']);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesalterarsetores.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Alterar Eventos / SGE</title>

    <script>
        function Cancelar() {
            location.href = '/SGE/GerenciarEventos.php';
        }
    </script>

</head>

<body>
    <?php
    if (isset($_POST['AlteracaoSubmitEvento'])) { // Caso o formulário de professor seja enviado.
        $resultado_final_decisivo_mega_importante = Alterar($_POST['calendario1'], @$_POST['calendario2'], $conn, $IDAEditar, @$PossuiDois, $resultadolista["NOME"]);
        // function Alterar($Nome, $Duracao, $Coordenador, $conn, $id) {
    }
    ?>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/GerenciarSetores.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">

            <p><b>Alterar Evento - <?php echo $Spaced ?></b></p>

            <form enctype="multipart/form-data" action="" id="FormulariodeAlteracaoSetor" method="post">
                
                <?php 
                if ($resultadolista["PRAZO1"] != NULL && $resultadolista["PRAZO2"] == NULL) {
                    $PossuiDois = 0;
                    ?>
                        <h2><?php echo $Spaced?></h2>
                        <label for="calendario1">Alterar Data para <?php echo $Spaced?></label><br>
                        <input value="<?php echo $resultadolista['PRAZO1']?>" type="date" id="calendario1" name="calendario1"></input>
                    <?php
                }
                if ($resultadolista["PRAZO1"] != NULL && $resultadolista["PRAZO2"] != NULL) {
                    $PossuiDois = 1;
                    ?>
                        <h2><?php echo $Spaced?></h2>
                        <label for="calendario1">Alterar Data para Primeiro Semestre de <?php echo $Spaced?></label><br>
                        <input value="<?php echo $resultadolista['PRAZO1']?>" type="date" id="calendario1" name="calendario1"></input>
                        <br><br>
                        <label for="calendario2">Alterar Data para Segundo Semestre de <?php echo $Spaced?></label><br>
                        <input value="<?php echo $resultadolista['PRAZO2']?>" type="date" id="calendario2" name="calendario2"></input>
                        </div></td>
                    <?php
                }
                ?>

                <br>
                <input class="botao" type="submit" name="AlteracaoSubmitEvento" value="Aplicar">
                <input class="botaodois" type="button" onclick="Cancelar()" name="AlteracaoCancel" value="Cancelar"><br>
            </form>

        </div>
    </div>

</body>

</html>