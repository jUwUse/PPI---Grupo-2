<?php   
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('Config.php');
include('Logout_Function.php');

if (!isset($_SESSION['Email'])) {
    logout();
}


$lista_insert = array("Parcial_1", "Semestral_1", "Parcial_2", "Semestral_2", "Plano_de_Trabalho", "Relatorio_de_Atividades", "Recuperacao_Paralela", "Final_de_Ano");
foreach($lista_insert as $row) {
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = '{$row}'");
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultado = $resultado->fetch_assoc();
    if ($resultado == NULL) {
        $query = "INSERT INTO EVENTO(NOME, PRAZO1, PRAZO2) VALUES('{$row}', NULL, NULL)";
        $conn->query($query);
    }
}

date_default_timezone_set('America/Sao_Paulo');
$data_Atual = '2025-02-08';

function isPrazoValid($prazo1, $prazo2, $currentDate) {
    if (is_null($prazo1) && is_null($prazo2)) {
        return "NO_PRAZO_DEFINED";
    }
    if (!is_null($prazo1) && $currentDate <= $prazo1) {
        return "PRAZO1_VALID";
    }
    if (!is_null($prazo2) && (is_null($prazo1) || $currentDate > $prazo1) && $currentDate <= $prazo2) {
        return "PRAZO2_VALID";
    }
    return "PRAZO_EXPIRED";
}

function getPrazoStatus($conn, $documento) {
    $instrucao = $conn->prepare("SELECT * FROM EVENTO WHERE NOME = ?");
    $instrucao->bind_param("s", $documento);
    $instrucao->execute();
    $resultado = $instrucao->get_result()->fetch_assoc();
    return [
        'status' => isPrazoValid($resultado["PRAZO1"], $resultado["PRAZO2"], $GLOBALS['data_Atual']),
        'prazo' => (!is_null($resultado["PRAZO1"]) && $GLOBALS['data_Atual'] <= $resultado["PRAZO1"]) ? $resultado["PRAZO1"] : $resultado["PRAZO2"]
    ];
}

function usuarioJaEnviouNoPrazo($conn, $iduser, $tipo, $prazoFinal) {
    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $instrucao = $conn->prepare("SELECT ARQUIVO FROM $tabela WHERE IDUSER = ? AND DATA_ENVIO <= ?");
    $instrucao->bind_param("is", $iduser, $prazoFinal);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    if ($instrucao->fetch()) {
        return $arquivo;
    }
    return false;
}

function removerArquivo($conn, $iduser, $tipo) {
    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $pastas = [
        "Plano de Trabalho" => "images_plano/",
        "Relatorio de Atividades" => "images_relatorio/",
    ];

    $instrucao = $conn->prepare("SELECT ARQUIVO FROM $tabela WHERE IDUSER = ?");
    $instrucao->bind_param("i", $iduser);
    $instrucao->execute();
    $instrucao->bind_result($arquivo);
    
    if ($instrucao->fetch() && $arquivo) {
        $caminho = $pastas[$tipo] . $arquivo;
        
        if (file_exists($caminho)) {
            unlink($caminho);
        }
        
        $instrucao->close();
        
        $deleteInstrucao = $conn->prepare("DELETE FROM $tabela WHERE IDUSER = ?");
        $deleteInstrucao->bind_param("i", $iduser);
        $deleteInstrucao->execute();
        $deleteInstrucao->close();

        echo "<div class='sucesso'>Arquivo removido com sucesso!</div>";
    } else {
        echo "<div class='erro'>Erro ao remover o arquivo.</div>";
    }
}

function Adicionar($iduser, $conn, $tipo, $prazoStatus, $prazoFinal) {
    echo "<p>Depuração: Chamando Adicionar para $tipo</p>";
    
    if ($prazoStatus == "NO_PRAZO_DEFINED" || $prazoStatus == "PRAZO_EXPIRED") {
        echo "<div class='erro'>Não é possível enviar este documento, pois o prazo está inválido.</div>";
        return;
    }
    
    if (usuarioJaEnviouNoPrazo($conn, $iduser, $tipo, $prazoFinal)) {
        echo "<div class='erro'>Você já enviou um documento deste tipo para o prazo vigente.</div>";
        return;
    }
    
    $pastas = [
        "Plano de Trabalho" => "images_plano/",
        "Relatorio de Atividades" => "images_relatorio/",
    ];
    
    if (!isset($_FILES['Arquivo']) || $_FILES['Arquivo']['error'] !== UPLOAD_ERR_OK) {
        echo "<div class='erro'>Erro no upload do arquivo.</div>";
        return;
    }
    
    $imagem = basename($_FILES['Arquivo']["name"]);
    $extensoes_permitidas = array("pdf");
    $extensao = strtolower(pathinfo($imagem, PATHINFO_EXTENSION));
    
    if (!in_array($extensao, $extensoes_permitidas)) {
        echo "<div class='erro'>Arquivos .$extensao não são permitidos.</div>";
        return;
    }
    
    $caminho = $pastas[$tipo] . $imagem;
    if (!is_dir($pastas[$tipo])) {
        mkdir($pastas[$tipo], 0777, true);
    }
    
    if (!move_uploaded_file($_FILES["Arquivo"]["tmp_name"], $caminho)) {
        echo "<div class='erro'>Falha ao mover o arquivo.</div>";
        return;
    }
    
    echo "<div class='sucesso'>Arquivo enviado com sucesso!</div>";
    
    $tabela = str_replace(" ", "_", strtoupper($tipo));
    $instrucao = $conn->prepare("INSERT INTO $tabela (IDUSER, ARQUIVO, ENVIADO, DATA_ENVIO) VALUES(?, ?, ?, ?)");
    $enviado = 1;
    $dataEnvio = date('Y-m-d');
    $instrucao->bind_param("isss", $iduser, $imagem, $enviado, $dataEnvio);
    $instrucao->execute();
}

$prazoPlano = getPrazoStatus($conn, 'Plano_de_Trabalho');
$prazoRelatorio = getPrazoStatus($conn, 'Relatorio_de_Atividades');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['removerArquivo'])) {
        removerArquivo($conn, $_SESSION["ID"], $_POST['tipoDocumento']);
    } elseif (isset($_POST['PlanodeTrabalhoSubmit'])) {
        Adicionar($_SESSION["ID"], $conn, "Plano de Trabalho", $prazoPlano['status'], $prazoPlano['prazo']);
    } elseif (isset($_POST['RelatoriodeAtividadesSubmit'])) {
        Adicionar($_SESSION["ID"], $conn, "Relatorio de Atividades", $prazoRelatorio['status'], $prazoRelatorio['prazo']);
    } 
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Arquivos / SGE</title>
</head>
<body>
    <?php foreach (["Plano de Trabalho" => $prazoPlano, "Relatorio de Atividades" => $prazoRelatorio] as $doc => $prazoInfo) : ?>
        <h3><?= $doc ?></h3>
        <?php $arquivoEnviado = usuarioJaEnviouNoPrazo($conn, $_SESSION["ID"], $doc, $prazoInfo['prazo']); ?>
        <?php if ($arquivoEnviado) : ?>
            <p><strong>Você já enviou um documento deste tipo.</strong></p>
            <form method="post">
                <input type="hidden" name="tipoDocumento" value="<?= $doc ?>">
                <button type="submit" name="removerArquivo">Remover Arquivo</button>
            </form>
        <?php else : ?>
            <form enctype="multipart/form-data" method="post">
                <input type="file" name="Arquivo" required>
                <button type="submit" name="<?= str_replace(' ', '', $doc) ?>Submit">Enviar</button>
            </form>
        <?php endif; ?>
    <?php endforeach; ?>
</body>
</html>
