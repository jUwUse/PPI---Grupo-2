<?php
include('../Config.php');

$InformacoesAluno = "SELECT * FROM DADOS_QUALITATIVOS WHERE IDDADOS_QUALITATIVOS = '{$_POST["pk"]}'";
$resultadoAluno = $conn->query($InformacoesAluno);
$resultadoAluno = $resultadoAluno->fetch_assoc();

$query = "
 UPDATE DADOS_QUALITATIVOS SET ".$_POST["name"]." = '".$_POST["value"]."' 
 WHERE IDDADOS_QUALITATIVOS = '".$_POST["pk"]."'";
mysqli_query($conn, $query);

date_default_timezone_set('America/Sao_Paulo');
$date = date('d/m/Y G:i:s', time());
$string_date = (string)$date;

$query = "INSERT INTO HISTORICO_SETOR(NOME, CONTEUDO, DIA, ALUNO, COLUNA) VALUES('{$_SESSION['Nome']}','{$_POST['value']}','{$string_date}','{$resultadoAluno['NOME']}','{$_POST['name']}')";
mysqli_query($conn, $query);

?>
