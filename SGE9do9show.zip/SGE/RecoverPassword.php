<?php
include("Config.php");
function RecuperarSenha($Email, $conn)
{
    include("ConfigMailer.php");
    $Email = filter_var($Email, FILTER_SANITIZE_EMAIL); //Remove caracteres indesejados do email
    if (filter_var($Email, FILTER_VALIDATE_EMAIL) != TRUE) { //Verifica se o email tá na estrutura certa
        echo "<div class='erro'>O Email inserido não está formatado corretamente.</div>";
        return "não funcionou.";
    }

    $instrucao = $conn->prepare("SELECT EMAIL FROM USUARIO WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
    $instrucao->bind_param("s", $Email); //s=string, i=int, d=double
    $instrucao->execute();
    $resultado = $instrucao->get_result();
    $resultadoverificacao = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
    if ($resultadoverificacao == NULL) {
        echo "<div class='erro'>Esse email não foi encontrado.</div>";
        return "não funcionou.";
    }

    // ---------------- Resto da configuração do Mailer -------------------- //

    $mail->addAddress($Email);
    $mail->addReplyTo(REPLY_TO, REPLY_TO_NAME);
    $mail->IsHTML(true);


    // ---------------- Configuração do Código Enviado -------------------- //

    $Combinacoes = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"; //Todas as possíveis combinações de caracteres
    $ComprimentoSenha = 8;
    $SenhaCombinada = str_shuffle($Combinacoes); //Cria um código para ser enviado ao professor (mas sem tamanho definido)
    $SenhaCombinada = substr($SenhaCombinada, 0, $ComprimentoSenha); //Muda o código para ter comprimento 8
    // echo $SenhaCombinada;

    $titulo = "SGE - Codigo de Recuperacao";
    $corpo = "Utilize o código abaixo no campo de senha, na página de login. A senha poderá ser alterada após feito o login." . "\r\n";
    $corpo .= $SenhaCombinada; //Acabei de descobrir para que serve o .=, ele basicamente junta duas strings. Tipo fazer um += só que com string.

    $mail->Subject = $titulo;
    $mail->Body = $corpo;
    $mail->AltBody = $corpo;

    if (!$mail->send()) {
        echo "<div class='erro'>Houve um erro com o envio do email. Tente novamente mais tarde.</div>";
        return "não funcionou.";
    } else {
        return $SenhaCombinada;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="stylesrecoverpassword.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Recuperar Senha / SGE</title>
</head>

<body>
    <span>
        <?php
        if (isset($_POST['SubmitRecuperarSenha'])) {
            $resultado_por_favor = RecuperarSenha($_POST['EmailRecuperarSenha'], $conn);
            if ($resultado_por_favor == "não funcionou.") {
                echo "<div class='erro'>Houve um erro com o envio do código. Tente novamente.</div>";
            } else {
                $senha_criptografada = password_hash($resultado_por_favor, PASSWORD_DEFAULT);

                $instrucao = $conn->prepare("UPDATE USUARIO SET SENHA = ? WHERE EMAIL = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
                $instrucao->bind_param("ss", $senha_criptografada, $_POST['EmailRecuperarSenha']); //s=string, i=int, d=double
                $instrucao->execute();
                if ($conn->affected_rows != 1) {
                    echo "<div class='erro'>Um erro ocorreu. Tente novamente mais tarde.</div>";
                } else {
                    echo "<div class='senhaenviada'>Siga as instruções do email enviado para recuperar sua senha.</div>";
                }
            }
        }

        ?>
    </span>

    <div class="slidebar">
        <div class="voltar">
            <a href="/SGE/Login.php" class="menu-item" style="display:flex; align-items:center;">
                <i class="uil uil-angle-left-b"></i>
                <span style="margin-left: 8px;">Voltar</span>
            </a><br>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row quadrado align-items-center">
            <div>
                <form action="RecoverPassword.php" method="post" autocomplete="off">
                    <h1> Recuperar Senha </h1>
                    <p> Insira seu email para um código de verificação ser enviado </p>
                    <input class="campo" type="email" id="EmailRecuperarSenha" name="EmailRecuperarSenha" value="<?php echo @$_POST['EmailRecuperarSenha']; ?>" required><br>

                    <input class="botao" type="submit" name="SubmitRecuperarSenha" value="Avançar"><br>
                </form>
            </div>
        </div>
    </div>
</body>

</html>