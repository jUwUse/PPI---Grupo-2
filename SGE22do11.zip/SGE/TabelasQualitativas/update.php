<?php
include('../Config.php');

$query = "
 UPDATE DADOS_QUALITATIVOS SET ".$_POST["name"]." = '".$_POST["value"]."' 
 WHERE IDDADOS_QUALITATIVOS = '".$_POST["pk"]."'";
mysqli_query($conn, $query);

?>
