<?php

// Cookie de tema
$tema_escolhido = "";
if (isset($_COOKIE['estilo']) == FALSE) {
    $tema_escolhido = "styleszdefault";
}
else {
    $tema_escolhido = $_COOKIE['estilo'];
}