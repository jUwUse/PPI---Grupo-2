<?php //Preenche os dados.
    include("Config.php");
    include("Logout_Function.php");

    if (isset($_SESSION['Email']) == FALSE) { // Caso nenhuma sessão tenha iniciado (ou seja, caso o usuário tente entrar sem fazer login)
        logout();
    } else {
        if ($_SESSION['Tipo'] != "ADM") { // Caso o usuário não seja um administrador.
            header("location: Home.php");
            exit();
        }
    }

    $IDAEditar = (int)$_GET['id'];
    $sql = "SELECT * FROM ALUNO WHERE IDALUNO = $IDAEditar";
    $resultadoverificacao = $conn->query($sql);
    $resultadolistapreenche = $resultadoverificacao->fetch_assoc();

    $sql = "SELECT * FROM TURMA WHERE IDTURMA =".$resultadolistapreenche['IDTURMA'];
    $resultadoverificacao = $conn->query($sql);
    $resultadolistapreencheturma = $resultadoverificacao->fetch_assoc();

    if (isset($_GET['id'])) {
        $iddoaluno = $_GET['id'];
        $sql = "SELECT * FROM ALUNO WHERE IDALUNO = $iddoaluno";
        $resultadoverificacao = $conn->query($sql);
        $resultadolista = $resultadoverificacao->fetch_assoc();
        $_SESSION['Turma'] = $resultadolista['IDTURMA'];
    }

    if(isset($_POST['AlteracaoCancel'])) {
        header("location: Turma.php?id=".$_SESSION['Turma']);
    }

    function Alterar($Nome, $Matricula, $Turma, $conn, $id)
    {
        if ($Nome == NULL && $Matricula == NULL && $Turma == NULL) {
            echo "<div class='erro'>Insira as informações que deseja alterar.</div>";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT NOME FROM ALUNO WHERE NOME = ? AND IDALUNO != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "<div class='erro'>Outro aluno já possui este nome.</div>";
            return "não funcionou.";
        }

        $instrucao = $conn->prepare("SELECT MATRICULA FROM ALUNO WHERE MATRICULA = ? AND IDALUNO != $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
        $instrucao->bind_param("i", $Matricula); //s=string, i=int, d=double
        $instrucao->execute();
        $resultado = $instrucao->get_result();
        $resultado = $resultado->fetch_assoc(); //Agrupa o resultado obtido na forma de uma lista.
        if ($resultado != NULL) {
            echo "<div class='erro'>Outro aluno já possui esta matrícula.</div>";
            return "não funcionou.";
        }

        if ($Nome != NULL) {
            if (strlen((string)$Nome) > 100) {
                echo "<div class='erro'>O nome não pode ter mais de 100 caracteres.</div>";
                return "não funcionou.";
            }
            $instrucao = $conn->prepare("UPDATE ALUNO SET NOME = ? WHERE IDALUNO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("s", $Nome); //s=string, i=int, d=double
            $instrucao->execute();
        }

        if ($Matricula != NULL) {
            if (strlen((string)$Matricula) != 10) {
                echo "<div class='erro'>A matrícula deve possuir 10 caracteres.</div>";
                return "não funcionou.";
            }
            $instrucao = $conn->prepare("UPDATE ALUNO SET MATRICULA = ? WHERE IDALUNO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $Matricula); //s=string, i=int, d=double
            $instrucao->execute();
        }

        if ($Turma != NULL) {
            $instrucao = $conn->prepare("SELECT NUMERO FROM TURMA WHERE NUMERO = ?");
            $instrucao->bind_param("i", $Turma); //s=string, i=int, d=double
            $instrucao->execute();
            $resultadonumeroturma = $instrucao->get_result();
            if ($resultadonumeroturma == NULL) {
                echo "<div class='erro'>Essa turma não existe</div>";
                return "não funcionou.";
            }

            $instrucao = $conn->prepare("SELECT * FROM TURMA WHERE NUMERO = ?"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $Turma); //s=string, i=int, d=double
            $instrucao->execute();
            $resultadoturmanumero = $instrucao->get_result();
            $resultadoturmanumero = $resultadoturmanumero->fetch_assoc();
            // print_r($resultadoturmanumero);

            $instrucao = $conn->prepare("UPDATE ALUNO SET IDTURMA = ? WHERE IDALUNO = $id"); //Esse ponto de pergunta é só pra evitar colocar o dado direto (placeholder)
            $instrucao->bind_param("i", $resultadoturmanumero['IDTURMA']); //s=string, i=int, d=double
            $instrucao->execute();
        }

        header("location: Turma.php?id=".$_SESSION['Turma']);
    } 

?> 

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="stylesalterarusuarios.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <title>Alterar Alunos / SGE</title>

    </head>

    <body>
        <?php
        if (isset($_POST['AlteracaoSubmitAluno'])) { // Caso o formulário de professor seja enviado.
            $resultado_final_decisivo_mega_importante = Alterar($_POST['NomeAlteracaoAluno'], $_POST['MatriculaAlteracaoAluno'], $_POST['TurmaAlteracaoAluno'], $conn, $IDAEditar);
            // function Alterar($Nome, $Duracao, $Coordenador, $conn, $id) {
        }
        ?>

        <div class="slidebar">
            <div class="voltar">
                <a href="/SGE/Turma.php?id=<?php echo $_SESSION['Turma']?>" class="menu-item" style="display:flex; align-items:center;">
                    <i class="uil uil-angle-left-b"></i>
                    <span style="margin-left: 8px;">Voltar</span>
                </a><br>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row quadrado align-items-center">

                <form action="" id="FormulariodeAlteracaoAluno" method="post">
                    <label for="NomeAlteracaoAluno">Nome:</label><br>
                    <input class="campo" type="text" id="NomeAlteracaoAluno" name="NomeAlteracaoAluno" placeholder="<?php echo @$resultadolistapreenche["NOME"] ?>" value="<?php echo @$_POST['NomeAlteracaoAluno'] ?>"><br>

                    <label for="MatriculaAlteracaoAluno">Matricula:</label><br>
                    <input class="campo" type="number" id="MatriculaAlteracaoAluno" name="MatriculaAlteracaoAluno" placeholder="<?php echo @$resultadolistapreenche["MATRICULA"] ?>" value="<?php echo @$_POST['MatriculaAlteracaoAluno'] ?>"><br>

                    <label for="TurmaAlteracaoAluno">Turma:</label><br>
                    <input class="campo" type="text" id="TurmaAlteracaoAluno" name="TurmaAlteracaoAluno" placeholder="<?php echo @$resultadolistapreencheturma["NUMERO"] ?>" value="<?php echo @$_POST['TurmaAlteracaoAluno'] ?>"><br>

                    <input class="botaoum" type="submit" name="AlteracaoSubmitAluno" value="Salvar Alterações"><br>
                    <input class="botaodois" type="submit" name="AlteracaoCancel" id="AlteracaoCancel" value="AlteracaoCancel"><br>
                </form>

            </div>
        </div>

    </body>

</html>